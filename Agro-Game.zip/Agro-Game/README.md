# RESQTECH: FIRELINE

A Godot 4.x procedural prototype for a cinematic 3D Indian smart-school emergency survival game.

## Open

1. Open this folder in Godot 4.x.
2. Run the project.
3. Run the story from the in-game HUD. Press `F` to switch from peaceful school life into the FIRELINE disaster phase when prompted.

## Current Scene

`res://scenes/SmartSchoolCampus.tscn` uses `res://scripts/SmartSchoolCampus.gd` to generate:

- Premium Indian private school entrance with security cabin, buses, boom barriers, CCTV, and parent vehicles.
- Four-floor central academic block with open corridors, smart-school infrastructure, emergency signs, stair towers, and rooftop evacuation pad.
- Central courtyard for assembly, panic gathering, and evacuation coordination.
- Smart classrooms, chemistry lab fire origin, library rescue zone, auditorium disaster sequence, control room, cafeteria, staircases, and rooftop finale.
- Normal-life NPC crowd placeholders and fire-phase panic NPC placeholders.
- GPU particle fire, smoke columns, emergency lights, AI route markers, and phase-aware cinematic labels.
- Harshit, the playable student character, spawned into the campus with survival movement and smoke/fire response systems.

## Player System

Player scene: `res://scenes/player/PlayerHarshit.tscn`

Node hierarchy:

- `PlayerHarshit` (`CharacterBody3D`, `PlayerMovement.gd`)
- `CollisionShape3D`
- `Neck`
- `Neck/CameraRig` (`PlayerCamera.gd`)
- `Neck/CameraRig/Camera3D`
- `Neck/CameraRig/Camera3D/InteractionRay` (`PlayerInteraction.gd`)
- `Systems/PlayerHealth`
- `Systems/StaminaSystem`
- `Systems/SmokeProbe`
- `Systems/AudioController`
- `Systems/AnimationController`

Controls:

- `WASD` / arrow keys: move
- `Shift`: sprint
- `Ctrl`: crouch
- `C`: crawl
- `Space`: jump
- `E`: interact
- `Escape`: toggle mouse capture
- `V`: toggle first-person / third-person camera
- `F`: toggle peaceful/fire campus phase

Drone controls after using the auditorium drone station:

- `I` / `K`: fly forward / back
- `J` / `L`: strafe left / right
- `O` / `U`: ascend / descend
- `T`: toggle thermal scan
- Arrow keys: drone camera look
- `-` / `=`: drone zoom

## Playable Story Route

The current build is a complete playable blockout of the RESQTECH: FIRELINE story:

1. Start in the normal school day and read the HUD tutorial prompts.
2. Explore the exhibition/campus, then press `F` when the warning signs objective appears.
3. During the fire phase, pull a fire alarm, collect an extinguisher, and break emergency glass.
4. Rescue Kabir near the classroom corridor.
5. Follow ResQTech safe-route guidance toward the library and rescue Riya/junior students.
6. Reach the auditorium and operate the rescue drone station to unlock thermal scouting.
7. Reach the security control room and activate the exit unlock protocol.
8. Follow the final evacuation objective to the helipad signal zone and interact to complete the ending.

The ending changes based on rescue and system-restoration progress:

- Good ending: rescue key survivors and restore the control-room exit protocol.
- Partial ending: complete evacuation with some objectives missed.
- Bad ending: reach evacuation with too few rescues or without restoring systems.

## In-Game Safety Guidance

The `GameplayStoryDirector` creates a live story HUD with:

- Current chapter
- Main objective
- ResQTech AI subtitles
- Contextual control hints
- Real fire-safety tips
- Survivor/system progress

Smoke and oxygen warnings teach the player to crouch or crawl in dense smoke, avoid unsafe routes, and prioritize evacuation over risky movement.

Implemented systems:

- Smooth acceleration/deceleration movement with sprint, crouch, crawl, jump, landing impact, and low-health movement penalty.
- Realistic first-person controller with smoothed mouse look, floor snapping, slope handling, camera head bob, breathing sway, sprint FOV, crouch/crawl camera height, trauma shake, smoke blindness, panic roll, and landing shake.
- Survival health with fire, smoke, heat, fall, explosion hooks, oxygen loss, safe-zone regeneration, critical state, and collapse.
- Stamina with sprint/crawl/carry drain, exhaustion, and rest recovery.
- Smoke probe that reads `smoke_zone`, `heat_zone`, and `fire_zone` Area3D triggers.
- Raycast interaction for doors, emergency glass, fire alarms, extinguishers, injured NPC carry, rescue drone stations, and emergency switches.
- Audio controller placeholders for footsteps, breathing, coughs, pain, heartbeat, and interaction reactions.
- Animation controller scaffold for idle, walk, sprint, crouch, crawl, jump, injured walk, carrying, and interaction states.

## Characters

Character logic: `res://scripts/characters/CharacterNPC.gd`

Named story characters are generated inside the campus:

- Harshit: playable first-person student volunteer.
- Kabir: best friend, normal phase classmate, fire phase trapped rescue target.
- Riya: smart student, fire phase injured/carryable library rescue target.
- Principal Meera Kapoor: evacuation guidance and leadership NPC.
- Security Guard Mahesh: exit/security guidance NPC.
- ResQTech AI Assistant: holographic emergency guidance interaction point.

NPC interaction states include calm, panicking, trapped, injured, following, and rescued. When the campus switches to the fire phase, the named cast updates into their emergency states automatically.

## Dynamic Fire

Fire simulation root: `res://scenes/fire/FireSimulationRoot.tscn`

Fire scripts:

- `FireManager.gd`: chunk-style simulation tick, active fire registry, propagation, burnable registration, player-distance LOD, and room heat/smoke updates.
- `FireNode.gd`: local flame, smoke, ember, sparks, heat area, dynamic lighting, stage changes, and heat application.
- `BurnableObject.gd`: material-specific ignition, burn progress, fuel, temperature, smoke output, explosion risk, and collapse flags.
- `FireMaterialDatabase.gd`: paper, wood, curtains, plastic, electrical equipment, walls, ceiling panels, chemicals, and concrete fire behavior.
- `HeatSystem.gd`: room temperature, smoke density, oxygen, airflow, and closed-room smoke buildup.
- `ExplosionSystem.gd`: shockwave damage, camera trauma hooks, debris launch, NPC injury, and secondary ignition.
- `FireAudioController.gd`: dynamic crackle/alarm/explosion/collapse audio placeholders.

Campus integration:

- The fire system is spawned as `AAA Dynamic Fire Simulation System`.
- The burnable network seeds chemistry lab chemicals/electricals, library bookshelves, auditorium curtains/roof panels, control-room servers, cafeteria plastics, classroom desks, and corridor notice boards.
- Pressing `F` switches to the disaster phase and ignites the chemistry lab chemical/electrical sources.
- Fire spreads based on material, oxygen, airflow, distance, object size, and intensity.
- Active fires create heat zones that damage the player and heat nearby burnable objects.
- Electrical and chemical burnables can explode and ignite nearby objects.

## Dynamic Smoke

Smoke simulation root: `res://scenes/smoke/SmokeSimulationRoot.tscn`

Smoke scripts:

- `SmokeManager.gd`: room-based smoke simulation, zone connectivity, heat-system integration, player exposure sampling, NPC reactions, and ResQTech guidance events.
- `SmokeZone.gd`: room/corridor/staircase/library/vent/open-area density, oxygen, ceiling smoke, floor smoke, toxic smoke, airflow, sprinklers, ventilation, and GPU particle LOD.
- `OxygenSystem.gd`: bridges smoke/oxygen exposure into the player health and smoke probe systems.
- `VisibilityController.gd`: adjusts volumetric fog, contrast, saturation, glow, and haze based on player smoke exposure.
- `SmokeAudioController.gd`: placeholder loops for coughing, muffled hearing, and panic breathing.

Smoke zone hierarchy:

- `SmokeSimulationRoot`
- `OxygenSystem`
- `VisibilityController`
- `SmokeAudioController`
- Generated `SmokeZone_*` nodes for chemistry lab, library, auditorium, control room, cafeteria, academic corridor, courtyard, staircases, and ventilation network.

Campus behavior:

- Fire output from `HeatSystem` feeds smoke into matching smoke rooms.
- Enclosed rooms fill faster; open courtyard clears faster.
- Staircases behave like smoke chimneys.
- Ventilation network spreads smoke between rooms more quickly.
- Crouching and crawling sample lower air, reducing smoke exposure compared with standing.
- Dense smoke lowers oxygen, worsens visibility, triggers coughing/breathing audio, harms player survival through existing health hooks, and pushes NPCs into panic or injury states.

Optimization:

- Smoke runs on a fixed simulation tick rather than every frame.
- GPU particle amount ratios are density-driven.
- Particle LOD lowers emission for zones far from the player.
- Room simulation uses compact per-zone values instead of per-particle physics.

## Renderer Target

The project is configured for Godot 4 Forward+ with SDFGI, volumetric fog, glow, directional shadows, and PBR-style materials.

## Next Build Steps

- Replace primitive blockout geometry with modeled modular assets.
- Add production animation clips, audio assets, and UI materials for health/stamina/oxygen/prompt feedback.
- Convert NPC placeholders into crowd AI and evacuation agents.
- Add real fire spread logic, damage volumes, destructible props, and dynamic navigation updates.
- Add audio buses for normal campus ambience, alarms, fire, coughing, debris, AI announcements, and helicopter finale.
