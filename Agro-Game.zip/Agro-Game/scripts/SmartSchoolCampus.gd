extends Node3D

enum DisasterPhase { NORMAL, FIRE }

const PLAYER_SCENE := preload("res://scenes/player/PlayerHarshit.tscn")
const FIRE_SIMULATION_SCENE := preload("res://scenes/fire/FireSimulationRoot.tscn")
const SMOKE_SIMULATION_SCENE := preload("res://scenes/smoke/SmokeSimulationRoot.tscn")
const STORY_DIRECTOR_SCRIPT := preload("res://scripts/story/GameplayStoryDirector.gd")
const CAMPUS_HALF_EXTENT := 92.0
const FLOOR_HEIGHT := 4.2
const ACADEMIC_FLOORS := 4

var phase: int = DisasterPhase.NORMAL
var normal_nodes: Array[Node] = []
var fire_nodes: Array[Node] = []
var route_nodes: Array[Node] = []
var story_characters: Array[Node] = []
var fire_manager: FireManager
var smoke_manager: SmokeManager
var player: CharacterBody3D
var story_director: GameplayStoryDirector
var fire_ignited := false
var flicker_lights: Array[Light3D] = []
var fire_emitters: Array[GPUParticles3D] = []
var smoke_emitters: Array[GPUParticles3D] = []
var phase_label: Label3D
var ai_label: Label3D
var camera_rig: Node3D

var mat_cream: StandardMaterial3D
var mat_sandstone: StandardMaterial3D
var mat_glass: StandardMaterial3D
var mat_floor: StandardMaterial3D
var mat_asphalt: StandardMaterial3D
var mat_grass: StandardMaterial3D
var mat_steel: StandardMaterial3D
var mat_emergency: StandardMaterial3D
var mat_fire_emissive: StandardMaterial3D
var mat_smoke: StandardMaterial3D
var mat_blue_emissive: StandardMaterial3D
var mat_green_route: StandardMaterial3D
var mat_wood: StandardMaterial3D
var mat_black: StandardMaterial3D
var mat_white: StandardMaterial3D


func _ready() -> void:
	_build_materials()
	_build_world()
	_build_campus()
	_spawn_player_harshit()
	_apply_phase(DisasterPhase.NORMAL)
	_build_story_director()


func _process(delta: float) -> void:
	if phase == DisasterPhase.FIRE:
		for light in flicker_lights:
			light.light_energy = 2.0 + randf() * 4.5
		for emitter in fire_emitters:
			emitter.amount_ratio = clamp(emitter.amount_ratio + delta * 0.05, 0.25, 1.0)
		for emitter in smoke_emitters:
			emitter.amount_ratio = clamp(emitter.amount_ratio + delta * 0.035, 0.2, 1.0)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F:
			_apply_phase(DisasterPhase.FIRE if phase == DisasterPhase.NORMAL else DisasterPhase.NORMAL)


func _build_materials() -> void:
	mat_cream = _mat("Warm cream concrete", Color(0.78, 0.70, 0.58), 0.78, 0.0)
	mat_sandstone = _mat("Bhopal red sandstone accents", Color(0.55, 0.20, 0.13), 0.65, 0.0)
	mat_glass = _mat("Reflective smart glass", Color(0.28, 0.48, 0.62, 0.42), 0.12, 0.35)
	mat_glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_floor = _mat("Polished corridor tile", Color(0.68, 0.66, 0.60), 0.28, 0.15)
	mat_asphalt = _mat("Indian campus road asphalt", Color(0.045, 0.047, 0.05), 0.92, 0.0)
	mat_grass = _mat("Landscaped monsoon grass", Color(0.14, 0.38, 0.18), 0.88, 0.0)
	mat_steel = _mat("Brushed steel railings", Color(0.42, 0.43, 0.42), 0.24, 0.55)
	mat_emergency = _mat("Emergency red emissive", Color(0.8, 0.04, 0.02), 0.35, 0.0, Color(3.0, 0.05, 0.02))
	mat_fire_emissive = _mat("GPU fire emissive", Color(1.0, 0.32, 0.02), 0.4, 0.0, Color(5.0, 1.3, 0.05))
	mat_smoke = _mat("Volumetric dark smoke", Color(0.06, 0.06, 0.065, 0.5), 0.95, 0.0)
	mat_smoke.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_blue_emissive = _mat("AI blue monitor glow", Color(0.04, 0.42, 0.95), 0.25, 0.0, Color(0.0, 1.6, 4.0))
	mat_green_route = _mat("ResQTech safe route green", Color(0.08, 0.95, 0.42), 0.3, 0.0, Color(0.1, 3.0, 0.85))
	mat_wood = _mat("Library warm wood", Color(0.36, 0.20, 0.10), 0.55, 0.0)
	mat_black = _mat("Charred disaster material", Color(0.015, 0.012, 0.01), 0.86, 0.0)
	mat_white = _mat("School whiteboard ceramic", Color(0.88, 0.90, 0.86), 0.22, 0.0)


func _mat(material_name: String, albedo: Color, roughness: float, metallic: float, emission: Color = Color.BLACK) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.resource_name = material_name
	material.albedo_color = albedo
	material.roughness = roughness
	material.metallic = metallic
	if emission != Color.BLACK:
		material.emission_enabled = true
		material.emission = emission
	return material


func _build_world() -> void:
	var environment := WorldEnvironment.new()
	var env := Environment.new()
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.42, 0.66, 0.92)
	sky_material.sky_horizon_color = Color(0.92, 0.80, 0.62)
	sky.sky_material = sky_material
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.65
	env.sdfgi_enabled = true
	env.sdfgi_energy = 1.15
	env.volumetric_fog_enabled = true
	env.volumetric_fog_density = 0.012
	env.volumetric_fog_albedo = Color(0.78, 0.82, 0.86)
	env.glow_enabled = true
	env.glow_intensity = 0.55
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 1.05
	environment.environment = env
	add_child(environment)

	var sun := DirectionalLight3D.new()
	sun.name = "Warm Morning Sun / Fire Phase Mooned Smoke Light"
	sun.rotation_degrees = Vector3(-42, -34, 0)
	sun.light_energy = 3.2
	sun.shadow_enabled = true
	add_child(sun)

	camera_rig = Node3D.new()
	camera_rig.name = "Cinematic Camera Rig"
	camera_rig.position = Vector3(0, 16, 74)
	add_child(camera_rig)

	var camera := Camera3D.new()
	camera.name = "Hybrid Third Person Cinematic Camera"
	camera.position = Vector3(0, 6, 14)
	camera.rotation_degrees = Vector3(-17, 0, 0)
	camera.fov = 56
	camera.doppler_tracking = Camera3D.DOPPLER_TRACKING_PHYSICS_STEP
	camera.current = true
	camera_rig.add_child(camera)

	phase_label = _label("PHASE: PEACEFUL SCHOOL LIFE\nPress F to trigger FIRELINE disaster phase", Vector3(-34, 10, 50), 34, Color.WHITE)
	add_child(phase_label)
	ai_label = _label("ResQTech AI: Campus systems nominal. Exhibition crowd density rising.", Vector3(0, 6.5, -14), 22, Color(0.55, 0.9, 1.0))
	add_child(ai_label)


func _build_campus() -> void:
	_create_box("Campus foundation / playable terrain", Vector3.ZERO, Vector3(CAMPUS_HALF_EXTENT * 2.0, 0.35, CAMPUS_HALF_EXTENT * 2.0), mat_grass)
	_create_collision_box("Campus ground collision", Vector3(0, -0.18, 0), Vector3(CAMPUS_HALF_EXTENT * 2.0, 0.35, CAMPUS_HALF_EXTENT * 2.0))
	_create_box("Realistic Indian approach road", Vector3(0, 0.02, 82), Vector3(80, 0.12, 18), mat_asphalt)
	_build_fire_simulation_root()
	_build_smoke_simulation_root()
	_build_main_entrance()
	_build_academic_block()
	_build_courtyard()
	_build_special_zones()
	_build_burnable_fire_targets()
	_build_smoke_zones()
	_build_smart_infrastructure()
	_build_npc_crowd()
	_build_story_characters()
	_build_fireline_systems()


func _build_main_entrance() -> void:
	var gate_root := Node3D.new()
	gate_root.name = "Main Entrance - SPS GN Bhopal Inspired Premium Gate"
	add_child(gate_root)
	_create_box("Logo wall: RESQTECH FIRELINE SMART SCHOOL", Vector3(0, 3.2, 73), Vector3(28, 6.2, 1.2), mat_cream, gate_root)
	_create_box("Red sandstone school identity band", Vector3(0, 6.6, 72.35), Vector3(30, 1.0, 1.4), mat_sandstone, gate_root)
	_create_box("Security cabin with CCTV", Vector3(-23, 2, 71), Vector3(8, 4, 7), mat_cream, gate_root)
	_create_box("Cabin smart glass", Vector3(-23, 3, 67.25), Vector3(6.5, 2, 0.18), mat_glass, gate_root)
	for x in [-10.0, 10.0]:
		_create_box("Biometric entry pillar", Vector3(x, 2.1, 68), Vector3(1.2, 4.2, 1.2), mat_steel, gate_root)
		_create_box("Boom barrier arm", Vector3(x * 0.5, 1.55, 68), Vector3(12, 0.18, 0.28), mat_emergency, gate_root)
	for i in range(4):
		_create_school_bus(Vector3(-52 + i * 14, 1.1, 84), gate_root)
	for i in range(8):
		_create_box("Parent vehicle queue car", Vector3(28 + i * 6, 0.65, 83), Vector3(4.0, 1.3, 2.2), _mat("car_%s" % i, Color(0.12 + 0.08 * i, 0.15, 0.20 + 0.03 * i), 0.38, 0.1), gate_root)
	_create_label_on_parent("MAIN ENTRANCE\nSecurity, buses, biometric gates", Vector3(0, 8.5, 72), gate_root)


func _build_academic_block() -> void:
	var block := Node3D.new()
	block.name = "Central 4-Floor Academic Block - Symmetrical Smart School"
	add_child(block)
	var wing_specs := [
		["North Academic Wing", Vector3(0, 0, -34), Vector3(72, FLOOR_HEIGHT * ACADEMIC_FLOORS, 10)],
		["West Academic Wing", Vector3(-41, 0, -5), Vector3(10, FLOOR_HEIGHT * ACADEMIC_FLOORS, 58)],
		["East Academic Wing", Vector3(41, 0, -5), Vector3(10, FLOOR_HEIGHT * ACADEMIC_FLOORS, 58)]
	]
	for spec in wing_specs:
		var wing_name: String = spec[0]
		var pos: Vector3 = spec[1]
		var size: Vector3 = spec[2]
		_create_box(wing_name + " cream facade", pos + Vector3(0, size.y * 0.5, 0), size, mat_cream, block)
		for floor_index in range(ACADEMIC_FLOORS):
			var y := 1.4 + floor_index * FLOOR_HEIGHT
			_create_box(wing_name + " open corridor floor %d polished tile" % (floor_index + 1), pos + Vector3(0, y, size.z * 0.52), Vector3(size.x * 0.94, 0.18, 2.2), mat_floor, block)
			_create_box(wing_name + " steel railing floor %d" % (floor_index + 1), pos + Vector3(0, y + 1.0, size.z * 0.65), Vector3(size.x * 0.92, 0.22, 0.22), mat_steel, block)
			_add_window_row(wing_name, pos, size, y + 1.15, block)
	_create_box("Central glass atrium AI lobby", Vector3(0, 8.4, -5), Vector3(18, 16.8, 12), mat_glass, block)
	for x in [-46.5, 46.5]:
		for z in [-36, 24]:
			_create_staircase_tower(Vector3(x, 8.5, z), block)
	_create_label_on_parent("CENTRAL ACADEMIC BLOCK\n4 floors, open corridors, smart classrooms", Vector3(0, 20, -31), block)


func _add_window_row(prefix: String, pos: Vector3, size: Vector3, y: float, parent: Node) -> void:
	var count := int(max(4.0, size.x / 8.0))
	var denominator := float(max(1, count - 1))
	for i in range(count):
		var x: float = pos.x - size.x * 0.38 + float(i) * (size.x * 0.76 / denominator)
		_create_box(prefix + " reflective classroom window", Vector3(x, y, pos.z + size.z * 0.535), Vector3(4.4, 2.0, 0.12), mat_glass, parent)


func _build_courtyard() -> void:
	var courtyard := Node3D.new()
	courtyard.name = "Central Courtyard / Assembly and Evacuation Zone"
	add_child(courtyard)
	_create_box("Assembly courtyard stone paving", Vector3(0, 0.18, 9), Vector3(64, 0.22, 48), mat_floor, courtyard)
	_create_box("School stage with LED display", Vector3(0, 1.1, 29), Vector3(24, 2.2, 8), mat_sandstone, courtyard)
	_create_box("Huge LED display normal announcements / emergency maps", Vector3(0, 3.8, 24.8), Vector3(18, 4.5, 0.28), mat_blue_emissive, courtyard)
	_create_flag(Vector3(-24, 0.25, 24), courtyard)
	for x in [-26, 26]:
		for z in [-8, 8, 20]:
			_create_tree(Vector3(x, 0.2, z), courtyard)
	for x in [-18, -6, 6, 18]:
		_create_box("Courtyard bench", Vector3(x, 0.65, -7), Vector3(6, 0.45, 1.2), mat_wood, courtyard)
	_create_label_on_parent("CENTRAL COURTYARD\nMorning assembly -> evacuation command zone", Vector3(0, 7, 8), courtyard)


func _build_special_zones() -> void:
	_build_smart_classroom(Vector3(-30, 2.35, -34), "Smart Classroom A - CBSE XII", false)
	_build_smart_classroom(Vector3(30, 2.35, -34), "Smart Classroom B - Rescue Tutorial", false)
	_build_chemistry_lab()
	_build_library()
	_build_auditorium()
	_build_control_room()
	_build_cafeteria()
	_build_rooftop()


func _build_smart_classroom(center: Vector3, title: String, is_fire_origin: bool) -> void:
	var room := Node3D.new()
	room.name = title
	add_child(room)
	_create_box(title + " back wall", center + Vector3(0, 2, -5), Vector3(20, 4, 0.35), mat_cream, room)
	_create_box(title + " tiled floor", center + Vector3(0, -1.9, 0), Vector3(20, 0.2, 12), mat_floor, room)
	_create_box(title + " smart board", center + Vector3(0, 2.2, -5.22), Vector3(8, 2.8, 0.18), mat_blue_emissive, room)
	_create_box(title + " whiteboard", center + Vector3(-6.3, 2.1, -5.25), Vector3(4.2, 2.2, 0.15), mat_white, room)
	for row in range(3):
		for col in range(4):
			_create_box(title + " scratched student desk", center + Vector3(-6 + col * 4, -1.25, -0.5 + row * 2.5), Vector3(2.5, 0.28, 1.4), mat_wood, room)
			_create_box(title + " bench", center + Vector3(-6 + col * 4, -1.55, 0.45 + row * 2.5), Vector3(2.6, 0.25, 0.55), mat_wood, room)
	_create_box(title + " digital attendance panel", center + Vector3(9.2, 1.6, -3.3), Vector3(0.25, 1.6, 1.2), mat_blue_emissive, room)
	_create_box(title + " ceiling fans / AC line", center + Vector3(0, 4.15, 0), Vector3(15, 0.16, 0.16), mat_steel, room)
	_create_interactable_box("Manual fire alarm pull station", center + Vector3(8.9, 0.35, -4.2), Vector3(0.45, 0.75, 0.25), mat_emergency, "fire_alarm", "Pull fire alarm", room)
	_create_interactable_box("Emergency glass breaker case", center + Vector3(-8.8, 0.3, -4.2), Vector3(0.5, 0.7, 0.2), mat_glass, "emergency_glass", "Break emergency glass", room)
	_create_label_on_parent(title + "\nSmart boards, bags, posters, fans, CCTV", center + Vector3(0, 4.5, 0), room)
	if is_fire_origin:
		_create_fire_cluster(center + Vector3(0, -1.2, -2.2), 1.0, room)


func _build_chemistry_lab() -> void:
	var lab := Node3D.new()
	lab.name = "CHEMISTRY LAB - FIRE ORIGIN / Explosion Sequence"
	add_child(lab)
	var center := Vector3(0, 2.35, -44)
	_build_smart_classroom(center, "Chemistry Lab Origin Room", true)
	for i in range(8):
		_create_cylinder("Chemical bottle display", center + Vector3(-8 + i * 2.2, -1.0, 1.5), 0.25, 0.9, _mat("chemical_%d" % i, Color(0.1 * i, 0.7, 0.25 + i * 0.06, 0.78), 0.15, 0.0), lab)
	_create_box("Overloaded exhibition extension boards", center + Vector3(5.8, -0.95, -2.0), Vector3(4, 0.25, 1.3), mat_black, lab)
	_create_box("Gas pipeline danger line", center + Vector3(-8.5, 0.2, -3.7), Vector3(0.28, 0.28, 6), mat_emergency, lab)
	_create_fire_cluster(center + Vector3(4, -1.7, -2), 1.7, lab)
	_create_smoke_column("Pressure-wave smoke from chemistry blast", center + Vector3(2, 0, -1), Vector3(6, 4, 6), lab)
	_create_label_on_parent("CHEMISTRY LAB\nOverload, chemical bottles, gas lines, blast origin", center + Vector3(0, 5.6, 0), lab)


func _build_library() -> void:
	var lib := Node3D.new()
	lib.name = "Library Rescue Zone - Riya and Junior Students"
	add_child(lib)
	var center := Vector3(-58, 3, -6)
	_create_box("Large library hall", center + Vector3(0, 2.8, 0), Vector3(24, 9, 26), mat_cream, lib)
	_create_box("Library warm wooden floor", center + Vector3(0, -1.85, 0), Vector3(25, 0.22, 27), mat_wood, lib)
	for row in range(4):
		for col in range(3):
			_create_box("Tall multi-floor bookshelf", center + Vector3(-8 + col * 8, 0.4, -8 + row * 5), Vector3(1.0, 4.5, 4.0), mat_wood, lib)
	for i in range(4):
		_create_box("Library computer terminal", center + Vector3(-6 + i * 4, -1.0, 7.5), Vector3(2.2, 0.25, 1.4), mat_blue_emissive, lib)
	_create_interactable_box("Injured junior student rescue point", center + Vector3(7, -1.0, 5), Vector3(1.2, 1.2, 1.2), mat_emergency, "carry_npc", "Carry injured student", lib)
	_create_smoke_column("Library smoke shaft", center + Vector3(5, 0, -4), Vector3(5, 8, 7), lib)
	_create_fire_cluster(center + Vector3(-6, -1.4, -6), 1.2, lib)
	_create_label_on_parent("LIBRARY RESCUE\nBurning books, smoke shafts, collapsing shelves", center + Vector3(0, 8.5, 0), lib)


func _build_auditorium() -> void:
	var aud := Node3D.new()
	aud.name = "Auditorium - Science Exhibition and Final Collapse"
	add_child(aud)
	var center := Vector3(58, 3.5, 2)
	_create_box("Modern auditorium shell", center + Vector3(0, 3, 0), Vector3(30, 11, 38), mat_cream, aud)
	_create_box("Auditorium stage", center + Vector3(0, -1, -14), Vector3(24, 1.6, 7), mat_sandstone, aud)
	_create_box("ResQTech AI demonstration LED wall", center + Vector3(0, 2.7, -17.8), Vector3(18, 5, 0.2), mat_blue_emissive, aud)
	for i in range(5):
		_create_box("Science exhibition booth robotics drone irrigation AI", center + Vector3(-10 + i * 5, -1.2, -4), Vector3(3.2, 2, 2.6), mat_glass, aud)
	_create_interactable_box("Rescue drone operation station", center + Vector3(0, -0.5, -7.5), Vector3(2.0, 1.4, 1.2), mat_blue_emissive, "rescue_drone", "Operate rescue drone", aud)
	for row in range(5):
		_create_box("Audience seating row", center + Vector3(0, -1.6, 2 + row * 3), Vector3(24, 0.45, 1.4), mat_wood, aud)
	_create_fire_cluster(center + Vector3(9, -1.4, -12), 1.6, aud)
	_create_smoke_column("Auditorium heavy final smoke", center + Vector3(0, 0, 4), Vector3(13, 10, 14), aud)
	_create_box("Hanging roof-collapse debris slab", center + Vector3(-6, 7.3, 1), Vector3(12, 0.5, 6), mat_black, aud)
	_create_label_on_parent("AUDITORIUM\nExhibition booths -> roof collapse finale", center + Vector3(0, 10, 0), aud)


func _build_control_room() -> void:
	var room := Node3D.new()
	room.name = "Security Control Room - ResQTech AI Core"
	add_child(room)
	var center := Vector3(0, 3, 34)
	_create_box("Control room dark tech shell", center + Vector3(0, 2.2, 0), Vector3(24, 7, 12), mat_black, room)
	for row in range(2):
		for col in range(6):
			_create_box("CCTV thermal fire prediction monitor", center + Vector3(-9 + col * 3.6, 3.2 + row * 2.2, -6.2), Vector3(2.8, 1.5, 0.16), mat_blue_emissive, room)
	for i in range(5):
		_create_box("Backup server rack", center + Vector3(-9 + i * 4.5, 0.7, 4.5), Vector3(2, 4, 1.4), mat_steel, room)
	_create_box("Emergency control console", center + Vector3(0, -0.9, -1), Vector3(14, 1.1, 3), mat_blue_emissive, room)
	_create_interactable_box("Exit unlock emergency switch", center + Vector3(0, -0.1, -1), Vector3(3.2, 1.4, 1.4), mat_green_route, "emergency_switch", "Activate exit unlock protocol", room)
	_create_fire_cluster(center + Vector3(8, -1.3, 4), 0.75, room)
	_create_label_on_parent("SECURITY CONTROL ROOM\nCCTV, AI maps, thermal screens, exit protocols", center + Vector3(0, 7.4, 0), room)


func _build_cafeteria() -> void:
	var cafe := Node3D.new()
	cafe.name = "Modern Indian School Cafeteria"
	add_child(cafe)
	var center := Vector3(-34, 1.8, 40)
	_create_box("Cafeteria shell", center + Vector3(0, 2.2, 0), Vector3(28, 6, 18), mat_cream, cafe)
	_create_box("Steel serving counter with Indian snacks", center + Vector3(-8, -0.8, -6), Vector3(12, 1, 2), mat_steel, cafe)
	for i in range(5):
		_create_box("Cafeteria table abandoned trays", center + Vector3(-10 + i * 5, -1.15, 2), Vector3(3, 0.32, 2), mat_wood, cafe)
	_create_smoke_column("Cafeteria smoke through ventilation", center + Vector3(7, 0, -2), Vector3(5, 5, 6), cafe)
	_create_label_on_parent("CAFETERIA\nSteel counters, trays, malfunctioning sprinklers", center + Vector3(0, 5.8, 0), cafe)


func _build_fire_simulation_root() -> void:
	fire_manager = FIRE_SIMULATION_SCENE.instantiate() as FireManager
	fire_manager.name = "AAA Dynamic Fire Simulation System"
	add_child(fire_manager)
	fire_manager.structural_collapse_requested.connect(_on_fire_structural_collapse_requested)


func _build_smoke_simulation_root() -> void:
	smoke_manager = SMOKE_SIMULATION_SCENE.instantiate() as SmokeManager
	smoke_manager.name = "AAA Dynamic Smoke Simulation System"
	add_child(smoke_manager)
	if fire_manager and fire_manager.has_node("HeatSystem"):
		smoke_manager.bind_heat_system(fire_manager.get_node("HeatSystem") as HeatSystem)
	smoke_manager.smoke_guidance_requested.connect(_on_smoke_guidance_requested)


func _build_burnable_fire_targets() -> void:
	var burnables_root := Node3D.new()
	burnables_root.name = "Burnable Material Network - Dynamic Fire Propagation Targets"
	add_child(burnables_root)

	_create_burnable_box("Chemistry overloaded extension board", Vector3(5.8, 1.3, -46), Vector3(3.8, 0.45, 1.3), BurnableObject.MaterialType.ELECTRICAL, "chemistry_lab", 0.85, false, burnables_root)
	_create_burnable_box("Chemistry volatile chemical tray", Vector3(0, 1.0, -42.5), Vector3(4.2, 0.4, 1.4), BurnableObject.MaterialType.CHEMICAL, "chemistry_lab", 1.0, false, burnables_root)
	_create_burnable_box("Chemistry wooden lab counter", Vector3(-5.4, 1.0, -42.2), Vector3(5.5, 0.6, 1.7), BurnableObject.MaterialType.WOOD, "chemistry_lab", 1.4, false, burnables_root)
	_create_burnable_box("Chemistry ceiling panel collapse risk", Vector3(1.0, 5.4, -44), Vector3(7.0, 0.28, 5.5), BurnableObject.MaterialType.CEILING_PANEL, "chemistry_lab", 1.2, true, burnables_root)

	for index in range(6):
		_create_burnable_box("Library paper book stack %02d" % index, Vector3(-65 + index * 3.2, 1.0, -10 + (index % 2) * 8), Vector3(1.2, 1.8, 3.0), BurnableObject.MaterialType.PAPER, "library", 0.8, false, burnables_root)
	for index in range(3):
		_create_burnable_box("Library wooden shelf collapse %02d" % index, Vector3(-66 + index * 7.0, 2.0, -3), Vector3(1.0, 4.0, 4.4), BurnableObject.MaterialType.WOOD, "library", 1.5, true, burnables_root)

	_create_burnable_box("Auditorium stage curtain left", Vector3(50, 2.0, -12), Vector3(0.5, 4.5, 6.0), BurnableObject.MaterialType.CURTAIN, "auditorium", 1.1, false, burnables_root)
	_create_burnable_box("Auditorium stage curtain right", Vector3(66, 2.0, -12), Vector3(0.5, 4.5, 6.0), BurnableObject.MaterialType.CURTAIN, "auditorium", 1.1, false, burnables_root)
	_create_burnable_box("Auditorium robotics electronics booth", Vector3(58, 1.0, -2), Vector3(4.5, 1.6, 2.5), BurnableObject.MaterialType.ELECTRICAL, "auditorium", 0.9, false, burnables_root)
	_create_burnable_box("Auditorium roof panel structural risk", Vector3(58, 8.4, 3), Vector3(16.0, 0.35, 10.0), BurnableObject.MaterialType.CEILING_PANEL, "auditorium", 1.6, true, burnables_root)

	_create_burnable_box("Control room server rack electrical hazard", Vector3(0, 3.0, 38.5), Vector3(11.0, 4.2, 1.4), BurnableObject.MaterialType.ELECTRICAL, "control_room", 1.2, false, burnables_root)
	_create_burnable_box("Cafeteria plastic tray smoke source", Vector3(-34, 1.0, 42), Vector3(8.0, 0.35, 3.0), BurnableObject.MaterialType.PLASTIC, "cafeteria", 0.9, false, burnables_root)

	for index in range(6):
		_create_burnable_box("Classroom wooden desks cluster %02d" % index, Vector3(-34 + index * 13.5, 1.0, -30), Vector3(4.6, 0.8, 3.4), BurnableObject.MaterialType.WOOD, "academic_corridor", 1.0, false, burnables_root)
	for index in range(4):
		_create_burnable_box("Corridor paper notice board %02d" % index, Vector3(-32 + index * 20, 2.4, -27.5), Vector3(3.5, 1.8, 0.25), BurnableObject.MaterialType.PAPER, "academic_corridor", 0.5, false, burnables_root)


func _build_smoke_zones() -> void:
	if smoke_manager == null:
		return
	smoke_manager.create_zone("chemistry_lab", Vector3(0, 2.7, -44), Vector3(24, 5.2, 16), SmokeZone.ZoneType.CLASSROOM, 0.18, 1.25)
	smoke_manager.create_zone("library", Vector3(-58, 3.2, -6), Vector3(28, 8.5, 30), SmokeZone.ZoneType.LIBRARY, 0.16, 1.35)
	smoke_manager.create_zone("auditorium", Vector3(58, 4.2, 2), Vector3(34, 11, 42), SmokeZone.ZoneType.AUDITORIUM, 0.22, 1.2)
	smoke_manager.create_zone("control_room", Vector3(0, 3.2, 34), Vector3(26, 7.5, 14), SmokeZone.ZoneType.CLASSROOM, 0.14, 1.45)
	smoke_manager.create_zone("cafeteria", Vector3(-34, 2.4, 40), Vector3(30, 6.5, 20), SmokeZone.ZoneType.CLASSROOM, 0.28, 1.05)
	smoke_manager.create_zone("academic_corridor", Vector3(0, 5.2, -24), Vector3(92, 10, 13), SmokeZone.ZoneType.CORRIDOR, 0.38, 0.9)
	smoke_manager.create_zone("central_courtyard", Vector3(0, 2.5, 9), Vector3(72, 6, 54), SmokeZone.ZoneType.OPEN_COURTYARD, 0.85, 0.35)
	smoke_manager.create_zone("staircase_west", Vector3(-46.5, 7, -6), Vector3(9, 18, 70), SmokeZone.ZoneType.STAIRCASE, 0.45, 1.15)
	smoke_manager.create_zone("staircase_east", Vector3(46.5, 7, -6), Vector3(9, 18, 70), SmokeZone.ZoneType.STAIRCASE, 0.45, 1.15)
	smoke_manager.create_zone("ventilation_network", Vector3(0, 8.5, -4), Vector3(88, 2.4, 76), SmokeZone.ZoneType.VENT_SHAFT, 0.72, 0.8)

	smoke_manager.connect_zones("chemistry_lab", "academic_corridor")
	smoke_manager.connect_zones("library", "academic_corridor")
	smoke_manager.connect_zones("auditorium", "academic_corridor")
	smoke_manager.connect_zones("control_room", "central_courtyard")
	smoke_manager.connect_zones("cafeteria", "central_courtyard")
	smoke_manager.connect_zones("academic_corridor", "staircase_west")
	smoke_manager.connect_zones("academic_corridor", "staircase_east")
	smoke_manager.connect_zones("academic_corridor", "ventilation_network")
	smoke_manager.connect_zones("ventilation_network", "library")
	smoke_manager.connect_zones("ventilation_network", "auditorium")


func _build_rooftop() -> void:
	var roof := Node3D.new()
	roof.name = "Rooftop Evacuation Zone - Final Helicopter Rescue"
	add_child(roof)
	var y := FLOOR_HEIGHT * ACADEMIC_FLOORS + 0.55
	_create_box("Rooftop evacuation pad", Vector3(0, y, -34), Vector3(42, 0.3, 15), mat_floor, roof)
	_create_cylinder("Helipad landing circle", Vector3(0, y + 0.08, -34), 8.0, 0.12, mat_emergency, roof)
	for x in [-18, 18]:
		_create_box("Broken rooftop parapet", Vector3(x, y + 1, -27), Vector3(8, 2, 0.8), mat_black, roof)
	_create_smoke_column("City-wide smoke visible from rooftop", Vector3(12, y + 1, -34), Vector3(14, 9, 10), roof)
	_create_interactable_box("Final rooftop evacuation flare", Vector3(0, y + 1.2, -34), Vector3(7.0, 2.4, 7.0), mat_green_route, "final_evacuate", "Signal rooftop evacuation", roof)
	_create_interactable_box("Accessible final evacuation signal zone", Vector3(0, 1.2, -34), Vector3(8.0, 2.4, 8.0), mat_green_route, "final_evacuate", "Signal rooftop evacuation", roof)
	_create_label_on_parent("ROOFTOP EVACUATION\nHelicopter approach, final collapse, hope", Vector3(0, y + 5, -34), roof)


func _build_smart_infrastructure() -> void:
	var infra := Node3D.new()
	infra.name = "Smart School Technology and Emergency Infrastructure"
	add_child(infra)
	var camera_points := [Vector3(-32, 6, 30), Vector3(32, 6, 30), Vector3(-32, 8, -30), Vector3(32, 8, -30), Vector3(0, 8, 68)]
	for p in camera_points:
		_create_cylinder("AI CCTV dome camera", p, 0.45, 0.35, mat_black, infra)
		_create_box("Camera mount", p + Vector3(0, -0.4, 0), Vector3(0.18, 0.8, 0.18), mat_steel, infra)
	for p in [Vector3(-30, 3.4, -26), Vector3(30, 3.4, -26), Vector3(-42, 4.2, 10), Vector3(42, 4.2, 10)]:
		_create_box("Digital emergency evacuation sign", p, Vector3(4.2, 1.2, 0.18), mat_green_route, infra)
		_add_route_marker(p + Vector3(0, -1.2, 2.5), infra)
	for p in [Vector3(-12, 2, -26), Vector3(12, 2, -26), Vector3(-44, 2, 14), Vector3(44, 2, 14)]:
		_create_cylinder("Fire extinguisher gameplay pickup", p, 0.22, 1.2, mat_emergency, infra)
		_create_interactable_box("Fire extinguisher pickup trigger", p + Vector3(0, 0.25, 0), Vector3(0.9, 1.5, 0.9), mat_emergency, "extinguisher", "Take extinguisher", infra)


func _build_npc_crowd() -> void:
	var crowd := Node3D.new()
	crowd.name = "NPC Crowd System Placeholders - Students Teachers Guards Visitors"
	add_child(crowd)
	for i in range(54):
		var x: float = randf_range(-28, 28)
		var z: float = randf_range(-6, 28)
		var normal := _create_npc("Normal student chatter %02d" % i, Vector3(x, 0.95, z), Color(randf_range(0.05, 0.25), randf_range(0.15, 0.35), randf_range(0.55, 0.95)), crowd)
		normal_nodes.append(normal)
	for i in range(26):
		var z_sign: float = -1.0 if i % 2 == 0 else 1.0
		var fire_npc := _create_npc("Panic evacuation runner %02d" % i, Vector3(randf_range(-36, 36), 0.95, randf_range(-22, 32) * z_sign), Color(0.9, 0.15, 0.05), crowd)
		fire_nodes.append(fire_npc)


func _build_story_characters() -> void:
	var characters := Node3D.new()
	characters.name = "Story Characters - Harshit Allies and ResQTech AI"
	add_child(characters)

	var kabir := _create_story_character(
		"Kabir",
		"Harshit best friend - funny but panic-prone",
		Vector3(30, 1.0, -31),
		Color(0.04, 0.17, 0.55),
		Color(0.95, 0.92, 0.82),
		CharacterNPC.Role.STUDENT,
		CharacterNPC.State.CALM,
		"Bro, this exhibition is louder than our annual day.",
		"Harshit! The door is blocked. Please get me out!",
		characters
	)
	kabir.set_meta("fire_state", CharacterNPC.State.TRAPPED)

	var riya := _create_story_character(
		"Riya",
		"Smart student trapped in library",
		Vector3(-52, 1.0, -1),
		Color(0.16, 0.26, 0.58),
		Color(0.95, 0.88, 0.76),
		CharacterNPC.Role.STUDENT,
		CharacterNPC.State.CALM,
		"I am checking the science references before judging starts.",
		"Nobody came for us. I thought everyone escaped.",
		characters
	)
	riya.can_be_carried = true
	riya.set_meta("fire_state", CharacterNPC.State.INJURED)

	_create_story_character(
		"Principal Meera Kapoor",
		"Principal coordinating evacuation",
		Vector3(-6, 1.0, 25),
		Color(0.45, 0.13, 0.18),
		Color(0.76, 0.52, 0.36),
		CharacterNPC.Role.PRINCIPAL,
		CharacterNPC.State.CALM,
		"Students, keep the assembly area clear and listen to your teachers.",
		"Harshit, guide anyone you find to the courtyard. Stay low in smoke.",
		characters
	)

	_create_story_character(
		"Security Guard Mahesh",
		"Experienced guard holding exits",
		Vector3(-22, 1.0, 68),
		Color(0.12, 0.24, 0.16),
		Color(0.58, 0.38, 0.24),
		CharacterNPC.Role.SECURITY,
		CharacterNPC.State.CALM,
		"ID cards ready. Move slowly through the gate.",
		"Beta, west exit is jammed. Try the academic block stairs.",
		characters
	)

	var ai := _create_resqtech_ai_presence(characters)
	story_characters.append(ai)


func _build_fireline_systems() -> void:
	var systems := Node3D.new()
	systems.name = "Dynamic Fire Spread, Smoke, Destruction and AI Navigation Systems"
	add_child(systems)
	for p in [Vector3(0, 2, -44), Vector3(-58, 3, -6), Vector3(58, 3.5, 2), Vector3(0, 3, 34), Vector3(-34, 1.8, 40)]:
		var light := OmniLight3D.new()
		light.name = "Flickering emergency fire light"
		light.position = p + Vector3(0, 2, 0)
		light.light_color = Color(1, 0.16, 0.04)
		light.omni_range = 20
		light.light_energy = 0
		light.shadow_enabled = true
		systems.add_child(light)
		fire_nodes.append(light)
		flicker_lights.append(light)
	_create_label_on_parent("FIRELINE SYSTEMS\nGPU fire, volumetric smoke, dynamic safe routes, destructible beats", Vector3(0, 7, 52), systems)


func _create_school_bus(pos: Vector3, parent: Node) -> void:
	var bus_mat := _mat("School bus yellow", Color(1.0, 0.68, 0.08), 0.42, 0.0)
	_create_box("SPS school bus body", pos, Vector3(10, 2.2, 3.1), bus_mat, parent)
	_create_box("Bus window strip", pos + Vector3(0, 0.6, -1.6), Vector3(8.8, 0.8, 0.12), mat_glass, parent)
	for x in [-3.2, 3.2]:
		for z in [-1.55, 1.55]:
			_create_cylinder("Bus wheel", pos + Vector3(x, -1.1, z), 0.55, 0.35, mat_black, parent)


func _create_staircase_tower(pos: Vector3, parent: Node) -> void:
	_create_box("Emergency staircase concrete tower", pos, Vector3(6, 17, 6), mat_sandstone, parent)
	for floor_index in range(ACADEMIC_FLOORS):
		_create_box("Fire exit door floor %d" % (floor_index + 1), Vector3(pos.x, 1.5 + floor_index * FLOOR_HEIGHT, pos.z + 3.05), Vector3(2, 2.4, 0.2), mat_green_route, parent)
		_create_interactable_box("Fire exit door interaction floor %d" % (floor_index + 1), Vector3(pos.x, 1.5 + floor_index * FLOOR_HEIGHT, pos.z + 3.0), Vector3(2.3, 2.6, 0.55), mat_green_route, "door", "Open emergency exit", parent)
		_create_box("Smoke-prone stair flight", Vector3(pos.x, 1.0 + floor_index * FLOOR_HEIGHT, pos.z), Vector3(4.5, 0.2, 3.5), mat_steel, parent)


func _create_flag(pos: Vector3, parent: Node) -> void:
	_create_cylinder("National flag pole", pos + Vector3(0, 3.2, 0), 0.08, 6.4, mat_steel, parent)
	_create_box("Indian flag saffron band", pos + Vector3(1.25, 5.6, 0), Vector3(2.5, 0.35, 0.08), _mat("flag_saffron", Color(1, 0.55, 0.12), 0.5, 0), parent)
	_create_box("Indian flag white band", pos + Vector3(1.25, 5.25, 0), Vector3(2.5, 0.35, 0.08), mat_white, parent)
	_create_box("Indian flag green band", pos + Vector3(1.25, 4.9, 0), Vector3(2.5, 0.35, 0.08), _mat("flag_green", Color(0.08, 0.46, 0.16), 0.5, 0), parent)


func _create_tree(pos: Vector3, parent: Node) -> void:
	_create_cylinder("Landscaped tree trunk", pos + Vector3(0, 1.2, 0), 0.28, 2.4, mat_wood, parent)
	var sphere := SphereMesh.new()
	sphere.radius = 1.8
	sphere.height = 3.2
	var crown := MeshInstance3D.new()
	crown.name = "Tree crown with animated wind target"
	crown.mesh = sphere
	crown.material_override = _mat("tree_crown", Color(0.07, 0.32, 0.12), 0.8, 0)
	crown.position = pos + Vector3(0, 3.0, 0)
	parent.add_child(crown)


func _create_npc(npc_name: String, pos: Vector3, color: Color, parent: Node) -> Node3D:
	var npc := Node3D.new()
	npc.name = npc_name
	npc.position = pos
	parent.add_child(npc)
	_create_cylinder("body", Vector3(0, 0.55, 0), 0.28, 1.1, _mat(npc_name + "_uniform", color, 0.55, 0), npc)
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.22
	head_mesh.height = 0.44
	var head := MeshInstance3D.new()
	head.name = "head"
	head.mesh = head_mesh
	head.material_override = _mat(npc_name + "_skin", Color(0.63, 0.42, 0.27), 0.65, 0)
	head.position = Vector3(0, 1.32, 0)
	npc.add_child(head)
	return npc


func _create_story_character(character_name: String, description: String, pos: Vector3, uniform_color: Color, skin_color: Color, role: int, initial_state: int, normal_dialogue: String, emergency_dialogue: String, parent: Node) -> CharacterNPC:
	var npc := CharacterNPC.new()
	npc.name = character_name.replace(" ", "_")
	npc.character_name = character_name
	npc.role = role
	npc.initial_state = initial_state
	npc.normal_dialogue = normal_dialogue
	npc.emergency_dialogue = emergency_dialogue
	npc.position = pos
	npc.set_meta("story_description", description)

	var capsule_shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.72
	capsule_shape.shape = capsule
	capsule_shape.position.y = 0.86
	npc.add_child(capsule_shape)

	_create_cylinder("Uniform body", Vector3(0, 0.85, 0), 0.32, 1.35, _mat(character_name + "_uniform", uniform_color, 0.62, 0.0), npc)
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.24
	head_mesh.height = 0.48
	var head := MeshInstance3D.new()
	head.name = "Expressive head"
	head.mesh = head_mesh
	head.material_override = _mat(character_name + "_skin", skin_color, 0.68, 0.0)
	head.position = Vector3(0, 1.62, 0)
	npc.add_child(head)

	_create_box("School ID card / role badge", Vector3(0, 1.12, -0.29), Vector3(0.28, 0.18, 0.03), mat_white, npc)
	var label := _label(character_name, Vector3(0, 2.25, 0), 18, Color.WHITE)
	label.name = "PromptLabel"
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	npc.add_child(label)
	parent.add_child(npc)
	story_characters.append(npc)
	return npc


func _create_resqtech_ai_presence(parent: Node) -> Node3D:
	var ai := CharacterNPC.new()
	ai.name = "ResQTech_AI_Assistant"
	ai.position = Vector3(0, 4.4, 27)
	ai.character_name = "ResQTech AI"
	ai.role = CharacterNPC.Role.AI_ASSISTANT
	ai.normal_dialogue = "ResQTech AI: Campus systems nominal. Monitoring exhibition crowd density."
	ai.emergency_dialogue = "ResQTech AI: Warning. Smoke density increasing. Alternate evacuation route recommended."
	_create_box("ResQTech holographic AI core", Vector3.ZERO, Vector3(3.2, 1.8, 0.18), mat_blue_emissive, ai)
	var label := _label("ResQTech AI\nemergency guidance online", Vector3(0, 1.8, 0), 18, Color(0.55, 0.9, 1.0))
	label.name = "PromptLabel"
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	ai.add_child(label)
	parent.add_child(ai)
	return ai


func _add_route_marker(pos: Vector3, parent: Node) -> void:
	var marker := _create_box("ResQTech dynamic AI safe route marker", pos, Vector3(2.4, 0.08, 2.4), mat_green_route, parent)
	fire_nodes.append(marker)
	route_nodes.append(marker)


func _create_fire_cluster(pos: Vector3, intensity: float, parent: Node) -> void:
	var fire := GPUParticles3D.new()
	fire.name = "Dynamic GPU fire spread emitter"
	fire.position = pos
	fire.amount = int(96 * intensity)
	fire.lifetime = 1.05
	fire.preprocess = 0.4
	fire.amount_ratio = 0.2
	fire.local_coords = false
	var process := ParticleProcessMaterial.new()
	process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	process.emission_box_extents = Vector3(1.6 * intensity, 0.25, 1.6 * intensity)
	process.direction = Vector3(0, 1, 0)
	process.spread = 34
	process.gravity = Vector3(0, 2.4, 0)
	process.initial_velocity_min = 1.5
	process.initial_velocity_max = 5.0
	process.scale_min = 0.35
	process.scale_max = 1.5 * intensity
	process.color = Color(1, 0.28, 0.02, 0.86)
	fire.process_material = process
	var quad := QuadMesh.new()
	quad.size = Vector2(1.1, 1.1)
	quad.material = mat_fire_emissive
	fire.draw_pass_1 = quad
	parent.add_child(fire)
	fire_nodes.append(fire)
	fire_emitters.append(fire)
	_create_hazard_area("Fire heat damage zone", pos + Vector3(0, 1.0, 0), Vector3(2.5 * intensity, 2.2, 2.5 * intensity), "fire_zone", "heat_level", clampf(0.35 + intensity * 0.25, 0.0, 1.0), parent)

	var sparks := GPUParticles3D.new()
	sparks.name = "Electrical sparks and ash"
	sparks.position = pos + Vector3(0, 1.2, 0)
	sparks.amount = int(70 * intensity)
	sparks.lifetime = 0.7
	sparks.amount_ratio = 0.25
	var spark_process := ParticleProcessMaterial.new()
	spark_process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	spark_process.emission_sphere_radius = 0.5 * intensity
	spark_process.direction = Vector3(0, 1, 0)
	spark_process.spread = 110
	spark_process.gravity = Vector3(0, -4, 0)
	spark_process.initial_velocity_min = 3
	spark_process.initial_velocity_max = 8
	spark_process.scale_min = 0.04
	spark_process.scale_max = 0.12
	spark_process.color = Color(1, 0.78, 0.16, 1)
	sparks.process_material = spark_process
	var spark_mesh := SphereMesh.new()
	spark_mesh.radius = 0.04
	spark_mesh.height = 0.08
	spark_mesh.material = mat_fire_emissive
	sparks.draw_pass_1 = spark_mesh
	parent.add_child(sparks)
	fire_nodes.append(sparks)


func _create_smoke_column(column_name: String, pos: Vector3, extents: Vector3, parent: Node) -> void:
	var smoke := GPUParticles3D.new()
	smoke.name = column_name
	smoke.position = pos
	smoke.amount = 180
	smoke.lifetime = 4.5
	smoke.preprocess = 1.5
	smoke.amount_ratio = 0.25
	smoke.local_coords = false
	var process := ParticleProcessMaterial.new()
	process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	process.emission_box_extents = extents
	process.direction = Vector3(0, 1, 0)
	process.spread = 24
	process.gravity = Vector3(0, 1.2, 0)
	process.initial_velocity_min = 0.4
	process.initial_velocity_max = 2.0
	process.scale_min = 1.0
	process.scale_max = 4.0
	process.color = Color(0.05, 0.05, 0.055, 0.42)
	smoke.process_material = process
	var quad := QuadMesh.new()
	quad.size = Vector2(2.8, 2.8)
	quad.material = mat_smoke
	smoke.draw_pass_1 = quad
	parent.add_child(smoke)
	fire_nodes.append(smoke)
	smoke_emitters.append(smoke)
	_create_hazard_area("Smoke inhalation zone", pos + Vector3(0, extents.y * 0.35, 0), extents * 1.15, "smoke_zone", "smoke_density", clampf(extents.y / 10.0, 0.35, 0.95), parent)


func _create_hazard_area(area_name: String, pos: Vector3, size: Vector3, group_name: String, value_key: String, value: float, parent: Node) -> Area3D:
	var area := Area3D.new()
	area.name = area_name
	area.position = pos
	area.add_to_group(group_name)
	area.set_meta(value_key, value)
	area.collision_layer = 1
	area.collision_mask = 0
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	area.add_child(shape)
	parent.add_child(area)
	fire_nodes.append(area)
	return area


func _create_interactable_box(area_name: String, pos: Vector3, size: Vector3, material: Material, interaction_type: String, interaction_label: String, parent: Node) -> Area3D:
	var area := Area3D.new()
	area.name = area_name
	area.position = pos
	area.add_to_group("interactable")
	area.set_meta("interaction_type", interaction_type)
	area.set_meta("interaction_label", interaction_label)
	area.collision_layer = 1
	area.collision_mask = 0
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	area.add_child(shape)
	var visual := _create_box(area_name + " visual", Vector3.ZERO, size * 0.72, material, area)
	visual.transparency = 0.35
	parent.add_child(area)
	return area


func _create_burnable_box(burnable_name: String, pos: Vector3, size: Vector3, material_type: int, room_id: String, object_size: float, is_structural: bool, parent: Node) -> BurnableObject:
	var burnable := BurnableObject.new()
	burnable.name = burnable_name
	burnable.position = pos
	burnable.material_type = material_type
	burnable.room_id = room_id
	burnable.object_size = object_size
	burnable.is_structural = is_structural
	burnable.scan_radius = maxf(size.x, maxf(size.y, size.z)) * 0.65
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	burnable.add_child(shape)
	var material := _material_for_burnable(material_type)
	_create_box(burnable_name + " visual", Vector3.ZERO, size, material, burnable)
	parent.add_child(burnable)
	if fire_manager:
		fire_manager.register_burnable(burnable)
	return burnable


func _material_for_burnable(material_type: int) -> Material:
	match material_type:
		BurnableObject.MaterialType.PAPER:
			return _mat("Burnable paper/books", Color(0.86, 0.78, 0.58), 0.82, 0.0)
		BurnableObject.MaterialType.WOOD:
			return mat_wood
		BurnableObject.MaterialType.CURTAIN:
			return _mat("Burnable red curtain fabric", Color(0.5, 0.02, 0.018), 0.9, 0.0)
		BurnableObject.MaterialType.PLASTIC:
			return _mat("Burnable plastic smoke source", Color(0.12, 0.12, 0.15), 0.55, 0.0)
		BurnableObject.MaterialType.ELECTRICAL:
			return mat_black
		BurnableObject.MaterialType.CEILING_PANEL:
			return _mat("Burnable acoustic ceiling panel", Color(0.58, 0.56, 0.50), 0.72, 0.0)
		BurnableObject.MaterialType.CHEMICAL:
			return _mat("Volatile chemical hazard", Color(0.08, 0.85, 0.35), 0.3, 0.0, Color(0.0, 1.2, 0.25))
		_:
			return mat_cream


func _create_box(node_name: String, pos: Vector3, size: Vector3, material: Material, parent: Node = null) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var node := MeshInstance3D.new()
	node.name = node_name
	node.mesh = mesh
	node.material_override = material
	node.position = pos
	var owner_node: Node = parent if parent != null else self
	owner_node.add_child(node)
	return node


func _create_cylinder(node_name: String, pos: Vector3, radius: float, height: float, material: Material, parent: Node = null) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 24
	var node := MeshInstance3D.new()
	node.name = node_name
	node.mesh = mesh
	node.material_override = material
	node.position = pos
	var owner_node: Node = parent if parent != null else self
	owner_node.add_child(node)
	return node


func _create_collision_box(collision_name: String, pos: Vector3, size: Vector3) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = collision_name
	body.position = pos
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	body.add_child(shape)
	add_child(body)
	return body


func _spawn_player_harshit() -> void:
	player = PLAYER_SCENE.instantiate() as CharacterBody3D
	player.name = "Harshit_PlayerCharacter"
	player.position = Vector3(0, 1.0, 48)
	add_child(player)


func _build_story_director() -> void:
	story_director = STORY_DIRECTOR_SCRIPT.new() as GameplayStoryDirector
	story_director.name = "GameplayStoryDirector"
	add_child(story_director)
	story_director.setup(self, player)


func _on_fire_structural_collapse_requested(pos: Vector3, source: BurnableObject) -> void:
	var slab := RigidBody3D.new()
	slab.name = "Fire-driven structural collapse debris from " + String(source.name)
	slab.position = pos + Vector3(0, -0.35, 0)
	slab.mass = 12.0
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.8, 0.35, 2.0)
	collision.shape = shape
	slab.add_child(collision)
	var visual := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = shape.size
	visual.mesh = mesh
	visual.material_override = mat_black
	slab.add_child(visual)
	add_child(slab)
	slab.apply_impulse(Vector3(randf_range(-2, 2), -3.0, randf_range(-2, 2)))


func _label(text: String, pos: Vector3, font_size: int, color: Color) -> Label3D:
	var label := Label3D.new()
	label.text = text
	label.position = pos
	label.font_size = font_size
	label.modulate = color
	label.outline_size = 6
	label.outline_modulate = Color(0, 0, 0, 0.75)
	return label


func _create_label_on_parent(text: String, pos: Vector3, parent: Node) -> void:
	parent.add_child(_label(text, pos, 18, Color.WHITE))


func _apply_phase(next_phase: int) -> void:
	phase = next_phase
	var is_fire := phase == DisasterPhase.FIRE
	if fire_manager:
		fire_manager.visible = is_fire
		fire_manager.set_process(is_fire)
	if smoke_manager:
		smoke_manager.visible = is_fire
		smoke_manager.set_process(is_fire)
	for node in fire_nodes:
		if is_instance_valid(node):
			node.visible = is_fire
			if node is Area3D:
				var hazard_area := node as Area3D
				hazard_area.monitoring = is_fire
				hazard_area.monitorable = is_fire
	for node in normal_nodes:
		if is_instance_valid(node):
			node.visible = not is_fire
	for light in flicker_lights:
		light.light_energy = 3.5 if is_fire else 0.0
	for emitter in fire_emitters:
		emitter.emitting = is_fire
	for emitter in smoke_emitters:
		emitter.emitting = is_fire
	if is_fire and fire_manager and not fire_ignited:
		fire_ignited = true
		fire_manager.ignite_nearest(Vector3(3, 1.0, -44), 8.0, BurnableObject.MaterialType.CHEMICAL)
		fire_manager.ignite_nearest(Vector3(5.8, 1.3, -46), 5.0, BurnableObject.MaterialType.ELECTRICAL)
		if smoke_manager:
			smoke_manager.open_ventilation("ventilation_network", 0.25)
	elif not is_fire:
		fire_ignited = false
	if phase_label:
		phase_label.text = "PHASE: FIRELINE DISASTER\nSmoke, panic routes, rescue objectives active. Press F for normal phase." if is_fire else "PHASE: PEACEFUL SCHOOL LIFE\nPress F to trigger FIRELINE disaster phase"
	if ai_label:
		ai_label.text = "ResQTech AI: Warning. Smoke density increasing. Staircase A compromised. Alternate route highlighted." if is_fire else "ResQTech AI: Campus systems nominal. Exhibition crowd density rising."
	_apply_story_character_phase(is_fire)
	var env := get_viewport().world_3d.environment
	if env:
		env.volumetric_fog_density = 0.075 if is_fire else 0.012
		env.volumetric_fog_albedo = Color(0.18, 0.16, 0.14) if is_fire else Color(0.78, 0.82, 0.86)
		env.adjustment_saturation = 0.82 if is_fire else 1.05
		env.adjustment_contrast = 1.28 if is_fire else 1.08
	if story_director:
		if is_fire:
			story_director.notify_fire_phase_started()
		else:
			story_director.notify_fire_phase_ended()


func _apply_story_character_phase(is_fire: bool) -> void:
	for character in story_characters:
		if not is_instance_valid(character) or not character is CharacterNPC:
			continue
		var npc := character as CharacterNPC
		if is_fire:
			if npc.has_meta("fire_state"):
				npc.set_story_state(int(npc.get_meta("fire_state")))
			else:
				npc.set_emergency_mode(true)
		else:
			npc.target_player = null
			npc.set_story_state(CharacterNPC.State.CALM)


func _on_smoke_guidance_requested(message: String) -> void:
	if ai_label:
		ai_label.text = message
