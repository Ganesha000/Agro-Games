class_name ExplosionSequence
extends Node3D

signal explosion_cinematic(position: Vector3, strength: float)

@export var shockwave_radius := 18.0
@export var slow_motion_time := 0.18
@export var slow_motion_scale := 0.35


func trigger(world_position: Vector3, strength: float) -> void:
	global_position = world_position
	explosion_cinematic.emit(world_position, strength)
	Engine.time_scale = slow_motion_scale
	await get_tree().create_timer(slow_motion_time, true, false, true).timeout
	Engine.time_scale = 1.0
	for npc in get_tree().get_nodes_in_group("npc"):
		if npc.has_method("receive_social_panic"):
			npc.call("receive_social_panic", clampf(strength / maxf(1.0, (npc as Node3D).global_position.distance_to(world_position)), 0.0, 1.0))
	for drone in get_tree().get_nodes_in_group("rescue_drone"):
		if drone.has_method("apply_explosion_shock"):
			drone.call("apply_explosion_shock", strength)
