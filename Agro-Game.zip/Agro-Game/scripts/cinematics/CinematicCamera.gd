class_name CinematicCamera
extends Camera3D

signal shot_finished

@export var default_blend := 1.2
@export var shake_decay := 3.5

var shake := 0.0
var tween: Tween


func play_shot(target_transform: Transform3D, duration: float = -1.0) -> void:
	if tween:
		tween.kill()
	tween = create_tween()
	var blend := default_blend if duration < 0.0 else duration
	tween.tween_property(self, "global_transform", target_transform, blend).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.finished.connect(func() -> void: shot_finished.emit())


func add_shake(amount: float) -> void:
	shake = maxf(shake, amount)


func _process(delta: float) -> void:
	if shake <= 0.0:
		h_offset = 0.0
		v_offset = 0.0
		return
	h_offset = randf_range(-shake, shake)
	v_offset = randf_range(-shake, shake)
	shake = move_toward(shake, 0.0, shake_decay * delta)
