class_name CutsceneManager
extends Node3D

signal cutscene_started(id: String)
signal cutscene_finished(id: String)

@export var gameplay_camera_group := "gameplay_camera"
@export var letterbox_path: NodePath

var active := false
var player: Node

@onready var cinematic_camera: CinematicCamera = get_node_or_null("CinematicCamera") as CinematicCamera
@onready var scripted_events: ScriptedEventSystem = get_node_or_null("ScriptedEventSystem") as ScriptedEventSystem
@onready var explosion_sequence: ExplosionSequence = get_node_or_null("ExplosionSequence") as ExplosionSequence
@onready var ending_manager: EndingManager = get_node_or_null("EndingManager") as EndingManager


func _ready() -> void:
	add_to_group("cutscene_manager")
	_ensure_children()


func play_cutscene(id: String, shots: Array[Dictionary], interactive := false) -> void:
	active = true
	cutscene_started.emit(id)
	_set_player_control(interactive)
	cinematic_camera.current = true
	for shot in shots:
		if shot.has("event_commands"):
			scripted_events.play_event(String(shot.get("event_id", id + "_event")), shot["event_commands"])
		if shot.has("transform"):
			cinematic_camera.play_shot(shot["transform"], float(shot.get("duration", cinematic_camera.default_blend)))
			await cinematic_camera.shot_finished
		if float(shot.get("hold", 0.0)) > 0.0:
			await get_tree().create_timer(float(shot["hold"])).timeout
	_finish_cutscene(id)


func trigger_fire_ignition(world_position: Vector3) -> void:
	var commands: Array[Dictionary] = [
		{"type": "emit", "group": "fire_manager", "method": "ignite_nearest", "args": [world_position, 8.0]},
		{"type": "emit", "group": "resqtech_ai", "method": "report_environment_event", "args": ["fire_ignition", world_position, 0.7]}
	]
	scripted_events.play_event("fire_ignition", commands)


func trigger_explosion(world_position: Vector3, strength: float) -> void:
	explosion_sequence.trigger(world_position, strength)
	for camera in get_tree().get_nodes_in_group("cinematic_camera"):
		if camera.has_method("add_shake"):
			camera.call("add_shake", strength * 0.08)


func _finish_cutscene(id: String) -> void:
	active = false
	_set_player_control(true)
	for camera in get_tree().get_nodes_in_group(gameplay_camera_group):
		if camera is Camera3D:
			(camera as Camera3D).current = true
			break
	cutscene_finished.emit(id)


func _set_player_control(enabled: bool) -> void:
	var players := get_tree().get_nodes_in_group("player")
	if not players.is_empty() and players[0].has_method("set_control_enabled"):
		players[0].call("set_control_enabled", enabled)


func _ensure_children() -> void:
	if not cinematic_camera:
		cinematic_camera = CinematicCamera.new()
		cinematic_camera.name = "CinematicCamera"
		cinematic_camera.add_to_group("cinematic_camera")
		add_child(cinematic_camera)
	if not scripted_events:
		scripted_events = ScriptedEventSystem.new()
		scripted_events.name = "ScriptedEventSystem"
		add_child(scripted_events)
	if not explosion_sequence:
		explosion_sequence = ExplosionSequence.new()
		explosion_sequence.name = "ExplosionSequence"
		add_child(explosion_sequence)
	if not ending_manager:
		ending_manager = EndingManager.new()
		ending_manager.name = "EndingManager"
		add_child(ending_manager)
