class_name ScriptedEventSystem
extends Node3D

signal scripted_event_started(id: String)
signal scripted_event_finished(id: String)


func play_event(id: String, commands: Array[Dictionary]) -> void:
	scripted_event_started.emit(id)
	for command in commands:
		await _run_command(command)
	scripted_event_finished.emit(id)


func _run_command(command: Dictionary) -> void:
	match String(command.get("type", "")):
		"wait":
			await get_tree().create_timer(float(command.get("duration", 1.0))).timeout
		"call":
			var node := get_node_or_null(NodePath(command.get("path", "")))
			if node and node.has_method(String(command.get("method", ""))):
				node.callv(String(command.get("method", "")), command.get("args", []))
		"emit":
			var group := String(command.get("group", ""))
			for node in get_tree().get_nodes_in_group(group):
				if node.has_method(String(command.get("method", ""))):
					node.callv(String(command.get("method", "")), command.get("args", []))
