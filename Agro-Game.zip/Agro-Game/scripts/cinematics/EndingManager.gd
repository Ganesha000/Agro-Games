class_name EndingManager
extends Node

signal ending_selected(ending_id: String)

var branching: BranchingChoiceSystem


func _ready() -> void:
	var missions := get_tree().get_nodes_in_group("mission_manager")
	if not missions.is_empty() and missions[0].has_node("BranchingChoiceSystem"):
		branching = missions[0].get_node("BranchingChoiceSystem") as BranchingChoiceSystem


func play_finale() -> String:
	var ending: String = branching.ending_type() if branching else "partial_survival"
	ending_selected.emit(ending)
	return ending
