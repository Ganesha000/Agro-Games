class_name ObjectivePanel
extends Control

var objectives: Array = []


func set_objectives(next_objectives: Array) -> void:
	objectives = next_objectives
	queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.01, 0.04, 0.07, 0.42))
	var y := 22.0
	draw_string(get_theme_default_font(), Vector2(12, y), "OBJECTIVES", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(0.5, 0.9, 1.0))
	y += 22.0
	for item in objectives:
		var text := String(item.get("text", item.get("title", "")))
		var priority := float(item.get("priority", 0.5))
		draw_circle(Vector2(16, y - 5), 4.0, Color(1.0, lerpf(0.22, 0.85, 1.0 - priority), 0.12))
		draw_string(get_theme_default_font(), Vector2(28, y), text, HORIZONTAL_ALIGNMENT_LEFT, size.x - 36, 13, Color.WHITE)
		y += 24.0
