class_name DroneHUD
extends Control

var battery := 1.0
var signal_strength := 1.0
var thermal_enabled := false
var markers: Array[Dictionary] = []


func update_drone_status(next_battery: float, next_signal: float, thermal: bool) -> void:
	battery = next_battery
	signal_strength = next_signal
	thermal_enabled = thermal
	queue_redraw()


func add_marker(screen_position: Vector2, label: String, priority: float) -> void:
	markers.append({"pos": screen_position, "label": label, "priority": priority, "time": 5.0})


func _process(delta: float) -> void:
	for marker in markers:
		marker["time"] = float(marker["time"]) - delta
	markers = markers.filter(func(marker: Dictionary) -> bool: return float(marker["time"]) > 0.0)
	queue_redraw()


func _draw() -> void:
	draw_string(get_theme_default_font(), Vector2(16, 24), "DRONE", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.45, 0.95, 1.0))
	draw_string(get_theme_default_font(), Vector2(16, 44), "BAT " + str(roundi(battery * 100.0)) + "%", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	draw_string(get_theme_default_font(), Vector2(16, 62), "SIG " + str(roundi(signal_strength * 100.0)) + "%", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	if thermal_enabled:
		draw_rect(Rect2(Vector2.ZERO, size), Color(1.0, 0.22, 0.02, 0.07), false, 2.0)
	for marker in markers:
		var p := marker["pos"] as Vector2
		draw_circle(p, 8.0, Color(1.0, 0.72, 0.08, 0.85))
		draw_string(get_theme_default_font(), p + Vector2(12, -8), String(marker["label"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color.WHITE)
