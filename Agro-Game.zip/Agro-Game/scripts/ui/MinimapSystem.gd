class_name MinimapSystem
extends Control

@export var world_scale := 0.12
@export var player_group := "player"

var danger_points: Array[Dictionary] = []
var survivor_points: Array[Dictionary] = []
var route := PackedVector3Array()


func set_route(points: PackedVector3Array, _danger: float = 0.0) -> void:
	route = points
	queue_redraw()


func set_danger_points(points: Array[Dictionary]) -> void:
	danger_points = points
	queue_redraw()


func mark_survivor(world_position: Vector3, priority: float) -> void:
	survivor_points.append({"position": world_position, "priority": priority, "time": 8.0})
	queue_redraw()


func _process(delta: float) -> void:
	for item in survivor_points:
		item["time"] = float(item["time"]) - delta
	survivor_points = survivor_points.filter(func(item: Dictionary) -> bool: return float(item["time"]) > 0.0)


func _draw() -> void:
	var center := size * 0.5
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.01, 0.04, 0.06, 0.58))
	for i in range(route.size() - 1):
		draw_line(center + _xz(route[i]) * world_scale, center + _xz(route[i + 1]) * world_scale, Color(0.1, 0.9, 1.0, 0.9), 2.0)
	for survivor in survivor_points:
		var p := center + _xz(survivor["position"]) * world_scale
		draw_circle(p, lerpf(3.0, 7.0, float(survivor["priority"])), Color(1.0, 0.82, 0.16))
	var players := get_tree().get_nodes_in_group(player_group)
	if not players.is_empty() and players[0] is Node3D:
		draw_circle(center + _xz((players[0] as Node3D).global_position) * world_scale, 5.0, Color(0.35, 1.0, 0.85))


func _xz(v: Vector3) -> Vector2:
	return Vector2(v.x, v.z)
