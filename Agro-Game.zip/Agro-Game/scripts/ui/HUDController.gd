class_name HUDController
extends CanvasLayer

@onready var health_ui: HealthUI = get_node_or_null("HealthUI") as HealthUI
@onready var minimap: MinimapSystem = get_node_or_null("MinimapSystem") as MinimapSystem
@onready var warnings: WarningAlertSystem = get_node_or_null("WarningAlertSystem") as WarningAlertSystem
@onready var objectives: ObjectivePanel = get_node_or_null("ObjectivePanel") as ObjectivePanel
@onready var drone_hud: DroneHUD = get_node_or_null("DroneHUD") as DroneHUD


func _ready() -> void:
	add_to_group("hud")
	_ensure_children()
	_bind_systems()


func update_player_vitals(health: float, stamina: float, oxygen: float, smoke: float) -> void:
	health_ui.update_vitals(health, stamina, oxygen, smoke)
	if oxygen < 0.25:
		warnings.push_alert("Oxygen Levels Falling", 0.88)
	if smoke > 0.72:
		warnings.push_alert("Smoke Density Critical", 0.82)


func push_alert(text: String, urgency: float = 0.5) -> void:
	warnings.push_alert(text, urgency)


func _bind_systems() -> void:
	var ai_nodes := get_tree().get_nodes_in_group("resqtech_ai")
	if not ai_nodes.is_empty():
		var ai := ai_nodes[0]
		if ai.has_signal("hud_alert"):
			ai.connect("hud_alert", push_alert)
		if ai.has_signal("survivor_priority_updated"):
			ai.connect("survivor_priority_updated", _on_survivor_priority)
	var route_nodes := get_tree().get_nodes_in_group("safe_route_system")
	if not route_nodes.is_empty() and route_nodes[0].has_signal("safe_route_updated"):
		route_nodes[0].connect("safe_route_updated", minimap.set_route)
	var mission_nodes := get_tree().get_nodes_in_group("mission_manager")
	if not mission_nodes.is_empty():
		var mission := mission_nodes[0]
		if mission.has_method("active_missions"):
			objectives.set_objectives(mission.call("active_missions"))


func _on_survivor_priority(npc: Node3D, priority: float) -> void:
	minimap.mark_survivor(npc.global_position, priority)


func _ensure_children() -> void:
	if not health_ui:
		health_ui = HealthUI.new()
		health_ui.name = "HealthUI"
		add_child(health_ui)
	if not minimap:
		minimap = MinimapSystem.new()
		minimap.name = "MinimapSystem"
		minimap.position = Vector2(20, 100)
		minimap.size = Vector2(180, 180)
		add_child(minimap)
	if not warnings:
		warnings = WarningAlertSystem.new()
		warnings.name = "WarningAlertSystem"
		warnings.position = Vector2(260, 24)
		warnings.size = Vector2(420, 180)
		add_child(warnings)
	if not objectives:
		objectives = ObjectivePanel.new()
		objectives.name = "ObjectivePanel"
		objectives.position = Vector2(20, 300)
		objectives.size = Vector2(340, 170)
		add_child(objectives)
	if not drone_hud:
		drone_hud = DroneHUD.new()
		drone_hud.name = "DroneHUD"
		drone_hud.visible = false
		add_child(drone_hud)
