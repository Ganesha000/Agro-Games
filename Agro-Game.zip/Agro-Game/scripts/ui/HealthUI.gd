class_name HealthUI
extends Control

@export var health := 1.0
@export var stamina := 1.0
@export var oxygen := 1.0
@export var smoke := 0.0


func update_vitals(next_health: float, next_stamina: float, next_oxygen: float, next_smoke: float) -> void:
	health = clampf(next_health, 0.0, 1.0)
	stamina = clampf(next_stamina, 0.0, 1.0)
	oxygen = clampf(next_oxygen, 0.0, 1.0)
	smoke = clampf(next_smoke, 0.0, 1.0)
	queue_redraw()


func _draw() -> void:
	_draw_bar(Vector2(0, 0), "HEALTH", health, Color(0.95, 0.12, 0.09))
	_draw_bar(Vector2(0, 26), "STAMINA", stamina, Color(0.1, 0.75, 0.95))
	_draw_bar(Vector2(0, 52), "OXYGEN", oxygen, Color(0.35, 0.95, 0.76))
	if oxygen < 0.28 or smoke > 0.7:
		draw_rect(Rect2(Vector2.ZERO, size), Color(1, 0, 0, 0.08 + abs(sin(Time.get_ticks_msec() * 0.012)) * 0.05), false, 3.0)


func _draw_bar(pos: Vector2, label: String, value: float, color: Color) -> void:
	draw_string(get_theme_default_font(), pos + Vector2(0, 14), label, HORIZONTAL_ALIGNMENT_LEFT, 82, 12, Color(0.75, 0.92, 1.0))
	draw_rect(Rect2(pos + Vector2(88, 3), Vector2(170, 12)), Color(0.02, 0.06, 0.08, 0.75))
	draw_rect(Rect2(pos + Vector2(88, 3), Vector2(170 * value, 12)), color)
