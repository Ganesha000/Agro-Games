class_name WarningAlertSystem
extends Control

signal alert_displayed(text: String, urgency: float)

@export var max_alerts := 5
@export var alert_lifetime := 4.0

var alerts: Array[Dictionary] = []


func push_alert(text: String, urgency: float = 0.5) -> void:
	alerts.append({"text": text, "urgency": urgency, "time": alert_lifetime})
	if alerts.size() > max_alerts:
		alerts.pop_front()
	alert_displayed.emit(text, urgency)
	queue_redraw()


func _process(delta: float) -> void:
	for alert in alerts:
		alert["time"] = float(alert["time"]) - delta
	alerts = alerts.filter(func(item: Dictionary) -> bool: return float(item["time"]) > 0.0)
	queue_redraw()


func _draw() -> void:
	var y := 0.0
	for alert in alerts:
		var urgency := float(alert["urgency"])
		var color := Color(1.0, lerpf(0.15, 0.85, 1.0 - urgency), 0.08, 0.75)
		draw_rect(Rect2(Vector2(0, y), Vector2(size.x, 28)), color)
		draw_string(get_theme_default_font(), Vector2(12, y + 19), String(alert["text"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
		y += 32.0
