class_name CharacterNPC
extends CharacterBody3D

enum Role { STUDENT, PRINCIPAL, SECURITY, AI_ASSISTANT }
enum State { CALM, PANICKING, TRAPPED, INJURED, FOLLOWING, RESCUED }

@export var character_name := "Character"
@export var role: Role = Role.STUDENT
@export var initial_state: State = State.CALM
@export_multiline var normal_dialogue := ""
@export_multiline var emergency_dialogue := ""
@export var can_follow_player := true
@export var can_be_carried := false
@export var walk_speed := 2.4
@export var panic_speed := 4.0
@export var follow_distance := 2.4
@export var gravity := 18.0

var state: State
var target_player: Node3D
var stress := 0.0
var rescue_value := 1

@onready var prompt_label: Label3D = $PromptLabel


func _ready() -> void:
	state = initial_state
	add_to_group("story_character")
	add_to_group("interactable")
	set_meta("interaction_type", _interaction_type_for_state())
	set_meta("interaction_label", _interaction_label_for_state())
	_update_prompt()


func _physics_process(delta: float) -> void:
	if role == Role.AI_ASSISTANT:
		return

	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1

	if state == State.FOLLOWING and is_instance_valid(target_player):
		var to_player := target_player.global_position - global_position
		to_player.y = 0.0
		if to_player.length() > follow_distance:
			var speed: float = panic_speed if stress > 0.65 else walk_speed
			var direction := to_player.normalized()
			velocity.x = move_toward(velocity.x, direction.x * speed, speed * 5.0 * delta)
			velocity.z = move_toward(velocity.z, direction.z * speed, speed * 5.0 * delta)
			look_at(Vector3(target_player.global_position.x, global_position.y, target_player.global_position.z), Vector3.UP)
		else:
			velocity.x = move_toward(velocity.x, 0.0, walk_speed * 5.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, walk_speed * 5.0 * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, walk_speed * 4.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, walk_speed * 4.0 * delta)

	move_and_slide()


func interact(player: Node) -> void:
	if role == Role.AI_ASSISTANT:
		_announce_to_player(player)
		return

	match state:
		State.TRAPPED:
			state = State.FOLLOWING
			target_player = player as Node3D
			stress = 0.55
		State.INJURED:
			if can_be_carried and player.has_method("set_carrying_npc"):
				player.call("set_carrying_npc", true)
				state = State.RESCUED
			else:
				state = State.FOLLOWING
				target_player = player as Node3D
		State.PANICKING:
			state = State.FOLLOWING if can_follow_player else State.CALM
			target_player = player as Node3D
			stress = 0.35
		State.CALM:
			if can_follow_player:
				state = State.FOLLOWING
				target_player = player as Node3D
		State.FOLLOWING:
			state = State.CALM
			target_player = null
		State.RESCUED:
			pass

	set_meta("interaction_type", _interaction_type_for_state())
	set_meta("interaction_label", _interaction_label_for_state())
	_update_prompt()


func set_emergency_mode(enabled: bool) -> void:
	if enabled and state == State.CALM:
		state = State.PANICKING
		stress = 0.8
	elif not enabled and state == State.PANICKING:
		state = State.CALM
		stress = 0.0
	set_meta("interaction_type", _interaction_type_for_state())
	set_meta("interaction_label", _interaction_label_for_state())
	_update_prompt()


func set_story_state(next_state: int) -> void:
	state = next_state
	set_meta("interaction_type", _interaction_type_for_state())
	set_meta("interaction_label", _interaction_label_for_state())
	_update_prompt()


func mark_trapped() -> void:
	state = State.TRAPPED
	set_meta("interaction_type", _interaction_type_for_state())
	set_meta("interaction_label", _interaction_label_for_state())
	_update_prompt()


func mark_injured() -> void:
	state = State.INJURED
	can_be_carried = true
	set_meta("interaction_type", _interaction_type_for_state())
	set_meta("interaction_label", _interaction_label_for_state())
	_update_prompt()


func _interaction_type_for_state() -> String:
	match state:
		State.INJURED:
			return "carry_npc" if can_be_carried else "revive_npc"
		State.TRAPPED:
			return "free_trapped_npc"
		State.PANICKING:
			return "calm_npc"
		State.FOLLOWING:
			return "guide_npc"
		State.RESCUED:
			return "rescued_npc"
		_:
			return "talk"


func _interaction_label_for_state() -> String:
	match state:
		State.INJURED:
			return "Help " + character_name
		State.TRAPPED:
			return "Free " + character_name
		State.PANICKING:
			return "Calm " + character_name
		State.FOLLOWING:
			return "Ask " + character_name + " to wait"
		State.RESCUED:
			return character_name + " is safe"
		_:
			return "Talk to " + character_name


func _update_prompt() -> void:
	if prompt_label:
		prompt_label.text = character_name + "\n" + _state_text()


func _state_text() -> String:
	match state:
		State.PANICKING:
			return "panicking"
		State.TRAPPED:
			return "trapped"
		State.INJURED:
			return "injured"
		State.FOLLOWING:
			return "following"
		State.RESCUED:
			return "rescued"
		_:
			return "calm"


func _announce_to_player(player: Node) -> void:
	if player and player.has_node("Neck/PromptLabel"):
		var label := player.get_node("Neck/PromptLabel") as Label3D
		label.visible = true
		label.text = emergency_dialogue if emergency_dialogue != "" else normal_dialogue
