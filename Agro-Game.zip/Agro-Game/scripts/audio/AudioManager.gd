class_name AudioManager
extends Node

signal priority_sound_requested(kind: String, position: Vector3, intensity: float)

@export var master_intensity := 0.0
@export var voice_priority_ducking := 0.65

@onready var music: DynamicMusicSystem = get_node_or_null("DynamicMusicSystem") as DynamicMusicSystem
@onready var ambience: AmbientAudioSystem = get_node_or_null("AmbientAudioSystem") as AmbientAudioSystem
@onready var announcements: EmergencyAnnouncementSystem = get_node_or_null("EmergencyAnnouncementSystem") as EmergencyAnnouncementSystem


func _ready() -> void:
	add_to_group("audio_manager")
	_ensure_children()
	if announcements:
		announcements.announcement_started.connect(_on_announcement)


func update_mix(delta: float, danger: float, mission_urgency: float, rescue_success: float) -> void:
	master_intensity = lerpf(master_intensity, maxf(danger, mission_urgency), delta * 2.0)
	music.update_music(delta, danger, mission_urgency, rescue_success)


func play_positional_event(kind: String, world_position: Vector3, intensity: float) -> void:
	priority_sound_requested.emit(kind, world_position, intensity)


func apply_temporary_deafness(strength: float) -> void:
	AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Master"), linear_to_db(clampf(1.0 - strength * 0.7, 0.18, 1.0)))
	await get_tree().create_timer(1.2).timeout
	AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Master"), 0.0)


func _on_announcement(text: String, urgency: float) -> void:
	priority_sound_requested.emit("ai_voice:" + text, Vector3.ZERO, urgency)


func _ensure_children() -> void:
	if not music:
		music = DynamicMusicSystem.new()
		music.name = "DynamicMusicSystem"
		add_child(music)
	if not ambience:
		ambience = AmbientAudioSystem.new()
		ambience.name = "AmbientAudioSystem"
		add_child(ambience)
