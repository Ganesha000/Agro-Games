class_name DynamicMusicSystem
extends Node

signal music_phase_changed(phase: int)

enum MusicPhase { CALM_INTRO, RISING_TENSION, PANIC, CRITICAL_DANGER, EMOTIONAL_RESCUE, FINAL_ESCAPE }

@export var crossfade_speed := 0.8

var phase: int = MusicPhase.CALM_INTRO
var danger := 0.0
var urgency := 0.0


func update_music(delta: float, next_danger: float, next_urgency: float, rescue_success: float) -> void:
	danger = lerpf(danger, next_danger, delta * crossfade_speed)
	urgency = lerpf(urgency, next_urgency, delta * crossfade_speed)
	var next_phase := phase
	if urgency > 0.88:
		next_phase = MusicPhase.FINAL_ESCAPE
	elif rescue_success > 0.65 and danger < 0.7:
		next_phase = MusicPhase.EMOTIONAL_RESCUE
	elif danger > 0.82:
		next_phase = MusicPhase.CRITICAL_DANGER
	elif danger > 0.55:
		next_phase = MusicPhase.PANIC
	elif danger > 0.25:
		next_phase = MusicPhase.RISING_TENSION
	else:
		next_phase = MusicPhase.CALM_INTRO
	if next_phase != phase:
		phase = next_phase
		music_phase_changed.emit(phase)
