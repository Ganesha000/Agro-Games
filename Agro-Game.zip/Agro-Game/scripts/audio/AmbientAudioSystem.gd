class_name AmbientAudioSystem
extends Node3D

signal ambience_changed(intensity: float)

@export var update_interval := 0.4

var tick := 0.0
var intensity := 0.0


func _process(delta: float) -> void:
	tick -= delta
	if tick <= 0.0:
		tick = update_interval
		_update_ambience()


func _update_ambience() -> void:
	var npc_panic := 0.0
	var count := 0
	for npc in get_tree().get_nodes_in_group("npc"):
		if npc.get("panic_system"):
			npc_panic += npc.panic_system.panic
			count += 1
	var average_panic := npc_panic / maxf(1.0, count)
	intensity = clampf(average_panic, 0.0, 1.0)
	ambience_changed.emit(intensity)
