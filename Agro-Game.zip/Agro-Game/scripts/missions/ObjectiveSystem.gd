class_name ObjectiveSystem
extends Node

signal objective_added(id: String, text: String, priority: float)
signal objective_updated(id: String, progress: float)
signal objective_completed(id: String)
signal objective_failed(id: String)

enum ObjectiveState { INACTIVE, ACTIVE, COMPLETED, FAILED, OPTIONAL, HIDDEN }

var objectives: Dictionary = {}


func add_objective(id: String, text: String, priority: float = 0.5, optional := false, hidden := false) -> void:
	objectives[id] = {"text": text, "priority": priority, "progress": 0.0, "state": ObjectiveState.HIDDEN if hidden else ObjectiveState.OPTIONAL if optional else ObjectiveState.ACTIVE}
	objective_added.emit(id, text, priority)


func update_progress(id: String, progress: float) -> void:
	if not objectives.has(id):
		return
	var data: Dictionary = objectives[id] as Dictionary
	data["progress"] = clampf(progress, 0.0, 1.0)
	objectives[id] = data
	objective_updated.emit(id, data["progress"])
	if progress >= 1.0:
		complete_objective(id)


func complete_objective(id: String) -> void:
	if objectives.has(id):
		var data: Dictionary = objectives[id] as Dictionary
		data["state"] = ObjectiveState.COMPLETED
		objectives[id] = data
		objective_completed.emit(id)


func fail_objective(id: String) -> void:
	if objectives.has(id):
		var data: Dictionary = objectives[id] as Dictionary
		data["state"] = ObjectiveState.FAILED
		objectives[id] = data
		objective_failed.emit(id)


func active_objectives() -> Array:
	var active: Array = []
	for id in objectives.keys():
		var data := objectives[id] as Dictionary
		if int(data["state"]) in [ObjectiveState.ACTIVE, ObjectiveState.OPTIONAL]:
			active.append({"id": id, "text": data["text"], "priority": data["priority"], "progress": data["progress"], "state": data["state"]})
	active.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a["priority"]) > float(b["priority"]))
	return active
