class_name TriggerEventSystem
extends Node3D

signal event_triggered(event_id: String, payload: Dictionary)

var triggered_once: Dictionary = {}


func trigger(event_id: String, payload: Dictionary = {}, once := false) -> void:
	if once and triggered_once.has(event_id):
		return
	triggered_once[event_id] = true
	event_triggered.emit(event_id, payload)


func trigger_if_player_enters(area: Area3D, event_id: String, payload: Dictionary = {}) -> void:
	if not area.body_entered.is_connected(_on_area_body_entered.bind(event_id, payload)):
		area.body_entered.connect(_on_area_body_entered.bind(event_id, payload))


func _on_area_body_entered(body: Node3D, event_id: String, payload: Dictionary) -> void:
	if body.is_in_group("player"):
		trigger(event_id, payload, true)
