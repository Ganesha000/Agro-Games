class_name MissionManager
extends Node

signal mission_started(id: String)
signal mission_completed(id: String)
signal mission_failed(id: String)
signal mission_priority_changed(id: String, priority: float)

enum MissionState { INACTIVE, ACTIVE, COMPLETED, FAILED, OPTIONAL, HIDDEN }
enum MissionType { RESCUE, SURVIVAL, TECHNICAL, INVESTIGATION, TIMED_EMERGENCY }

@export var danger_priority_multiplier := 0.35

var missions: Dictionary = {}

@onready var objectives: ObjectiveSystem = get_node_or_null("ObjectiveSystem") as ObjectiveSystem
@onready var triggers: TriggerEventSystem = get_node_or_null("TriggerEventSystem") as TriggerEventSystem
@onready var checkpoints: CheckpointManager = get_node_or_null("CheckpointManager") as CheckpointManager
@onready var branching: BranchingChoiceSystem = get_node_or_null("BranchingChoiceSystem") as BranchingChoiceSystem


func _ready() -> void:
	add_to_group("mission_manager")
	_ensure_children()
	triggers.event_triggered.connect(_on_event_triggered)
	objectives.objective_completed.connect(_on_objective_completed)
	_seed_opening_missions()


func create_mission(id: String, title: String, mission_type: int, objective_ids: Array, priority := 0.5, hidden := false) -> void:
	missions[id] = {"title": title, "type": mission_type, "objectives": objective_ids, "priority": priority, "state": MissionState.HIDDEN if hidden else MissionState.INACTIVE, "timer": -1.0}


func start_mission(id: String) -> void:
	if not missions.has(id):
		return
	var data: Dictionary = missions[id] as Dictionary
	data["state"] = MissionState.ACTIVE
	missions[id] = data
	mission_started.emit(id)


func update_dynamic_priority(id: String, danger: float, survivor_priority: float) -> void:
	if not missions.has(id):
		return
	var data: Dictionary = missions[id] as Dictionary
	var priority := clampf(float(data["priority"]) + danger * danger_priority_multiplier + survivor_priority * 0.4, 0.0, 1.0)
	data["priority"] = priority
	missions[id] = data
	mission_priority_changed.emit(id, priority)


func complete_mission(id: String) -> void:
	if not missions.has(id):
		return
	var data: Dictionary = missions[id] as Dictionary
	data["state"] = MissionState.COMPLETED
	missions[id] = data
	mission_completed.emit(id)


func fail_mission(id: String) -> void:
	if not missions.has(id):
		return
	var data: Dictionary = missions[id] as Dictionary
	data["state"] = MissionState.FAILED
	missions[id] = data
	mission_failed.emit(id)


func active_missions() -> Array:
	var active: Array = []
	for id in missions.keys():
		var data := missions[id] as Dictionary
		if int(data["state"]) == MissionState.ACTIVE:
			active.append({"id": id, "title": data["title"], "priority": data["priority"], "type": data["type"]})
	active.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a["priority"]) > float(b["priority"]))
	return active


func _on_event_triggered(event_id: String, payload: Dictionary) -> void:
	match event_id:
		"fire_ignition":
			start_mission("evacuate_first_floor")
		"library_survivors_detected":
			objectives.add_objective("rescue_library_students", "Locate survivors in Library", 0.88)
			create_mission("rescue_library", "Rescue Library Survivors", MissionType.RESCUE, ["rescue_library_students"], 0.88)
			start_mission("rescue_library")
		"power_failure":
			objectives.add_objective("restore_emergency_power", "Restore emergency power", 0.74)
			create_mission("restore_power", "Restore Emergency Power", MissionType.TECHNICAL, ["restore_emergency_power"], 0.74)
			start_mission("restore_power")
		"npc_rescued":
			branching.register_choice("rescued_" + String(payload.get("npc", "survivor")), {"survivors": 1, "heroism": 1})


func _on_objective_completed(id: String) -> void:
	for mission_id in missions.keys():
		var data := missions[mission_id] as Dictionary
		if not (data["objectives"] as Array).has(id):
			continue
		var done := true
		for objective_id in data["objectives"]:
			var objective_data: Dictionary = objectives.objectives.get(objective_id, {}) as Dictionary
			if objective_data.is_empty() or int(objective_data["state"]) != ObjectiveSystem.ObjectiveState.COMPLETED:
				done = false
		if done:
			complete_mission(mission_id)


func _seed_opening_missions() -> void:
	objectives.add_objective("reach_safe_corridor", "Reach nearest safe corridor", 0.65)
	create_mission("evacuate_first_floor", "Evacuate First Floor", MissionType.SURVIVAL, ["reach_safe_corridor"], 0.65, true)


func _ensure_children() -> void:
	if not objectives:
		objectives = ObjectiveSystem.new()
		objectives.name = "ObjectiveSystem"
		add_child(objectives)
	if not triggers:
		triggers = TriggerEventSystem.new()
		triggers.name = "TriggerEventSystem"
		add_child(triggers)
	if not checkpoints:
		checkpoints = CheckpointManager.new()
		checkpoints.name = "CheckpointManager"
		add_child(checkpoints)
	if not branching:
		branching = BranchingChoiceSystem.new()
		branching.name = "BranchingChoiceSystem"
		add_child(branching)
