class_name CheckpointManager
extends Node

signal checkpoint_saved(id: String)
signal checkpoint_loaded(id: String)

var checkpoints: Dictionary = {}
var latest_checkpoint := ""


func save_checkpoint(id: String, player: Node3D, mission_data: Dictionary = {}) -> void:
	checkpoints[id] = {"player_position": player.global_position if player else Vector3.ZERO, "mission_data": mission_data.duplicate(true), "time": Time.get_ticks_msec()}
	latest_checkpoint = id
	checkpoint_saved.emit(id)


func load_latest(player: Node3D) -> Dictionary:
	if latest_checkpoint == "" or not checkpoints.has(latest_checkpoint):
		return {}
	var data := checkpoints[latest_checkpoint] as Dictionary
	if player:
		player.global_position = data["player_position"]
	checkpoint_loaded.emit(latest_checkpoint)
	return data.get("mission_data", {})
