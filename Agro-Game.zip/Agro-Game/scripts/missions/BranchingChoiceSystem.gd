class_name BranchingChoiceSystem
extends Node

signal choice_registered(choice_id: String, weight: float)
signal ending_score_changed(score: Dictionary)

var score := {"survivors": 0, "damage": 0, "heroism": 0, "technical": 0}
var choices: Array[Dictionary] = []


func register_choice(choice_id: String, tags: Dictionary) -> void:
	choices.append({"id": choice_id, "tags": tags})
	for key in tags.keys():
		score[key] = int(score.get(key, 0)) + int(tags[key])
	choice_registered.emit(choice_id, 1.0)
	ending_score_changed.emit(score)


func ending_type() -> String:
	if int(score["survivors"]) >= 8 and int(score["damage"]) <= 2:
		return "perfect_evacuation"
	if int(score["heroism"]) >= 5:
		return "heroic_rescue"
	if int(score["survivors"]) <= 2:
		return "tragic_survival"
	return "partial_survival"
