class_name FireManager
extends Node3D

signal fire_created(fire_node: FireNode, burnable: BurnableObject)
signal fire_stage_changed(fire_node: FireNode, stage: int)
signal structural_collapse_requested(position: Vector3, source: BurnableObject)

const FIRE_NODE_SCENE := preload("res://scenes/fire/FireNode.tscn")

@export var simulation_tick := 0.18
@export var spread_radius := 6.5
@export var max_active_fires := 80
@export var distant_update_multiplier := 3.0
@export var initial_player_position := Vector3.ZERO

var active_fires: Array[FireNode] = []
var burnables: Array[BurnableObject] = []
var fire_by_burnable: Dictionary = {}
var tick_timer := 0.0
var heat_system: HeatSystem
var explosion_system: ExplosionSystem
var audio_controller: FireAudioController


func _ready() -> void:
	add_to_group("fire_manager")
	heat_system = get_node_or_null("HeatSystem") as HeatSystem
	explosion_system = get_node_or_null("ExplosionSystem") as ExplosionSystem
	audio_controller = get_node_or_null("FireAudioController") as FireAudioController
	if explosion_system:
		explosion_system.explosion_triggered.connect(_on_explosion_triggered)
	_register_existing_burnables()


func _process(delta: float) -> void:
	tick_timer -= delta
	if tick_timer > 0.0:
		return
	tick_timer = simulation_tick
	_simulate(simulation_tick)


func register_burnable(burnable: BurnableObject) -> void:
	if heat_system == null:
		heat_system = get_node_or_null("HeatSystem") as HeatSystem
	if explosion_system == null:
		explosion_system = get_node_or_null("ExplosionSystem") as ExplosionSystem
	if audio_controller == null:
		audio_controller = get_node_or_null("FireAudioController") as FireAudioController
	if burnables.has(burnable):
		return
	burnables.append(burnable)
	if heat_system:
		heat_system.register_room(burnable.room_id)
	burnable.ignited.connect(_on_burnable_ignited)
	burnable.burned_out.connect(_on_burnable_burned_out)
	burnable.explosion_requested.connect(_on_explosion_requested)


func ignite_burnable(burnable: BurnableObject, source: Node = null) -> void:
	register_burnable(burnable)
	burnable.ignite(source)


func ignite_nearest(point: Vector3, radius: float, material_filter: int = -1) -> void:
	for burnable in burnables:
		if burnable.global_position.distance_to(point) > radius:
			continue
		if material_filter != -1 and burnable.material_type != material_filter:
			continue
		ignite_burnable(burnable, self)
		return


func request_spread_from(fire_node: FireNode) -> void:
	if active_fires.size() >= max_active_fires:
		return
	var source := fire_node.source_burnable
	if source == null:
		return

	var source_power := source.spread_power()
	if source_power <= 0.02:
		return

	for burnable in burnables:
		if burnable == source or burnable.state >= BurnableObject.BurnState.IGNITED:
			continue
		var distance := source.global_position.distance_to(burnable.global_position)
		if distance > spread_radius * maxf(0.75, source_power):
			continue
		var room_bonus: float = 1.2 if source.room_id == burnable.room_id else 0.75
		var distance_factor := 1.0 - distance / (spread_radius * maxf(0.75, source_power))
		var heat_amount := source.temperature * source_power * distance_factor * room_bonus
		burnable.receive_heat(heat_amount, fire_node, simulation_tick)


func _simulate(delta: float) -> void:
	var player_position := _player_position()
	var total_intensity := 0.0
	for burnable in burnables:
		var oxygen: float = heat_system.room_oxygen(burnable.room_id) if heat_system else 0.85
		var airflow: float = heat_system.room_airflow(burnable.room_id) if heat_system else 0.35
		burnable.update_burn(delta, oxygen, airflow)
		if burnable.can_collapse():
			structural_collapse_requested.emit(burnable.global_position, burnable)

	for fire_node in active_fires.duplicate():
		if not is_instance_valid(fire_node):
			active_fires.erase(fire_node)
			continue
		var previous_stage := int(fire_node.get_meta("last_stage", fire_node.stage))
		fire_node.simulate(delta, player_position)
		if previous_stage != int(fire_node.stage):
			fire_node.set_meta("last_stage", int(fire_node.stage))
			fire_stage_changed.emit(fire_node, int(fire_node.stage))
		total_intensity += fire_node.intensity
		if fire_node.source_burnable and heat_system:
			heat_system.add_fire_output(fire_node.source_burnable.room_id, fire_node.heat_output, fire_node.smoke_output * 0.035, delta)
		if fire_node.stage == FireNode.FireStage.DYING and fire_node.intensity <= 0.02:
			active_fires.erase(fire_node)
			fire_by_burnable.erase(fire_node.source_burnable)
			fire_node.queue_free()

	if heat_system:
		heat_system.update_rooms(delta)
	if audio_controller:
		audio_controller.update_fire_audio(delta, clampf(total_intensity / 14.0, 0.0, 1.0))


func _register_existing_burnables() -> void:
	var tree := get_tree()
	if tree == null:
		return
	for node in tree.get_nodes_in_group("burnable"):
		if node is BurnableObject:
			register_burnable(node)


func _create_fire_node(burnable: BurnableObject) -> void:
	if fire_by_burnable.has(burnable) or active_fires.size() >= max_active_fires:
		return
	var fire_node := FIRE_NODE_SCENE.instantiate() as FireNode
	add_child(fire_node)
	fire_node.setup(burnable, self)
	active_fires.append(fire_node)
	fire_by_burnable[burnable] = fire_node
	fire_created.emit(fire_node, burnable)


func _on_burnable_ignited(burnable: BurnableObject, _source: Node) -> void:
	_create_fire_node(burnable)


func _on_burnable_burned_out(_burnable: BurnableObject) -> void:
	pass


func _on_explosion_requested(burnable: BurnableObject, strength: float) -> void:
	if explosion_system:
		explosion_system.trigger_explosion(burnable.global_position, strength, burnable)


func _on_explosion_triggered(_position: Vector3, strength: float) -> void:
	if audio_controller:
		audio_controller.play_explosion(strength)


func _player_position() -> Vector3:
	var tree := get_tree()
	if tree == null:
		return initial_player_position
	var players := tree.get_nodes_in_group("player")
	if players.is_empty() or not players[0] is Node3D:
		return initial_player_position
	return (players[0] as Node3D).global_position
