class_name HeatSystem
extends Node

signal room_temperature_changed(room_id: String, temperature: float, smoke_density: float)

@export var ambient_temperature := 28.0
@export var heat_decay_per_second := 0.18
@export var smoke_decay_per_second := 0.10
@export var closed_room_smoke_multiplier := 1.35

var rooms: Dictionary = {}


func register_room(room_id: String, oxygen: float = 0.85, airflow: float = 0.35, closed_room: bool = true) -> void:
	if rooms.has(room_id):
		return
	rooms[room_id] = {
		"temperature": ambient_temperature,
		"smoke_density": 0.0,
		"oxygen": oxygen,
		"airflow": airflow,
		"closed_room": closed_room
	}


func add_fire_output(room_id: String, heat: float, smoke: float, delta: float) -> void:
	register_room(room_id)
	var room: Dictionary = rooms[room_id]
	var smoke_multiplier: float = closed_room_smoke_multiplier if bool(room["closed_room"]) else 0.85
	room["temperature"] = float(room["temperature"]) + heat * delta
	room["smoke_density"] = clampf(float(room["smoke_density"]) + smoke * smoke_multiplier * delta, 0.0, 1.0)
	room["oxygen"] = clampf(float(room["oxygen"]) - heat * 0.00045 * delta - smoke * 0.018 * delta, 0.18, 1.0)
	rooms[room_id] = room


func update_rooms(delta: float) -> void:
	for room_id in rooms.keys():
		var room: Dictionary = rooms[room_id]
		room["temperature"] = lerpf(float(room["temperature"]), ambient_temperature, heat_decay_per_second * delta)
		room["smoke_density"] = maxf(0.0, float(room["smoke_density"]) - smoke_decay_per_second * float(room["airflow"]) * delta)
		room["oxygen"] = minf(1.0, float(room["oxygen"]) + 0.035 * float(room["airflow"]) * delta)
		rooms[room_id] = room
		room_temperature_changed.emit(String(room_id), float(room["temperature"]), float(room["smoke_density"]))


func room_temperature(room_id: String) -> float:
	register_room(room_id)
	return float(rooms[room_id]["temperature"])


func room_smoke(room_id: String) -> float:
	register_room(room_id)
	return float(rooms[room_id]["smoke_density"])


func room_oxygen(room_id: String) -> float:
	register_room(room_id)
	return float(rooms[room_id]["oxygen"])


func room_airflow(room_id: String) -> float:
	register_room(room_id)
	return float(rooms[room_id]["airflow"])
