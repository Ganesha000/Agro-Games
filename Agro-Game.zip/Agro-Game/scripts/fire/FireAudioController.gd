class_name FireAudioController
extends Node

@export var min_crackle_db := -28.0
@export var max_crackle_db := -4.0
@export var update_rate := 0.2

var active_intensity := 0.0
var update_timer := 0.0
@onready var crackle_player: AudioStreamPlayer = $Crackle
@onready var alarm_player: AudioStreamPlayer = $Alarm
@onready var explosion_player: AudioStreamPlayer = $Explosion
@onready var collapse_player: AudioStreamPlayer = $Collapse


func _ready() -> void:
	_play_if_stream(crackle_player)
	_play_if_stream(alarm_player)


func update_fire_audio(delta: float, intensity: float) -> void:
	active_intensity = lerpf(active_intensity, clampf(intensity, 0.0, 1.0), 1.0 - exp(-3.0 * delta))
	update_timer -= delta
	if update_timer > 0.0:
		return
	update_timer = update_rate
	crackle_player.volume_db = lerpf(min_crackle_db, max_crackle_db, active_intensity)
	alarm_player.volume_db = lerpf(-32.0, -10.0, active_intensity)


func play_explosion(strength: float) -> void:
	explosion_player.volume_db = lerpf(-12.0, 1.5, clampf(strength, 0.0, 1.5) / 1.5)
	explosion_player.play()


func play_collapse() -> void:
	collapse_player.play()


func _play_if_stream(player: AudioStreamPlayer) -> void:
	if player and player.stream:
		player.play()

