class_name BurnableObject
extends Area3D

signal ignited(burnable: BurnableObject, ignition_source: Node)
signal burn_progress_changed(burnable: BurnableObject, progress: float)
signal burned_out(burnable: BurnableObject)
signal explosion_requested(burnable: BurnableObject, strength: float)

enum MaterialType {
	PAPER,
	WOOD,
	CURTAIN,
	PLASTIC,
	ELECTRICAL,
	WALL,
	CEILING_PANEL,
	CHEMICAL,
	CONCRETE
}

enum BurnState { UNBURNED, HEATING, IGNITED, BURNING, BURNED_OUT }

@export var material_type: MaterialType = MaterialType.WOOD
@export var object_size := 1.0
@export var oxygen_access := 0.65
@export var room_id := "global"
@export var is_structural := false
@export var collapse_threshold := 0.78
@export var scan_radius := 2.5
@export var visual_node_path: NodePath

var state: BurnState = BurnState.UNBURNED
var temperature := 24.0
var burn_progress := 0.0
var fuel_remaining := 1.0
var heat_exposure := 0.0
var time_since_ignition := 0.0
var has_exploded := false
var collapse_reported := false
var material_data := {}
var visual_node: Node3D


func _ready() -> void:
	add_to_group("burnable")
	monitoring = true
	monitorable = true
	collision_layer = 1
	collision_mask = 1
	material_data = FireMaterialDatabase.get_material(material_type)
	if visual_node_path != NodePath():
		visual_node = get_node_or_null(visual_node_path) as Node3D
	if get_child_count() == 0:
		_add_default_shape()


func receive_heat(amount: float, source: Node, delta: float) -> void:
	if state == BurnState.BURNED_OUT or material_type == MaterialType.CONCRETE:
		return

	var ignition_temp: float = float(material_data["ignition_temperature"])
	var conductivity: float = float(material_data["heat_absorption"])
	heat_exposure = maxf(heat_exposure, amount)
	temperature += amount * conductivity * delta

	if state == BurnState.UNBURNED and temperature > ignition_temp * 0.45:
		state = BurnState.HEATING

	if temperature >= ignition_temp and state < BurnState.IGNITED:
		ignite(source)


func ignite(source: Node = null) -> void:
	if state >= BurnState.IGNITED or state == BurnState.BURNED_OUT:
		return
	state = BurnState.IGNITED
	time_since_ignition = 0.0
	ignited.emit(self, source)


func update_burn(delta: float, room_oxygen: float, airflow: float) -> void:
	if state < BurnState.IGNITED or state == BurnState.BURNED_OUT:
		temperature = maxf(24.0, temperature - 18.0 * delta)
		heat_exposure = maxf(0.0, heat_exposure - delta)
		return

	state = BurnState.BURNING
	time_since_ignition += delta
	var burn_duration: float = float(material_data["burn_duration"]) * maxf(0.35, object_size)
	var oxygen_factor := clampf((room_oxygen + oxygen_access) * 0.5, 0.25, 1.35)
	var airflow_factor := lerpf(0.75, 1.35, clampf(airflow, 0.0, 1.0))
	var burn_rate := delta / burn_duration * oxygen_factor * airflow_factor

	burn_progress = clampf(burn_progress + burn_rate, 0.0, 1.0)
	fuel_remaining = 1.0 - burn_progress
	temperature = lerpf(temperature, float(material_data["max_temperature"]), 1.0 - exp(-2.5 * delta))
	burn_progress_changed.emit(self, burn_progress)

	if _should_explode():
		has_exploded = true
		explosion_requested.emit(self, float(material_data["explosion_strength"]))

	if burn_progress >= 1.0:
		state = BurnState.BURNED_OUT
		temperature = maxf(120.0, temperature * 0.35)
		burned_out.emit(self)


func flame_intensity() -> float:
	if state < BurnState.IGNITED or state == BurnState.BURNED_OUT:
		return 0.0
	var base: float = float(material_data["flame_intensity"])
	var growth := smoothstep(0.0, 0.22, burn_progress)
	var decay := 1.0 - smoothstep(0.72, 1.0, burn_progress)
	return clampf(base * growth * decay * fuel_remaining + heat_exposure * 0.1, 0.0, 2.5)


func smoke_amount() -> float:
	if state < BurnState.IGNITED:
		return 0.0
	var base: float = float(material_data["smoke_amount"])
	return clampf(base * (0.35 + burn_progress * 0.9), 0.0, 2.5)


func spread_power() -> float:
	return flame_intensity() * float(material_data["spread_multiplier"]) * oxygen_access


func can_collapse() -> bool:
	if is_structural and not collapse_reported and burn_progress >= collapse_threshold:
		collapse_reported = true
		return true
	return false


func _should_explode() -> bool:
	if has_exploded:
		return false
	var risk: float = float(material_data["explosion_risk"])
	if risk <= 0.0:
		return false
	return burn_progress > 0.18 and randf() < risk * 0.012


func _add_default_shape() -> void:
	var collision := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = scan_radius
	collision.shape = shape
	add_child(collision)
