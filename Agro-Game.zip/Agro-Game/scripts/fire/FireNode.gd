class_name FireNode
extends Node3D

signal intensity_changed(fire_node: FireNode, intensity: float)
signal critical_reached(fire_node: FireNode)

enum FireStage { IGNITION, GROWING, DANGEROUS, CRITICAL, DYING }

@export var source_burnable_path: NodePath
@export var heat_radius := 5.5
@export var spread_interval := 0.65
@export var max_life_after_burnout := 8.0
@export var lod_distance := 75.0

var source_burnable: BurnableObject
var stage: FireStage = FireStage.IGNITION
var intensity := 0.15
var smoke_output := 0.0
var heat_output := 0.0
var spread_timer := 0.0
var dying_timer := 0.0
var manager: FireManager

@onready var flame_particles: GPUParticles3D = $Flames
@onready var smoke_particles: GPUParticles3D = $Smoke
@onready var ember_particles: GPUParticles3D = $Embers
@onready var sparks_particles: GPUParticles3D = $Sparks
@onready var fire_light: OmniLight3D = $FireLight
@onready var heat_area: Area3D = $HeatArea
@onready var heat_shape: CollisionShape3D = $HeatArea/CollisionShape3D


func setup(burnable: BurnableObject, fire_manager: FireManager) -> void:
	source_burnable = burnable
	manager = fire_manager
	global_position = burnable.global_position


func _ready() -> void:
	_configure_particles()
	if source_burnable_path != NodePath():
		source_burnable = get_node_or_null(source_burnable_path) as BurnableObject


func simulate(delta: float, player_position: Vector3) -> void:
	if source_burnable == null or not is_instance_valid(source_burnable):
		queue_free()
		return

	var distance_to_player := global_position.distance_to(player_position)
	var lod_factor: float = 1.0 if distance_to_player < lod_distance else 0.35
	_update_intensity(delta)
	_update_stage()
	_update_visuals(delta, lod_factor)
	_apply_heat_to_overlapping(delta)
	_update_spread(delta)
	intensity_changed.emit(self, intensity)

	if stage == FireStage.CRITICAL:
		critical_reached.emit(self)


func _update_intensity(delta: float) -> void:
	if source_burnable.state == BurnableObject.BurnState.BURNED_OUT:
		stage = FireStage.DYING
		dying_timer += delta
		intensity = maxf(0.0, intensity - delta / max_life_after_burnout)
	else:
		var target: float = source_burnable.flame_intensity()
		intensity = lerpf(intensity, target, 1.0 - exp(-3.2 * delta))

	smoke_output = source_burnable.smoke_amount() * intensity
	heat_output = source_burnable.temperature * intensity * 0.018


func _update_stage() -> void:
	if stage == FireStage.DYING:
		return
	if intensity < 0.35:
		stage = FireStage.IGNITION
	elif intensity < 0.85:
		stage = FireStage.GROWING
	elif intensity < 1.45:
		stage = FireStage.DANGEROUS
	else:
		stage = FireStage.CRITICAL


func _update_visuals(delta: float, lod_factor: float) -> void:
	var particle_ratio := clampf(intensity * lod_factor, 0.05, 1.0)
	flame_particles.amount_ratio = particle_ratio
	smoke_particles.amount_ratio = clampf(smoke_output * 0.5 * lod_factor, 0.05, 1.0)
	ember_particles.amount_ratio = clampf(intensity * 0.6 * lod_factor, 0.05, 1.0)
	var spark_factor: float = 1.0 if source_burnable.material_type == BurnableObject.MaterialType.ELECTRICAL else 0.25
	sparks_particles.amount_ratio = clampf(spark_factor * intensity * lod_factor, 0.0, 1.0)
	fire_light.light_energy = lerpf(fire_light.light_energy, intensity * 4.5 + randf() * intensity * 1.2, 1.0 - exp(-18.0 * delta))
	fire_light.omni_range = lerpf(4.0, 13.0, clampf(intensity / 1.6, 0.0, 1.0))
	var sphere := heat_shape.shape as SphereShape3D
	if sphere:
		sphere.radius = heat_radius * clampf(0.45 + intensity, 0.4, 1.9)


func _apply_heat_to_overlapping(delta: float) -> void:
	for area in heat_area.get_overlapping_areas():
		if area is BurnableObject and area != source_burnable:
			var burnable := area as BurnableObject
			var distance := global_position.distance_to(burnable.global_position)
			var falloff := clampf(1.0 - distance / maxf(0.1, heat_radius), 0.0, 1.0)
			burnable.receive_heat(source_burnable.temperature * intensity * falloff, self, delta)

	for body in heat_area.get_overlapping_bodies():
		if body.is_in_group("player") and body.has_method("apply_environment_hit"):
			var distance := global_position.distance_to((body as Node3D).global_position)
			var falloff := clampf(1.0 - distance / maxf(0.1, heat_radius), 0.0, 1.0)
			body.call("apply_environment_hit", "heat_fire", intensity * falloff * 3.0 * delta, intensity * 0.03)
		elif body.is_in_group("story_character"):
			if body.has_method("set_emergency_mode"):
				body.call("set_emergency_mode", true)
			if intensity > 1.2 and body.has_method("mark_injured"):
				body.call("mark_injured")


func _update_spread(delta: float) -> void:
	spread_timer -= delta
	if spread_timer > 0.0 or manager == null:
		return
	spread_timer = spread_interval
	manager.request_spread_from(self)


func _configure_particles() -> void:
	flame_particles.emitting = true
	smoke_particles.emitting = true
	ember_particles.emitting = true
	sparks_particles.emitting = true
