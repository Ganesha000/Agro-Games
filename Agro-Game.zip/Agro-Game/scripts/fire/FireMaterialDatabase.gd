class_name FireMaterialDatabase
extends RefCounted


static func get_material(material_type: int) -> Dictionary:
	match material_type:
		BurnableObject.MaterialType.PAPER:
			return {
				"ignition_temperature": 230.0,
				"burn_duration": 10.0,
				"flame_intensity": 0.85,
				"smoke_amount": 1.2,
				"explosion_risk": 0.0,
				"explosion_strength": 0.0,
				"max_temperature": 620.0,
				"spread_multiplier": 1.45,
				"heat_absorption": 1.45
			}
		BurnableObject.MaterialType.WOOD:
			return {
				"ignition_temperature": 300.0,
				"burn_duration": 38.0,
				"flame_intensity": 1.0,
				"smoke_amount": 0.9,
				"explosion_risk": 0.0,
				"explosion_strength": 0.0,
				"max_temperature": 760.0,
				"spread_multiplier": 0.9,
				"heat_absorption": 0.82
			}
		BurnableObject.MaterialType.CURTAIN:
			return {
				"ignition_temperature": 255.0,
				"burn_duration": 16.0,
				"flame_intensity": 1.2,
				"smoke_amount": 1.35,
				"explosion_risk": 0.0,
				"explosion_strength": 0.0,
				"max_temperature": 690.0,
				"spread_multiplier": 1.55,
				"heat_absorption": 1.18
			}
		BurnableObject.MaterialType.PLASTIC:
			return {
				"ignition_temperature": 360.0,
				"burn_duration": 24.0,
				"flame_intensity": 0.75,
				"smoke_amount": 1.85,
				"explosion_risk": 0.0,
				"explosion_strength": 0.0,
				"max_temperature": 710.0,
				"spread_multiplier": 0.7,
				"heat_absorption": 0.72
			}
		BurnableObject.MaterialType.ELECTRICAL:
			return {
				"ignition_temperature": 210.0,
				"burn_duration": 26.0,
				"flame_intensity": 1.05,
				"smoke_amount": 1.55,
				"explosion_risk": 0.35,
				"explosion_strength": 0.65,
				"max_temperature": 840.0,
				"spread_multiplier": 1.1,
				"heat_absorption": 1.0
			}
		BurnableObject.MaterialType.WALL:
			return {
				"ignition_temperature": 520.0,
				"burn_duration": 120.0,
				"flame_intensity": 0.35,
				"smoke_amount": 0.32,
				"explosion_risk": 0.0,
				"explosion_strength": 0.0,
				"max_temperature": 430.0,
				"spread_multiplier": 0.22,
				"heat_absorption": 0.32
			}
		BurnableObject.MaterialType.CEILING_PANEL:
			return {
				"ignition_temperature": 290.0,
				"burn_duration": 28.0,
				"flame_intensity": 0.9,
				"smoke_amount": 1.1,
				"explosion_risk": 0.05,
				"explosion_strength": 0.25,
				"max_temperature": 680.0,
				"spread_multiplier": 1.05,
				"heat_absorption": 0.86
			}
		BurnableObject.MaterialType.CHEMICAL:
			return {
				"ignition_temperature": 170.0,
				"burn_duration": 18.0,
				"flame_intensity": 1.85,
				"smoke_amount": 1.65,
				"explosion_risk": 0.75,
				"explosion_strength": 1.35,
				"max_temperature": 1120.0,
				"spread_multiplier": 1.85,
				"heat_absorption": 1.35
			}
		_:
			return {
				"ignition_temperature": 9999.0,
				"burn_duration": 999.0,
				"flame_intensity": 0.0,
				"smoke_amount": 0.0,
				"explosion_risk": 0.0,
				"explosion_strength": 0.0,
				"max_temperature": 60.0,
				"spread_multiplier": 0.0,
				"heat_absorption": 0.05
			}

