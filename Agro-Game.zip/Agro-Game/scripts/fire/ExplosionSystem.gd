class_name ExplosionSystem
extends Node3D

signal explosion_triggered(position: Vector3, strength: float)

@export var base_radius := 7.0
@export var player_damage := 36.0
@export var npc_damage := 50.0
@export var ignition_heat := 580.0
@export var debris_count := 10

var debris_material: StandardMaterial3D


func _ready() -> void:
	debris_material = StandardMaterial3D.new()
	debris_material.albedo_color = Color(0.08, 0.07, 0.06)
	debris_material.roughness = 0.82


func trigger_explosion(origin: Vector3, strength: float, source: Node = null) -> void:
	var radius := base_radius * maxf(0.35, strength)
	explosion_triggered.emit(origin, strength)
	_apply_shockwave(origin, radius, strength)
	_launch_debris(origin, strength)
	_ignite_nearby_burnables(origin, radius, strength, source)


func _apply_shockwave(origin: Vector3, radius: float, strength: float) -> void:
	var tree := get_tree()
	if tree == null:
		return
	for player in tree.get_nodes_in_group("player"):
		if not player is Node3D:
			continue
		var distance := origin.distance_to((player as Node3D).global_position)
		if distance <= radius and player.has_method("apply_environment_hit"):
			var falloff := 1.0 - distance / radius
			player.call("apply_environment_hit", "explosion", player_damage * falloff * strength, clampf(0.35 + strength * 0.35, 0.0, 1.0))
	for npc in tree.get_nodes_in_group("story_character"):
		if not npc is Node3D:
			continue
		var distance := origin.distance_to((npc as Node3D).global_position)
		if distance <= radius and npc.has_method("mark_injured"):
			npc.call("mark_injured")


func _launch_debris(origin: Vector3, strength: float) -> void:
	for i in range(debris_count):
		var body := RigidBody3D.new()
		body.name = "Explosion debris"
		body.position = origin + Vector3(randf_range(-1.2, 1.2), randf_range(0.5, 2.4), randf_range(-1.2, 1.2))
		body.mass = randf_range(0.5, 2.5)
		var collision := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = Vector3(randf_range(0.18, 0.65), randf_range(0.08, 0.35), randf_range(0.18, 0.65))
		collision.shape = shape
		body.add_child(collision)
		var visual := MeshInstance3D.new()
		var mesh := BoxMesh.new()
		mesh.size = shape.size
		visual.mesh = mesh
		visual.material_override = debris_material
		body.add_child(visual)
		add_child(body)
		var impulse := Vector3(randf_range(-1, 1), randf_range(0.45, 1.25), randf_range(-1, 1)).normalized() * randf_range(7.0, 15.0) * strength
		body.apply_impulse(impulse)


func _ignite_nearby_burnables(origin: Vector3, radius: float, strength: float, source: Node) -> void:
	var tree := get_tree()
	if tree == null:
		return
	for burnable in tree.get_nodes_in_group("burnable"):
		if not burnable is BurnableObject:
			continue
		var obj := burnable as BurnableObject
		var distance := origin.distance_to(obj.global_position)
		if distance <= radius:
			var falloff := 1.0 - distance / radius
			obj.receive_heat(ignition_heat * falloff * strength, source, 1.0)

