class_name PathfindingSystem
extends Node

signal route_failed(reason: String)
signal route_changed(target: Vector3)

@export var repath_interval := 0.55
@export var danger_probe_radius := 4.0
@export var crowd_penalty_weight := 0.35
@export var danger_penalty_weight := 2.25

var navigation_agent: NavigationAgent3D
var danger_provider: Node
var crowd_manager: CrowdManager
var target_position := Vector3.ZERO
var repath_timer := 0.0
var route_blocked_timer := 0.0


func bind(agent: NavigationAgent3D, danger: Node, crowd: CrowdManager) -> void:
	navigation_agent = agent
	danger_provider = danger
	crowd_manager = crowd
	if navigation_agent:
		navigation_agent.path_desired_distance = 0.6
		navigation_agent.target_desired_distance = 1.2
		navigation_agent.avoidance_enabled = true


func set_target(target: Vector3, force := false) -> void:
	if not navigation_agent:
		return
	if force or target.distance_to(target_position) > 1.2:
		target_position = target
		navigation_agent.target_position = target_position
		route_changed.emit(target_position)


func update_route(delta: float, origin: Vector3, exits: Array[Node3D]) -> void:
	repath_timer -= delta
	if repath_timer > 0.0:
		return
	repath_timer = repath_interval
	var best_target := choose_best_exit(origin, exits)
	if best_target != Vector3.INF:
		set_target(best_target)
	elif navigation_agent and navigation_agent.is_navigation_finished():
		route_failed.emit("No safe evacuation route available.")


func next_direction(origin: Vector3) -> Vector3:
	if not navigation_agent or navigation_agent.is_navigation_finished():
		return Vector3.ZERO
	var next_point := navigation_agent.get_next_path_position()
	var direction := next_point - origin
	direction.y = 0.0
	return direction.normalized() if direction.length_squared() > 0.01 else Vector3.ZERO


func choose_best_exit(origin: Vector3, exits: Array[Node3D]) -> Vector3:
	var best_score := INF
	var best_position := Vector3.INF
	for exit in exits:
		if not is_instance_valid(exit):
			continue
		var danger := _sample_danger(exit.global_position)
		var crowd: float = crowd_manager.crowd_density_at(exit.global_position, 5.5) if crowd_manager else 0.0
		var distance := origin.distance_to(exit.global_position)
		var blocked := bool(exit.get_meta("blocked", false))
		if blocked or danger > 0.88:
			continue
		var score := distance + danger * danger_penalty_weight * 40.0 + crowd * crowd_penalty_weight * 30.0
		if score < best_score:
			best_score = score
			best_position = exit.global_position
	return best_position


func _sample_danger(point: Vector3) -> float:
	if danger_provider and danger_provider.has_method("danger_at"):
		return float(danger_provider.call("danger_at", point, danger_probe_radius))
	return 0.0
