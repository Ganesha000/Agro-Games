class_name PanicSystem
extends Node

signal state_requested(next_state: int, reason: String)
signal voice_requested(category: String, intensity: float)

@export var fear_gain_fire := 0.34
@export var fear_gain_smoke := 0.28
@export var fear_decay := 0.035
@export var freeze_threshold := 0.76
@export var collapse_threshold := 0.94
@export var social_contagion_radius := 7.0

var panic := 0.0
var courage := 0.35
var discipline := 0.35
var empathy := 0.35
var confusion := 0.0
var last_scream_time := -10.0


func configure(profile: Dictionary) -> void:
	courage = float(profile.get("courage", courage))
	discipline = float(profile.get("discipline", discipline))
	empathy = float(profile.get("empathy", empathy))
	panic = float(profile.get("initial_panic", panic))


func update_panic(delta: float, danger: Dictionary, social_pressure: float, is_guided: bool) -> void:
	var fire := float(danger.get("fire", 0.0))
	var smoke := float(danger.get("smoke", 0.0))
	var heat := float(danger.get("heat", 0.0))
	var collapse := float(danger.get("collapse", 0.0))
	var injury := float(danger.get("injury", 0.0))
	var guidance_bonus := 0.18 if is_guided else 0.0
	var growth := fire * fear_gain_fire + smoke * fear_gain_smoke + heat * 0.12 + collapse * 0.24 + injury * 0.2
	growth += social_pressure * 0.22
	growth *= 1.25 - courage * 0.45 - discipline * 0.25 - guidance_bonus
	panic = clampf(panic + growth * delta - fear_decay * delta * (0.6 + discipline), 0.0, 1.0)
	confusion = clampf(smoke * 0.65 + panic * 0.25 - discipline * 0.12, 0.0, 1.0)


func choose_state(current_state: int, states: Dictionary, danger: Dictionary, health: float, trapped: bool, guided: bool) -> int:
	if health <= 0.02 or panic >= collapse_threshold:
		return int(states["COLLAPSE"])
	if trapped:
		return int(states["RESCUE_REQUEST"])
	if guided:
		return int(states["GUIDED"])
	if health < 0.42:
		return int(states["INJURED"])
	var danger_score := _danger_score(danger)
	if danger_score > 0.48 and panic > 0.48:
		return int(states["ESCAPE"])
	if panic > 0.58:
		return int(states["PANIC"])
	if danger_score > 0.18:
		return int(states["ALERT"])
	return current_state


func should_freeze() -> bool:
	return panic > freeze_threshold and randf() < panic * 0.018


func should_help_other() -> bool:
	var stress_penalty := panic * 0.45
	return empathy + courage * 0.35 - stress_penalty > randf()


func should_scream(now: float) -> bool:
	if now - last_scream_time < lerpf(7.0, 1.6, panic):
		return false
	if panic < 0.35:
		return false
	last_scream_time = now
	voice_requested.emit("scream", panic)
	return true


func apply_calm_command(strength: float) -> void:
	panic = clampf(panic - strength * (0.45 + discipline * 0.35), 0.0, 1.0)
	confusion = clampf(confusion - strength * 0.25, 0.0, 1.0)
	voice_requested.emit("breathing", panic)


func react_to_explosion(distance: float, strength: float) -> void:
	var shock := clampf(strength / maxf(distance, 1.0), 0.0, 1.0)
	panic = clampf(panic + shock * 0.5, 0.0, 1.0)
	confusion = clampf(confusion + shock * 0.35, 0.0, 1.0)
	voice_requested.emit("shock", shock)


func _danger_score(danger: Dictionary) -> float:
	return clampf(
		float(danger.get("fire", 0.0)) * 0.34 +
		float(danger.get("smoke", 0.0)) * 0.28 +
		float(danger.get("heat", 0.0)) * 0.16 +
		float(danger.get("collapse", 0.0)) * 0.22,
		0.0,
		1.0
	)
