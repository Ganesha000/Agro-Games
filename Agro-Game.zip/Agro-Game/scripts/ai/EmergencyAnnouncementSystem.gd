class_name EmergencyAnnouncementSystem
extends Node

signal announcement_queued(text: String, urgency: float)
signal announcement_started(text: String, urgency: float)

@export var min_gap := 4.0
@export var critical_gap := 1.8
@export var voice_bus := "Voice"

var queue: Array[Dictionary] = []
var cooldown := 0.0
var system_damage := 0.0


func _process(delta: float) -> void:
	cooldown -= delta
	if cooldown > 0.0 or queue.is_empty():
		return
	queue.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a["urgency"]) > float(b["urgency"]))
	var item := queue.pop_front() as Dictionary
	var text := String(item["text"])
	var urgency := float(item["urgency"])
	cooldown = lerpf(min_gap, critical_gap, urgency)
	announcement_started.emit(_distort(text), urgency)


func announce(text: String, urgency: float = 0.5) -> void:
	queue.append({"text": text, "urgency": clampf(urgency, 0.0, 1.0)})
	announcement_queued.emit(text, urgency)


func set_system_damage(amount: float) -> void:
	system_damage = clampf(amount, 0.0, 1.0)


func _distort(text: String) -> String:
	if system_damage < 0.45:
		return text
	return "[SIGNAL DEGRADED] " + text
