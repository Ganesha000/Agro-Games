class_name SafeRouteSystem
extends Node3D

signal safe_route_updated(points: PackedVector3Array, danger_score: float)
signal evacuation_route_compromised(reason: String)

@export var update_interval := 0.7
@export var exit_group := "evacuation_exit"
@export var route_marker_group := "safe_route_marker"

var tick := 0.0
var danger_analysis: DangerAnalysis
var current_route := PackedVector3Array()
var current_danger := 1.0


func _ready() -> void:
	add_to_group("safe_route_system")
	_resolve_danger()


func request_route(origin: Vector3) -> PackedVector3Array:
	_resolve_danger()
	var best_exit := _best_exit(origin)
	if best_exit == null:
		evacuation_route_compromised.emit("All exits are blocked or unsafe.")
		return PackedVector3Array()
	current_route = PackedVector3Array([origin, best_exit.global_position])
	current_danger = danger_analysis.danger_at(best_exit.global_position, 8.0) if danger_analysis else 0.0
	safe_route_updated.emit(current_route, current_danger)
	return current_route


func _process(delta: float) -> void:
	tick -= delta
	if tick > 0.0:
		return
	tick = update_interval
	var players := get_tree().get_nodes_in_group("player")
	if not players.is_empty() and players[0] is Node3D:
		request_route((players[0] as Node3D).global_position)


func _best_exit(origin: Vector3) -> Node3D:
	var best: Node3D
	var best_score := INF
	for node in get_tree().get_nodes_in_group(exit_group):
		if not node is Node3D or bool(node.get_meta("blocked", false)):
			continue
		var exit := node as Node3D
		var danger: float = danger_analysis.danger_at(exit.global_position, 9.0) if danger_analysis else 0.0
		if danger > 0.82:
			continue
		var score := origin.distance_to(exit.global_position) + danger * 80.0
		if score < best_score:
			best_score = score
			best = exit
	return best


func _resolve_danger() -> void:
	if danger_analysis:
		return
	var nodes := get_tree().get_nodes_in_group("danger_analysis")
	if not nodes.is_empty():
		danger_analysis = nodes[0] as DangerAnalysis
