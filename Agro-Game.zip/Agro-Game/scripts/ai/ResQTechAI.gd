class_name ResQTechAI
extends Node3D

signal objective_suggested(text: String, priority: float)
signal hud_alert(text: String, urgency: float)
signal survivor_priority_updated(npc: Node3D, priority: float)

@export var director_tick := 0.35
@export var critical_survivor_threshold := 0.72

var tick := 0.0

@onready var danger_analysis: DangerAnalysis = get_node_or_null("DangerAnalysis") as DangerAnalysis
@onready var safe_routes: SafeRouteSystem = get_node_or_null("SafeRouteSystem") as SafeRouteSystem
@onready var thermal_scanner: ThermalScanner = get_node_or_null("ThermalScanner") as ThermalScanner
@onready var announcements: EmergencyAnnouncementSystem = get_node_or_null("EmergencyAnnouncementSystem") as EmergencyAnnouncementSystem
@onready var infrastructure: SmartInfrastructureController = get_node_or_null("SmartInfrastructureController") as SmartInfrastructureController


func _ready() -> void:
	add_to_group("resqtech_ai")
	_ensure_children()
	danger_analysis.critical_zone_detected.connect(_on_critical_zone)
	safe_routes.safe_route_updated.connect(_on_safe_route_updated)
	safe_routes.evacuation_route_compromised.connect(func(reason: String) -> void: _announce(reason, 0.86))
	thermal_scanner.survivor_detected.connect(_on_survivor_detected)
	_announce("ResQTech AI online. Emergency response systems synchronizing.", 0.25)


func _process(delta: float) -> void:
	tick -= delta
	if tick > 0.0:
		return
	tick = director_tick
	_update_player_route()


func request_survivor_scan(origin: Vector3) -> Array:
	var results := thermal_scanner.scan(origin)
	if results.is_empty():
		_announce("Thermal scan clear. Continue toward the evacuation route.", 0.35)
	else:
		_announce("Thermal scan detected trapped individuals nearby.", 0.72)
	return results


func report_environment_event(event_id: String, world_position: Vector3, severity: float) -> void:
	match event_id:
		"explosion":
			hud_alert.emit("Explosion shockwave detected", severity)
			_announce("Warning. Explosion detected. Recalculating safe route.", severity)
		"power_loss":
			infrastructure.set_emergency_lighting(true)
			_announce("Power instability detected. Emergency lighting engaged.", severity)
		"collapse":
			_announce("Structural integrity decreasing. Avoid marked corridors.", severity)
	danger_analysis.set_structural_risk(event_id + "_" + str(Time.get_ticks_msec()), world_position, severity)


func danger_at(point: Vector3, radius: float = 5.0) -> float:
	return danger_analysis.danger_at(point, radius)


func danger_breakdown_at(point: Vector3, room_id: String = "") -> Dictionary:
	return danger_analysis.danger_breakdown_at(point, room_id)


func _update_player_route() -> void:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty() or not players[0] is Node3D:
		return
	safe_routes.request_route((players[0] as Node3D).global_position)


func _on_critical_zone(zone_id: String, _position: Vector3, danger: float) -> void:
	hud_alert.emit("Critical danger in " + zone_id, danger)
	_announce("Critical hazard detected in " + zone_id + ". Avoid this area immediately.", danger)
	if danger > 0.88:
		infrastructure.seal_danger_zone(zone_id)


func _on_safe_route_updated(_points: PackedVector3Array, danger_score: float) -> void:
	if danger_score < 0.45:
		hud_alert.emit("Alternative evacuation route available", 0.35)
	else:
		hud_alert.emit("Safe route risk elevated", danger_score)


func _on_survivor_detected(npc: Node3D, priority: float) -> void:
	survivor_priority_updated.emit(npc, priority)
	if priority >= critical_survivor_threshold:
		objective_suggested.emit("Rescue priority: " + npc.name, priority)
		_announce("Rescue priority updated. Life signs at risk.", priority)


func _announce(text: String, urgency: float) -> void:
	announcements.announce(text, urgency)
	hud_alert.emit(text, urgency)


func _ensure_children() -> void:
	if not danger_analysis:
		danger_analysis = DangerAnalysis.new()
		danger_analysis.name = "DangerAnalysis"
		add_child(danger_analysis)
	if not safe_routes:
		safe_routes = SafeRouteSystem.new()
		safe_routes.name = "SafeRouteSystem"
		add_child(safe_routes)
	if not thermal_scanner:
		thermal_scanner = ThermalScanner.new()
		thermal_scanner.name = "ThermalScanner"
		add_child(thermal_scanner)
	if not announcements:
		announcements = EmergencyAnnouncementSystem.new()
		announcements.name = "EmergencyAnnouncementSystem"
		add_child(announcements)
	if not infrastructure:
		infrastructure = SmartInfrastructureController.new()
		infrastructure.name = "SmartInfrastructureController"
		add_child(infrastructure)
