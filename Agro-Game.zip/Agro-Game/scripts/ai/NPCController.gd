class_name NPCController
extends CharacterBody3D

signal npc_state_changed(npc: NPCController, state: int)
signal rescue_priority_changed(npc: NPCController, priority: float)

enum NPCType { STUDENT, TEACHER, INJURED, SECURITY_STAFF, JUNIOR_STUDENT }
enum PanicState { CALM, ALERT, PANIC, ESCAPE, RESCUE_REQUEST, INJURED, COLLAPSE, GUIDED }

@export var npc_name := "Survivor"
@export var npc_type: int = NPCType.STUDENT
@export var room_id := ""
@export var walk_speed := 2.2
@export var run_speed := 5.2
@export var injured_speed := 1.15
@export var panic_sprint_speed := 6.0
@export var acceleration := 9.0
@export var gravity := 18.0
@export var ai_tick_near := 0.12
@export var ai_tick_mid := 0.35
@export var ai_tick_far := 0.9
@export var evacuation_exits_group := "evacuation_exit"
@export var animation_tree_path: NodePath
@export var voice_player_path: NodePath

var state: int = PanicState.CALM
var danger := {"fire": 0.0, "smoke": 0.0, "heat": 0.0, "collapse": 0.0, "injury": 0.0}
var social_panic := 0.0
var crowd_density := 0.0
var trapped := false
var ai_timer := 0.0
var freeze_timer := 0.0
var random_wander := Vector3.ZERO

@onready var navigation_agent: NavigationAgent3D = get_node_or_null("NavigationAgent3D") as NavigationAgent3D
@onready var panic_system: PanicSystem = get_node_or_null("PanicSystem") as PanicSystem
@onready var pathfinding: PathfindingSystem = get_node_or_null("PathfindingSystem") as PathfindingSystem
@onready var rescue_behavior: RescueBehavior = get_node_or_null("RescueBehavior") as RescueBehavior
@onready var health: NPCHealth = get_node_or_null("NPCHealth") as NPCHealth
@onready var animation_tree: AnimationTree = get_node_or_null(animation_tree_path) as AnimationTree
@onready var voice_player: AudioStreamPlayer3D = get_node_or_null(voice_player_path) as AudioStreamPlayer3D

var crowd_manager: CrowdManager
var danger_analysis: Node


func _ready() -> void:
	add_to_group("npc")
	add_to_group("survivor")
	add_to_group("story_character")
	_ensure_children()
	_apply_type_profile()
	_bind_world_systems()
	health.injured.connect(func(_severity: float) -> void: _change_state(PanicState.INJURED, "injury"))
	health.collapsed.connect(func() -> void: _change_state(PanicState.COLLAPSE, "collapse"))
	health.revived.connect(func() -> void: _change_state(PanicState.ALERT, "revived"))
	panic_system.voice_requested.connect(_on_voice_requested)


func _physics_process(delta: float) -> void:
	_update_ai_tick(delta)
	_apply_movement(delta)
	_update_animation()


func interact(player: Node) -> void:
	var player_3d := player as Node3D
	if state == PanicState.COLLAPSE:
		health.revive()
		rescue_behavior.revive()
		return
	if state == PanicState.INJURED and rescue_behavior.can_be_carried:
		rescue_behavior.request_carry(self)
		return
	if player_3d and rescue_behavior.request_guidance(player_3d, panic_system.panic, _danger_score()):
		panic_system.apply_calm_command(0.5)
		_change_state(PanicState.GUIDED, "player_guidance")


func set_emergency_mode(enabled: bool) -> void:
	if enabled and state == PanicState.CALM:
		_change_state(PanicState.ALERT, "alarm")
		panic_system.panic = maxf(panic_system.panic, 0.32)


func mark_trapped() -> void:
	trapped = true
	_change_state(PanicState.RESCUE_REQUEST, "trapped")


func mark_injured() -> void:
	if health:
		health.apply_damage(52.0)


func receive_social_panic(intensity: float) -> void:
	social_panic = maxf(social_panic, intensity)


func receive_crowd_density(density: float) -> void:
	crowd_density = density


func get_rescue_priority() -> float:
	var type_bonus := 0.18 if npc_type == NPCType.JUNIOR_STUDENT else 0.0
	var injured_bonus := 0.25 if state == PanicState.INJURED or state == PanicState.COLLAPSE else 0.0
	return clampf(_danger_score() * 0.45 + (1.0 - health.normalized()) * 0.35 + type_bonus + injured_bonus, 0.0, 1.0)


func _update_ai_tick(delta: float) -> void:
	var lod := crowd_manager.desired_lod_for(self) if crowd_manager else 0
	var interval := ai_tick_near if lod == 0 else ai_tick_mid if lod == 1 else ai_tick_far
	ai_timer -= delta
	if ai_timer > 0.0:
		return
	ai_timer = interval
	_sample_danger(interval)
	panic_system.update_panic(interval, danger, social_panic + crowd_density * 0.35, rescue_behavior.is_guided())
	social_panic = move_toward(social_panic, 0.0, interval * 0.25)
	var state_dict := {
		"COLLAPSE": PanicState.COLLAPSE,
		"RESCUE_REQUEST": PanicState.RESCUE_REQUEST,
		"GUIDED": PanicState.GUIDED,
		"INJURED": PanicState.INJURED,
		"ESCAPE": PanicState.ESCAPE,
		"PANIC": PanicState.PANIC,
		"ALERT": PanicState.ALERT
	}
	_change_state(panic_system.choose_state(state, state_dict, danger, health.normalized(), trapped, rescue_behavior.is_guided()), "evaluation")
	if panic_system.should_scream(Time.get_ticks_msec() * 0.001) and crowd_manager:
		crowd_manager.notify_scream(global_position, panic_system.panic)
	_update_destination(interval)
	rescue_priority_changed.emit(self, get_rescue_priority())


func _sample_danger(delta: float) -> void:
	if danger_analysis and danger_analysis.has_method("danger_breakdown_at"):
		danger = danger_analysis.call("danger_breakdown_at", global_position, room_id)
	else:
		danger = {"fire": 0.0, "smoke": 0.0, "heat": 0.0, "collapse": 0.0, "injury": 1.0 - health.normalized()}
	health.update_exposure(delta, float(danger.get("smoke", 0.0)), float(danger.get("heat", 0.0)), 1.0 - float(danger.get("smoke", 0.0)) * 0.5)


func _update_destination(delta: float) -> void:
	if not pathfinding:
		return
	if state == PanicState.GUIDED and rescue_behavior.guided_by:
		pathfinding.set_target(rescue_behavior.guided_by.global_position, true)
	elif state == PanicState.ESCAPE or state == PanicState.INJURED:
		var exits: Array[Node3D] = []
		for exit in get_tree().get_nodes_in_group(evacuation_exits_group):
			if exit is Node3D:
				exits.append(exit)
		pathfinding.update_route(delta, global_position, exits)
	elif state == PanicState.PANIC:
		if random_wander == Vector3.ZERO or randf() < 0.12:
			random_wander = global_position + Vector3(randf_range(-9.0, 9.0), 0.0, randf_range(-9.0, 9.0))
		pathfinding.set_target(random_wander)


func _apply_movement(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1
	var desired := Vector3.ZERO
	if freeze_timer > 0.0:
		freeze_timer -= delta
	elif state == PanicState.COLLAPSE or state == PanicState.RESCUE_REQUEST:
		desired = Vector3.ZERO
	elif state in [PanicState.PANIC, PanicState.ESCAPE, PanicState.INJURED, PanicState.GUIDED]:
		if panic_system.should_freeze():
			freeze_timer = randf_range(0.5, 1.8)
		else:
			desired = pathfinding.next_direction(global_position) if pathfinding else Vector3.ZERO
	var speed := _speed_for_state()
	velocity.x = move_toward(velocity.x, desired.x * speed, acceleration * delta)
	velocity.z = move_toward(velocity.z, desired.z * speed, acceleration * delta)
	if desired.length_squared() > 0.05:
		look_at(global_position + desired, Vector3.UP)
	move_and_slide()


func _speed_for_state() -> float:
	match state:
		PanicState.PANIC:
			return panic_sprint_speed
		PanicState.ESCAPE, PanicState.GUIDED:
			return lerpf(walk_speed, run_speed, panic_system.panic)
		PanicState.INJURED:
			return injured_speed
		_:
			return walk_speed


func _change_state(next_state: int, _reason: String) -> void:
	if state == next_state:
		return
	state = next_state
	set_meta("interaction_label", _interaction_label())
	npc_state_changed.emit(self, state)


func _interaction_label() -> String:
	match state:
		PanicState.COLLAPSE:
			return "Revive " + npc_name
		PanicState.INJURED:
			return "Assist " + npc_name
		PanicState.RESCUE_REQUEST:
			return "Free " + npc_name
		PanicState.PANIC:
			return "Calm " + npc_name
		PanicState.GUIDED:
			return "Guide " + npc_name
		_:
			return "Talk to " + npc_name


func _update_animation() -> void:
	if not animation_tree:
		return
	animation_tree.set("parameters/Panic/blend_amount", panic_system.panic)
	animation_tree.set("parameters/Move/blend_position", Vector2(velocity.x, velocity.z).length())
	animation_tree.set("parameters/Injured/blend_amount", 1.0 - health.normalized())
	animation_tree.set("parameters/Smoke/blend_amount", float(danger.get("smoke", 0.0)))


func _on_voice_requested(category: String, intensity: float) -> void:
	if voice_player and not voice_player.playing:
		voice_player.unit_size = lerpf(5.0, 14.0, intensity)
		voice_player.play()


func _danger_score() -> float:
	return clampf(float(danger.get("fire", 0.0)) * 0.35 + float(danger.get("smoke", 0.0)) * 0.3 + float(danger.get("collapse", 0.0)) * 0.25 + float(danger.get("heat", 0.0)) * 0.1, 0.0, 1.0)


func _ensure_children() -> void:
	if not navigation_agent:
		navigation_agent = NavigationAgent3D.new()
		navigation_agent.name = "NavigationAgent3D"
		add_child(navigation_agent)
	if not panic_system:
		panic_system = PanicSystem.new()
		panic_system.name = "PanicSystem"
		add_child(panic_system)
	if not pathfinding:
		pathfinding = PathfindingSystem.new()
		pathfinding.name = "PathfindingSystem"
		add_child(pathfinding)
	if not rescue_behavior:
		rescue_behavior = RescueBehavior.new()
		rescue_behavior.name = "RescueBehavior"
		add_child(rescue_behavior)
	if not health:
		health = NPCHealth.new()
		health.name = "NPCHealth"
		add_child(health)


func _apply_type_profile() -> void:
	var profiles := {
		NPCType.STUDENT: {"courage": 0.32, "discipline": 0.28, "empathy": 0.42},
		NPCType.TEACHER: {"courage": 0.62, "discipline": 0.76, "empathy": 0.72},
		NPCType.INJURED: {"courage": 0.26, "discipline": 0.3, "empathy": 0.38, "initial_panic": 0.35},
		NPCType.SECURITY_STAFF: {"courage": 0.78, "discipline": 0.82, "empathy": 0.58},
		NPCType.JUNIOR_STUDENT: {"courage": 0.16, "discipline": 0.12, "empathy": 0.48, "initial_panic": 0.25}
	}
	panic_system.configure(profiles[npc_type])
	if npc_type == NPCType.INJURED:
		health.health = health.max_health * 0.5
		rescue_behavior.can_be_carried = true


func _bind_world_systems() -> void:
	var crowds := get_tree().get_nodes_in_group("crowd_manager")
	if not crowds.is_empty():
		crowd_manager = crowds[0] as CrowdManager
		crowd_manager.register_npc(self)
	var danger_nodes := get_tree().get_nodes_in_group("danger_analysis")
	if not danger_nodes.is_empty():
		danger_analysis = danger_nodes[0]
	pathfinding.bind(navigation_agent, danger_analysis, crowd_manager)
