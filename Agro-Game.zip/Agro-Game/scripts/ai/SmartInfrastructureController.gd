class_name SmartInfrastructureController
extends Node3D

signal infrastructure_action(action: String, target_id: String)

@export var door_group := "smart_door"
@export var sprinkler_group := "sprinkler_zone"
@export var vent_group := "ventilation_zone"
@export var lighting_group := "emergency_light"


func unlock_safe_exits() -> void:
	for node in get_tree().get_nodes_in_group(door_group):
		if bool(node.get_meta("emergency_exit", false)) and node.has_method("unlock"):
			node.call("unlock")
			infrastructure_action.emit("unlock", node.name)


func seal_danger_zone(zone_id: String) -> void:
	for node in get_tree().get_nodes_in_group(door_group):
		if String(node.get_meta("zone_id", "")) == zone_id and node.has_method("lock"):
			node.call("lock")
			node.set_meta("blocked", true)
			infrastructure_action.emit("seal", zone_id)


func activate_sprinklers(zone_id: String) -> void:
	for node in get_tree().get_nodes_in_group(sprinkler_group):
		if String(node.get_meta("zone_id", "")) == zone_id and node.has_method("activate"):
			node.call("activate")
			infrastructure_action.emit("sprinkler", zone_id)


func boost_ventilation(zone_id: String) -> void:
	for node in get_tree().get_nodes_in_group(vent_group):
		if String(node.get_meta("zone_id", "")) == zone_id and node.has_method("open_ventilation"):
			node.call("open_ventilation")
			infrastructure_action.emit("ventilation", zone_id)


func set_emergency_lighting(enabled: bool) -> void:
	for node in get_tree().get_nodes_in_group(lighting_group):
		if node.has_method("set_emergency_enabled"):
			node.call("set_emergency_enabled", enabled)
	infrastructure_action.emit("lighting", "global")
