class_name CrowdManager
extends Node3D

signal panic_wave(origin: Vector3, intensity: float)
signal bottleneck_detected(position: Vector3, density: float)

@export var update_interval := 0.25
@export var cell_size := 5.0
@export var panic_spread_radius := 9.0
@export var max_full_ai_distance := 42.0

var npcs: Array[Node3D] = []
var density_grid: Dictionary = {}
var tick := 0.0
var player: Node3D


func _ready() -> void:
	add_to_group("crowd_manager")


func register_npc(npc: Node3D) -> void:
	if not npcs.has(npc):
		npcs.append(npc)


func unregister_npc(npc: Node3D) -> void:
	npcs.erase(npc)


func _process(delta: float) -> void:
	tick -= delta
	if tick > 0.0:
		return
	tick = update_interval
	_resolve_player()
	_rebuild_density()
	_update_social_panic()


func crowd_density_at(point: Vector3, radius: float = 5.0) -> float:
	var count := 0
	for npc in npcs:
		if is_instance_valid(npc) and npc.global_position.distance_to(point) <= radius:
			count += 1
	return clampf(float(count) / 9.0, 0.0, 1.0)


func desired_lod_for(npc: Node3D) -> int:
	if not player:
		return 1
	var distance := npc.global_position.distance_to(player.global_position)
	if distance < max_full_ai_distance:
		return 0
	if distance < max_full_ai_distance * 1.8:
		return 1
	return 2


func notify_scream(origin: Vector3, intensity: float) -> void:
	panic_wave.emit(origin, intensity)
	for npc in npcs:
		if not is_instance_valid(npc) or npc.global_position.distance_to(origin) > panic_spread_radius:
			continue
		if npc.has_method("receive_social_panic"):
			npc.call("receive_social_panic", intensity)


func _rebuild_density() -> void:
	density_grid.clear()
	for npc in npcs:
		if not is_instance_valid(npc):
			continue
		var key := Vector2i(floori(npc.global_position.x / cell_size), floori(npc.global_position.z / cell_size))
		density_grid[key] = int(density_grid.get(key, 0)) + 1
		if int(density_grid[key]) >= 7:
			bottleneck_detected.emit(npc.global_position, clampf(float(density_grid[key]) / 12.0, 0.0, 1.0))


func _update_social_panic() -> void:
	for npc in npcs:
		if not is_instance_valid(npc) or not npc.has_method("receive_crowd_density"):
			continue
		npc.call("receive_crowd_density", crowd_density_at(npc.global_position, cell_size))


func _resolve_player() -> void:
	if player and is_instance_valid(player):
		return
	var players := get_tree().get_nodes_in_group("player")
	if not players.is_empty() and players[0] is Node3D:
		player = players[0] as Node3D
