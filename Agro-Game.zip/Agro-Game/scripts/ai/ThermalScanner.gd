class_name ThermalScanner
extends Node3D

signal survivor_detected(npc: Node3D, priority: float)
signal scan_completed(results: Array)

@export var scan_interval := 1.0
@export var scan_radius := 28.0
@export var max_results := 12
@export var survivor_group := "survivor"

var tick := 0.0
var last_results: Array = []


func _ready() -> void:
	add_to_group("thermal_scanner")


func _process(delta: float) -> void:
	tick -= delta
	if tick <= 0.0:
		tick = scan_interval
		scan(global_position)


func scan(origin: Vector3) -> Array:
	var results: Array = []
	for node in get_tree().get_nodes_in_group(survivor_group):
		if not node is Node3D:
			continue
		var npc := node as Node3D
		var distance := npc.global_position.distance_to(origin)
		if distance > scan_radius:
			continue
		var priority := 1.0 - distance / scan_radius
		if npc.has_method("get_rescue_priority"):
			priority = maxf(priority, float(npc.call("get_rescue_priority")))
		results.append({"npc": npc, "position": npc.global_position, "priority": priority, "distance": distance})
	results.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a["priority"]) > float(b["priority"]))
	if results.size() > max_results:
		results.resize(max_results)
	last_results = results
	for result in results:
		survivor_detected.emit(result["npc"], result["priority"])
	scan_completed.emit(results)
	return results
