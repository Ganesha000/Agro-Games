class_name DangerAnalysis
extends Node3D

signal danger_zone_updated(zone_id: String, danger: float)
signal critical_zone_detected(zone_id: String, position: Vector3, danger: float)

@export var analysis_interval := 0.25
@export var fire_weight := 0.36
@export var smoke_weight := 0.28
@export var heat_weight := 0.18
@export var collapse_weight := 0.18
@export var critical_threshold := 0.78

var tick := 0.0
var zones: Dictionary = {}
var fire_manager: FireManager
var smoke_manager: SmokeManager


func _ready() -> void:
	add_to_group("danger_analysis")
	_resolve_sources()


func _process(delta: float) -> void:
	tick -= delta
	if tick > 0.0:
		return
	tick = analysis_interval
	_resolve_sources()
	_update_known_zones()


func danger_at(point: Vector3, radius: float = 5.0) -> float:
	var best := 0.0
	if fire_manager:
		for fire in fire_manager.active_fires:
			if not is_instance_valid(fire):
				continue
			var distance_factor := 1.0 - clampf(fire.global_position.distance_to(point) / radius, 0.0, 1.0)
			best = maxf(best, fire.intensity * distance_factor)
	if smoke_manager:
		for zone_key in smoke_manager.zones.keys():
			var zone := smoke_manager.zones[zone_key] as SmokeZone
			if zone and zone.global_position.distance_to(point) <= maxf(radius, zone.size.length() * 0.35):
				best = maxf(best, zone.smoke_density * 0.85)
	return clampf(best, 0.0, 1.0)


func danger_breakdown_at(point: Vector3, room_id: String = "") -> Dictionary:
	var fire := 0.0
	var heat := 0.0
	var smoke := 0.0
	var collapse := 0.0
	if fire_manager:
		for active_fire in fire_manager.active_fires:
			if not is_instance_valid(active_fire):
				continue
			var distance_factor := 1.0 - clampf(active_fire.global_position.distance_to(point) / 12.0, 0.0, 1.0)
			fire = maxf(fire, active_fire.intensity * distance_factor)
			heat = maxf(heat, active_fire.heat_output * 0.012 * distance_factor)
	if smoke_manager:
		for zone_key in smoke_manager.zones.keys():
			var zone := smoke_manager.zones[zone_key] as SmokeZone
			if zone and (String(zone_key) == room_id or zone.is_player_inside(point)):
				smoke = maxf(smoke, zone.smoke_density)
				heat = maxf(heat, inverse_lerp(34.0, 90.0, zone.temperature))
	if zones.has(room_id):
		collapse = float(zones[room_id].get("collapse", 0.0))
	return {"fire": clampf(fire, 0.0, 1.0), "smoke": clampf(smoke, 0.0, 1.0), "heat": clampf(heat, 0.0, 1.0), "collapse": clampf(collapse, 0.0, 1.0)}


func set_structural_risk(zone_id: String, world_position: Vector3, risk: float) -> void:
	var data: Dictionary = zones.get(zone_id, {"position": world_position, "fire": 0.0, "smoke": 0.0, "heat": 0.0, "collapse": 0.0}) as Dictionary
	data["position"] = world_position
	data["collapse"] = clampf(risk, 0.0, 1.0)
	zones[zone_id] = data


func safest_zone_position() -> Vector3:
	var best := Vector3.ZERO
	var best_score := INF
	for zone_id in zones.keys():
		var data := zones[zone_id] as Dictionary
		var score := _score(data)
		if score < best_score:
			best_score = score
			best = data.get("position", Vector3.ZERO)
	return best


func _update_known_zones() -> void:
	if smoke_manager:
		for zone_key in smoke_manager.zones.keys():
			var zone := smoke_manager.zones[zone_key] as SmokeZone
			var data: Dictionary = zones.get(String(zone_key), {}) as Dictionary
			data["position"] = zone.global_position
			data["smoke"] = zone.smoke_density
			data["heat"] = inverse_lerp(30.0, 90.0, zone.temperature)
			zones[String(zone_key)] = data
	for zone_id in zones.keys():
		var data := zones[zone_id] as Dictionary
		var danger := _score(data)
		danger_zone_updated.emit(String(zone_id), danger)
		if danger >= critical_threshold:
			critical_zone_detected.emit(String(zone_id), data.get("position", Vector3.ZERO), danger)


func _score(data: Dictionary) -> float:
	return clampf(float(data.get("fire", 0.0)) * fire_weight + float(data.get("smoke", 0.0)) * smoke_weight + float(data.get("heat", 0.0)) * heat_weight + float(data.get("collapse", 0.0)) * collapse_weight, 0.0, 1.0)


func _resolve_sources() -> void:
	if not fire_manager:
		var fires := get_tree().get_nodes_in_group("fire_manager")
		if not fires.is_empty():
			fire_manager = fires[0] as FireManager
	if not smoke_manager:
		var smokes := get_tree().get_nodes_in_group("smoke_manager")
		if not smokes.is_empty():
			smoke_manager = smokes[0] as SmokeManager
