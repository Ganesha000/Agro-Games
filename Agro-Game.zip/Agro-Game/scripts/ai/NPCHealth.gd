class_name NPCHealth
extends Node

signal injured(severity: float)
signal collapsed
signal revived
signal died

@export var max_health := 100.0
@export var smoke_damage_rate := 8.0
@export var heat_damage_rate := 15.0
@export var oxygen_damage_rate := 20.0
@export var revive_health := 28.0

var health := 100.0
var oxygen := 1.0
var smoke_exposure := 0.0
var heat_exposure := 0.0
var is_collapsed := false
var is_dead := false


func _ready() -> void:
	health = max_health


func update_exposure(delta: float, smoke: float, heat: float, oxygen_level: float) -> void:
	if is_dead:
		return
	smoke_exposure = smoke
	heat_exposure = heat
	oxygen = oxygen_level
	var damage := smoke * smoke_damage_rate + maxf(0.0, heat - 0.35) * heat_damage_rate
	damage += maxf(0.0, 0.45 - oxygen_level) * oxygen_damage_rate
	apply_damage(damage * delta)


func apply_damage(amount: float) -> void:
	if amount <= 0.0 or is_dead:
		return
	health = clampf(health - amount, 0.0, max_health)
	if health <= 0.0:
		is_dead = true
		died.emit()
	elif health < max_health * 0.18 and not is_collapsed:
		is_collapsed = true
		collapsed.emit()
	elif health < max_health * 0.55:
		injured.emit(1.0 - health / max_health)


func revive() -> void:
	if is_dead:
		return
	is_collapsed = false
	health = maxf(health, revive_health)
	revived.emit()


func normalized() -> float:
	return clampf(health / max_health, 0.0, 1.0)
