class_name RescueBehavior
extends Node

signal guide_started(player: Node3D)
signal guide_stopped
signal carry_requested(npc: Node)
signal revived

@export var trust_required := 0.18
@export var calm_strength := 0.4
@export var carry_interaction_label := "Carry survivor"
@export var revive_interaction_label := "Revive survivor"

var guided_by: Node3D
var trust := 0.35
var can_be_carried := false


func request_guidance(player: Node3D, panic_level: float, danger_level: float) -> bool:
	if not is_instance_valid(player):
		return false
	var confidence := trust + calm_strength - panic_level * 0.28 - danger_level * 0.12
	if confidence < trust_required and randf() > confidence:
		return false
	guided_by = player
	trust = clampf(trust + 0.12, 0.0, 1.0)
	guide_started.emit(player)
	return true


func stop_guidance() -> void:
	guided_by = null
	guide_stopped.emit()


func request_carry(npc: Node) -> void:
	can_be_carried = true
	carry_requested.emit(npc)


func revive() -> void:
	trust = clampf(trust + 0.2, 0.0, 1.0)
	revived.emit()


func is_guided() -> bool:
	return is_instance_valid(guided_by)
