class_name PlayerHealth
extends Node

signal health_changed(current: float, maximum: float)
signal oxygen_changed(current: float, maximum: float)
signal critical_state_changed(is_critical: bool)
signal collapsed(reason: String)
signal damage_taken(amount: float, damage_type: String)

@export var max_health := 100.0
@export var max_oxygen := 100.0
@export var safe_zone_regen_per_second := 4.0
@export var oxygen_recovery_per_second := 9.0
@export var critical_health_threshold := 28.0
@export var collapse_health_threshold := 1.0
@export var collapse_oxygen_threshold := 1.0

var current_health := 100.0
var current_oxygen := 100.0
var injury_level := 0.0
var stress_level := 0.0
var is_critical := false
var is_collapsed := false


func _ready() -> void:
	current_health = max_health
	current_oxygen = max_oxygen
	_emit_state()


func update_survival(delta: float, safe_zone_factor: float, smoke_density: float, heat_level: float) -> void:
	if is_collapsed:
		return

	if smoke_density > 0.02:
		var oxygen_loss := lerpf(1.5, 18.0, clampf(smoke_density, 0.0, 1.0))
		current_oxygen = maxf(0.0, current_oxygen - oxygen_loss * delta)
		if smoke_density > 0.35:
			apply_damage(smoke_density * 7.5 * delta, "smoke_inhalation")
	else:
		current_oxygen = minf(max_oxygen, current_oxygen + oxygen_recovery_per_second * safe_zone_factor * delta)

	if heat_level > 0.05:
		apply_damage(heat_level * 16.0 * delta, "heat_fire")

	if safe_zone_factor > 0.75 and smoke_density < 0.05 and heat_level < 0.05:
		current_health = minf(max_health, current_health + safe_zone_regen_per_second * delta)

	injury_level = 1.0 - (current_health / max_health)
	var oxygen_stress := 1.0 - current_oxygen / max_oxygen
	stress_level = clampf(maxf(maxf(injury_level, smoke_density), maxf(heat_level, oxygen_stress)), 0.0, 1.0)
	_update_critical()
	_emit_state()

	if current_health <= collapse_health_threshold:
		_collapse("injury")
	elif current_oxygen <= collapse_oxygen_threshold:
		_collapse("oxygen_loss")


func apply_damage(amount: float, damage_type: String) -> void:
	if is_collapsed or amount <= 0.0:
		return
	current_health = maxf(0.0, current_health - amount)
	damage_taken.emit(amount, damage_type)
	_update_critical()
	_emit_state()


func apply_blast_damage(amount: float, deafness_stress: float) -> void:
	apply_damage(amount, "explosion")
	stress_level = clampf(stress_level + deafness_stress, 0.0, 1.0)


func health_ratio() -> float:
	return current_health / max_health


func oxygen_ratio() -> float:
	return current_oxygen / max_oxygen


func movement_penalty() -> float:
	if current_health > 55.0:
		return 1.0
	return lerpf(0.55, 1.0, clampf(current_health / 55.0, 0.0, 1.0))


func _update_critical() -> void:
	var next_critical := current_health <= critical_health_threshold or current_oxygen <= critical_health_threshold
	if next_critical != is_critical:
		is_critical = next_critical
		critical_state_changed.emit(is_critical)


func _collapse(reason: String) -> void:
	if is_collapsed:
		return
	is_collapsed = true
	collapsed.emit(reason)


func _emit_state() -> void:
	health_changed.emit(current_health, max_health)
	oxygen_changed.emit(current_oxygen, max_oxygen)
