class_name AudioController
extends Node

@export var footstep_interval_walk := 0.48
@export var footstep_interval_sprint := 0.30
@export var breathing_min_db := -28.0
@export var breathing_max_db := -6.0

var footstep_timer := 0.0
var surface_name := "tile"
var breathing_intensity := 0.0
var heartbeat_intensity := 0.0
var muffled_intensity := 0.0

@onready var footstep_player: AudioStreamPlayer3D = $Footsteps
@onready var breathing_player: AudioStreamPlayer = $Breathing
@onready var cough_player: AudioStreamPlayer = $Cough
@onready var heartbeat_player: AudioStreamPlayer = $Heartbeat
@onready var pain_player: AudioStreamPlayer = $Pain
@onready var interaction_player: AudioStreamPlayer = $Interaction


func _ready() -> void:
	_start_loop_if_stream_exists(breathing_player)
	_start_loop_if_stream_exists(heartbeat_player)


func update_audio(delta: float, speed_ratio: float, is_sprinting: bool, stamina_ratio: float, smoke_density: float, health_ratio: float, stress: float, is_grounded: bool) -> void:
	var breathing_target := maxf(maxf(1.0 - stamina_ratio, smoke_density), stress * 0.75)
	breathing_intensity = lerpf(breathing_intensity, breathing_target, 1.0 - exp(-5.0 * delta))
	heartbeat_intensity = lerpf(heartbeat_intensity, clampf(1.0 - health_ratio + stress * 0.4, 0.0, 1.0), 1.0 - exp(-4.0 * delta))
	muffled_intensity = lerpf(muffled_intensity, smoke_density, 1.0 - exp(-3.0 * delta))

	breathing_player.volume_db = lerpf(breathing_min_db, breathing_max_db, breathing_intensity)
	heartbeat_player.volume_db = lerpf(-34.0, -7.0, heartbeat_intensity)

	if is_grounded and speed_ratio > 0.12:
		var interval: float = lerpf(footstep_interval_walk, footstep_interval_sprint, 1.0 if is_sprinting else speed_ratio)
		footstep_timer -= delta
		if footstep_timer <= 0.0:
			_play_footstep(speed_ratio)
			footstep_timer = interval
	else:
		footstep_timer = minf(footstep_timer, 0.08)


func play_cough(intensity: float) -> void:
	cough_player.pitch_scale = randf_range(0.92, 1.08)
	cough_player.volume_db = lerpf(-14.0, -3.0, intensity)
	cough_player.play()


func play_pain(amount: float) -> void:
	pain_player.volume_db = lerpf(-18.0, -4.0, clampf(amount / 25.0, 0.0, 1.0))
	pain_player.pitch_scale = randf_range(0.9, 1.05)
	pain_player.play()


func play_interaction() -> void:
	interaction_player.play()


func _play_footstep(speed_ratio: float) -> void:
	footstep_player.pitch_scale = randf_range(0.92, 1.08) + speed_ratio * 0.08
	footstep_player.volume_db = lerpf(-17.0, -7.0, speed_ratio)
	footstep_player.play()


func _start_loop_if_stream_exists(player: AudioStreamPlayer) -> void:
	if player and player.stream:
		player.play()
