class_name PlayerMovement
extends CharacterBody3D

enum Stance { STAND, CROUCH, CRAWL }

@export var walk_speed := 4.2
@export var sprint_speed := 7.0
@export var crouch_speed := 2.15
@export var crawl_speed := 1.05
@export var acceleration := 11.0
@export var deceleration := 14.0
@export var air_control := 0.35
@export var jump_velocity := 4.8
@export var gravity := 18.5
@export var mouse_capture_enabled := true
@export var carrying_speed_multiplier := 0.62
@export var floor_snap := 0.35
@export var max_floor_angle_degrees := 52.0

var stance: int = Stance.STAND
var is_sprinting := false
var is_carrying := false
var was_grounded := true
var last_vertical_velocity := 0.0
var desired_velocity := Vector3.ZERO
var input_vector := Vector2.ZERO

@onready var collision_shape: CollisionShape3D = $CollisionShape3D
@onready var camera_system: PlayerCamera = $Neck/CameraRig
@onready var interaction: PlayerInteraction = $Neck/CameraRig/Camera3D/InteractionRay
@onready var health: PlayerHealth = $Systems/PlayerHealth
@onready var stamina: StaminaSystem = $Systems/StaminaSystem
@onready var smoke: SmokeSystem = $Systems/SmokeProbe
@onready var audio: AudioController = $Systems/AudioController
@onready var animation: AnimationController = $Systems/AnimationController
@onready var prompt_label: Label3D = $Neck/PromptLabel
@onready var body_visual: Node3D = $BodyVisual


func _ready() -> void:
	add_to_group("player")
	floor_snap_length = floor_snap
	floor_max_angle = deg_to_rad(max_floor_angle_degrees)
	_ensure_input_actions()
	body_visual.visible = camera_system.is_third_person
	if mouse_capture_enabled:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	interaction.prompt_changed.connect(_on_prompt_changed)
	interaction.interaction_performed.connect(_on_interaction_performed)
	smoke.cough_requested.connect(_on_cough_requested)
	health.damage_taken.connect(_on_damage_taken)
	health.collapsed.connect(_on_collapsed)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		camera_system.apply_mouse_motion(event.relative, self)
	if event.is_action_pressed("interact"):
		interaction.try_interact()
	if event.is_action_pressed("toggle_camera_capture"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED
	if event.is_action_pressed("toggle_perspective"):
		body_visual.visible = camera_system.toggle_perspective()


func _physics_process(delta: float) -> void:
	if health.is_collapsed:
		velocity.x = move_toward(velocity.x, 0.0, deceleration * delta)
		velocity.z = move_toward(velocity.z, 0.0, deceleration * delta)
		velocity.y -= gravity * delta
		move_and_slide()
		return

	_read_input()
	_update_stance()
	_update_movement(delta)
	_update_survival_systems(delta)
	interaction.update_interaction()
	move_and_slide()
	_update_landing()
	_update_feedback(delta)


func _read_input() -> void:
	input_vector = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var wants_sprint := Input.is_action_pressed("sprint") and stance == Stance.STAND and input_vector.y < -0.1
	is_sprinting = wants_sprint and not stamina.is_exhausted and stamina.current_stamina > 1.0


func _update_stance() -> void:
	if Input.is_action_pressed("crawl"):
		stance = Stance.CRAWL
	elif Input.is_action_pressed("crouch") or smoke.is_heavy_smoke():
		stance = Stance.CROUCH
	else:
		stance = Stance.STAND
	_resize_capsule_for_stance()


func _update_movement(delta: float) -> void:
	var movement_basis := global_transform.basis
	var forward := -movement_basis.z
	var right := movement_basis.x
	var direction := (right * input_vector.x + forward * -input_vector.y).normalized()
	var speed := _target_speed()
	var control: float = 1.0 if is_on_floor() else air_control
	desired_velocity = direction * speed

	var current_horizontal := Vector3(velocity.x, 0.0, velocity.z)
	var rate: float = acceleration if direction.length() > 0.01 else deceleration
	current_horizontal = current_horizontal.lerp(desired_velocity, 1.0 - exp(-rate * control * delta))
	velocity.x = current_horizontal.x
	velocity.z = current_horizontal.z

	if is_on_floor():
		if Input.is_action_just_pressed("jump") and stance == Stance.STAND and not is_carrying:
			velocity.y = jump_velocity
			camera_system.add_trauma(0.08)
		else:
			velocity.y = -0.1
	else:
		velocity.y -= gravity * delta

	last_vertical_velocity = velocity.y


func _target_speed() -> float:
	var speed := walk_speed
	if stance == Stance.CROUCH:
		speed = crouch_speed
	elif stance == Stance.CRAWL:
		speed = crawl_speed
	elif is_sprinting:
		speed = sprint_speed
	if is_carrying:
		speed *= carrying_speed_multiplier
	speed *= health.movement_penalty()
	if stamina.is_exhausted:
		speed *= 0.78
	return speed


func _update_survival_systems(delta: float) -> void:
	var is_moving := Vector3(velocity.x, 0.0, velocity.z).length() > 0.15
	stamina.update_stamina(delta, is_sprinting, is_moving, stance == Stance.CRAWL, is_carrying)
	var safe_zone_factor: float = 1.0 if smoke.smoke_density < 0.04 and smoke.heat_level < 0.04 else 0.0
	health.update_survival(delta, safe_zone_factor, smoke.smoke_density, smoke.heat_level)


func _update_landing() -> void:
	var grounded := is_on_floor()
	if grounded and not was_grounded:
		camera_system.landing_impact(last_vertical_velocity)
		if absf(last_vertical_velocity) > 9.0:
			health.apply_damage((absf(last_vertical_velocity) - 9.0) * 2.8, "fall")
	was_grounded = grounded


func _update_feedback(delta: float) -> void:
	var horizontal_speed := Vector3(velocity.x, 0.0, velocity.z).length()
	var speed_ratio := clampf(horizontal_speed / sprint_speed, 0.0, 1.0)
	camera_system.update_camera(delta, speed_ratio, is_sprinting, stance, stamina.stamina_ratio(), health.stress_level, smoke.smoke_density, smoke.heat_level, is_on_floor())
	audio.update_audio(delta, speed_ratio, is_sprinting, stamina.stamina_ratio(), smoke.smoke_density, health.health_ratio(), health.stress_level, is_on_floor())
	animation.update_animation(speed_ratio, stance, is_sprinting, is_on_floor(), is_carrying, health.current_health < 45.0)


func _resize_capsule_for_stance() -> void:
	var capsule := collision_shape.shape as CapsuleShape3D
	if capsule == null:
		return
	var target_height := 1.78
	if stance == Stance.CROUCH:
		target_height = 1.15
	elif stance == Stance.CRAWL:
		target_height = 0.62
	capsule.height = lerpf(capsule.height, target_height, 0.24)
	collision_shape.position.y = capsule.height * 0.5


func apply_environment_hit(kind: String, amount: float, trauma: float) -> void:
	health.apply_damage(amount, kind)
	camera_system.add_trauma(trauma)
	if kind == "explosion":
		health.apply_blast_damage(amount, trauma)


func set_carrying_npc(enabled: bool) -> void:
	is_carrying = enabled


func _on_prompt_changed(prompt: String) -> void:
	prompt_label.text = prompt
	prompt_label.visible = prompt != ""


func _on_interaction_performed(_target: Node, interaction_type: String) -> void:
	audio.play_interaction()
	animation.play_interaction(interaction_type)
	if interaction_type == "carry_npc":
		set_carrying_npc(true)


func _on_cough_requested(intensity: float) -> void:
	audio.play_cough(intensity)
	camera_system.add_trauma(0.08 + intensity * 0.12)


func _on_damage_taken(amount: float, _damage_type: String) -> void:
	audio.play_pain(amount)
	camera_system.add_trauma(clampf(amount / 35.0, 0.03, 0.35))


func _on_collapsed(reason: String) -> void:
	prompt_label.visible = true
	prompt_label.text = "Harshit collapsed: " + reason
	camera_system.add_trauma(0.6)


func _ensure_input_actions() -> void:
	_ensure_key_action("move_forward", [KEY_W, KEY_UP])
	_ensure_key_action("move_back", [KEY_S, KEY_DOWN])
	_ensure_key_action("move_left", [KEY_A, KEY_LEFT])
	_ensure_key_action("move_right", [KEY_D, KEY_RIGHT])
	_ensure_key_action("sprint", [KEY_SHIFT])
	_ensure_key_action("crouch", [KEY_CTRL])
	_ensure_key_action("crawl", [KEY_C])
	_ensure_key_action("jump", [KEY_SPACE])
	_ensure_key_action("interact", [KEY_E])
	_ensure_key_action("toggle_camera_capture", [KEY_ESCAPE])
	_ensure_key_action("toggle_perspective", [KEY_V])


func _ensure_key_action(action_name: String, physical_keys: Array) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	if not InputMap.action_get_events(action_name).is_empty():
		return
	for keycode: int in physical_keys:
		var event := InputEventKey.new()
		event.physical_keycode = keycode as Key
		InputMap.action_add_event(action_name, event)
