class_name PlayerCamera
extends Node3D

@export var camera_path: NodePath = NodePath("Camera3D")
@export var mouse_sensitivity := 0.0022
@export var normal_height := 1.65
@export var crouch_height := 1.05
@export var crawl_height := 0.42
@export var normal_fov := 72.0
@export var sprint_fov := 82.0
@export var crouch_fov := 68.0
@export var max_pitch_degrees := 84.0
@export var third_person_distance := 4.5

var camera: Camera3D
var is_third_person := false
var yaw := 0.0
var pitch := 0.0
var target_yaw := 0.0
var target_pitch := 0.0
var controlled_body: Node3D
var headbob_time := 0.0
var trauma := 0.0
var breathing_phase := 0.0
var target_height := 1.65
var smoke_blindness := 0.0
var injury_intensity := 0.0
var panic_intensity := 0.0
var heat_distortion := 0.0
var base_position := Vector3.ZERO


func _ready() -> void:
	camera = get_node_or_null(camera_path) as Camera3D
	base_position = position
	target_height = normal_height
	position.y = normal_height
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func apply_mouse_motion(relative: Vector2, body: Node3D) -> void:
	controlled_body = body
	target_yaw -= relative.x * mouse_sensitivity
	target_pitch = clampf(target_pitch - relative.y * mouse_sensitivity, deg_to_rad(-max_pitch_degrees), deg_to_rad(max_pitch_degrees))


func update_camera(delta: float, speed_ratio: float, is_sprinting: bool, stance: int, stamina_ratio: float, stress: float, smoke_density: float, heat_level: float, is_grounded: bool) -> void:
	var stance_height := normal_height
	var target_fov := normal_fov
	if stance == 1:
		stance_height = crouch_height
		target_fov = crouch_fov
	elif stance == 2:
		stance_height = crawl_height
		target_fov = crouch_fov - 4.0
	elif is_sprinting:
		target_fov = sprint_fov

	target_height = stance_height
	position.y = lerpf(position.y, target_height, 1.0 - exp(-11.0 * delta))
	breathing_phase += delta * lerpf(0.8, 2.6, 1.0 - stamina_ratio)
	headbob_time += delta * lerpf(5.0, 12.0, speed_ratio)

	var headbob_strength: float = speed_ratio * (0.045 if is_grounded else 0.01)
	if stance == 2:
		headbob_strength *= 0.55
	var breathing_strength := lerpf(0.012, 0.055, maxf(1.0 - stamina_ratio, stress))
	var bob := Vector3(
		sin(headbob_time) * headbob_strength * 0.45,
		abs(sin(headbob_time * 2.0)) * headbob_strength,
		0.0
	)
	var breathing := Vector3(0.0, sin(breathing_phase) * breathing_strength, cos(breathing_phase * 0.7) * breathing_strength * 0.35)

	trauma = maxf(0.0, trauma - delta * 1.6)
	var shake := Vector3.ZERO
	if trauma > 0.001:
		var shake_amount := trauma * trauma
		shake = Vector3(randf_range(-shake_amount, shake_amount), randf_range(-shake_amount, shake_amount), 0.0) * 0.22

	position.x = lerpf(position.x, base_position.x + bob.x + shake.x, 1.0 - exp(-18.0 * delta))
	position.z = lerpf(position.z, base_position.z + breathing.z, 1.0 - exp(-12.0 * delta))
	position.y += bob.y + breathing.y + shake.y

	smoke_blindness = lerpf(smoke_blindness, smoke_density, 1.0 - exp(-5.0 * delta))
	heat_distortion = lerpf(heat_distortion, heat_level, 1.0 - exp(-6.0 * delta))
	panic_intensity = lerpf(panic_intensity, stress, 1.0 - exp(-3.0 * delta))
	yaw = lerp_angle(yaw, target_yaw, 1.0 - exp(-24.0 * delta))
	pitch = lerpf(pitch, target_pitch, 1.0 - exp(-24.0 * delta))
	if controlled_body:
		controlled_body.rotation.y = yaw
	rotation.x = pitch
	if camera:
		var camera_z: float = third_person_distance if is_third_person else 0.0
		camera.position.z = lerpf(camera.position.z, camera_z, 1.0 - exp(-9.0 * delta))
		camera.fov = lerpf(camera.fov, target_fov - smoke_blindness * 8.0 + panic_intensity * 3.0, 1.0 - exp(-6.0 * delta))
		camera.rotation.z = lerpf(camera.rotation.z, randf_range(-0.015, 0.015) * panic_intensity, 1.0 - exp(-12.0 * delta))


func add_trauma(amount: float) -> void:
	trauma = clampf(trauma + amount, 0.0, 1.0)


func landing_impact(vertical_speed: float) -> void:
	add_trauma(clampf(absf(vertical_speed) / 18.0, 0.05, 0.45))


func toggle_perspective() -> bool:
	is_third_person = not is_third_person
	return is_third_person
