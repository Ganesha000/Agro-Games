class_name AnimationController
extends Node

signal animation_state_changed(state_name: String)

@export var animation_tree_path: NodePath
@export var animation_player_path: NodePath

var current_state := "idle"
var target_blend := 0.0
var animation_tree: AnimationTree
var animation_player: AnimationPlayer


func _ready() -> void:
	if animation_tree_path != NodePath():
		animation_tree = get_node_or_null(animation_tree_path) as AnimationTree
	if animation_player_path != NodePath():
		animation_player = get_node_or_null(animation_player_path) as AnimationPlayer


func update_animation(speed_ratio: float, stance: int, is_sprinting: bool, is_grounded: bool, is_carrying: bool, is_injured: bool) -> void:
	var next_state := "idle"
	if not is_grounded:
		next_state = "jump"
	elif is_carrying:
		next_state = "carry_injured_npc"
	elif stance == 2:
		next_state = "crawl"
	elif stance == 1:
		next_state = "crouch_walk" if speed_ratio > 0.1 else "crouch_idle"
	elif is_injured and speed_ratio > 0.1:
		next_state = "injured_walk"
	elif is_sprinting and speed_ratio > 0.4:
		next_state = "sprint"
	elif speed_ratio > 0.1:
		next_state = "walk"

	if next_state != current_state:
		current_state = next_state
		animation_state_changed.emit(current_state)
		if animation_player and animation_player.has_animation(current_state):
			animation_player.play(current_state, 0.18)

	target_blend = speed_ratio
	if animation_tree:
		animation_tree.set("parameters/movement_blend/blend_amount", speed_ratio)


func play_interaction(interaction_type: String) -> void:
	var animation_name := "interact_" + interaction_type
	if animation_player and animation_player.has_animation(animation_name):
		animation_player.play(animation_name, 0.1)

