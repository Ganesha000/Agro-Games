class_name StaminaSystem
extends Node

signal stamina_changed(current: float, maximum: float)
signal exhaustion_changed(is_exhausted: bool)

@export var max_stamina := 100.0
@export var sprint_drain_per_second := 18.0
@export var carry_drain_per_second := 12.0
@export var crawl_drain_per_second := 3.0
@export var moving_recovery_per_second := 8.0
@export var resting_recovery_per_second := 18.0
@export var exhausted_threshold := 8.0
@export var recovered_threshold := 26.0

var current_stamina := 100.0
var is_exhausted := false


func _ready() -> void:
	current_stamina = max_stamina
	stamina_changed.emit(current_stamina, max_stamina)


func update_stamina(delta: float, is_sprinting: bool, is_moving: bool, is_crawling: bool, is_carrying: bool) -> void:
	var drain := 0.0
	if is_sprinting:
		drain += sprint_drain_per_second
	if is_carrying:
		drain += carry_drain_per_second
	if is_crawling and is_moving:
		drain += crawl_drain_per_second

	if drain > 0.0:
		current_stamina = maxf(0.0, current_stamina - drain * delta)
	else:
		var recovery: float = moving_recovery_per_second if is_moving else resting_recovery_per_second
		current_stamina = minf(max_stamina, current_stamina + recovery * delta)

	var next_exhausted := is_exhausted
	if current_stamina <= exhausted_threshold:
		next_exhausted = true
	elif current_stamina >= recovered_threshold:
		next_exhausted = false

	if next_exhausted != is_exhausted:
		is_exhausted = next_exhausted
		exhaustion_changed.emit(is_exhausted)

	stamina_changed.emit(current_stamina, max_stamina)


func stamina_ratio() -> float:
	return current_stamina / max_stamina
