class_name PlayerInteraction
extends RayCast3D

signal prompt_changed(prompt: String)
signal interaction_performed(target: Node, interaction_type: String)

@export var interact_distance := 3.0
@export var prompt_prefix := "E"

var current_target: Node
var current_prompt := ""


func _ready() -> void:
	enabled = true
	collide_with_areas = true
	collide_with_bodies = true
	target_position = Vector3(0, 0, -interact_distance)


func update_interaction() -> void:
	force_raycast_update()
	var next_target: Node = null
	var next_prompt := ""
	if is_colliding():
		var collider := get_collider()
		if collider is Node:
			var node := collider as Node
			if node.is_in_group("interactable") or node.has_meta("interaction_type"):
				next_target = node
				var label := String(node.get_meta("interaction_label", _label_for_type(String(node.get_meta("interaction_type", "use")))))
				next_prompt = "[%s] %s" % [prompt_prefix, label]

	if next_target != current_target or next_prompt != current_prompt:
		current_target = next_target
		current_prompt = next_prompt
		prompt_changed.emit(current_prompt)


func try_interact() -> void:
	if current_target == null:
		return
	var interaction_type := String(current_target.get_meta("interaction_type", "use"))
	if current_target.has_method("interact"):
		current_target.call("interact", owner)
	else:
		_apply_default_interaction(current_target, interaction_type)
	interaction_performed.emit(current_target, interaction_type)


func _apply_default_interaction(target: Node, interaction_type: String) -> void:
	match interaction_type:
		"door":
			target.set_meta("is_open", true)
		"emergency_glass":
			target.visible = false
			target.set_meta("is_broken", true)
		"fire_alarm":
			target.set_meta("pulled", true)
		"extinguisher":
			target.set_meta("picked_up", true)
			target.visible = false
		"carry_npc":
			target.set_meta("is_being_carried", true)
		"rescue_drone":
			target.set_meta("drone_control_active", true)
		"emergency_switch":
			target.set_meta("activated", true)
		_:
			target.set_meta("used", true)


func _label_for_type(interaction_type: String) -> String:
	match interaction_type:
		"door":
			return "Open door"
		"emergency_glass":
			return "Break emergency glass"
		"fire_alarm":
			return "Pull fire alarm"
		"extinguisher":
			return "Take extinguisher"
		"carry_npc":
			return "Carry injured student"
		"rescue_drone":
			return "Operate rescue drone"
		"emergency_switch":
			return "Activate emergency switch"
		_:
			return "Interact"
