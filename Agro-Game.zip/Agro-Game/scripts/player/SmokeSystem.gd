class_name SmokeSystem
extends Area3D

signal smoke_changed(density: float)
signal heat_changed(level: float)
signal cough_requested(intensity: float)

@export var probe_radius := 1.2
@export var smoke_decay_per_second := 0.65
@export var heat_decay_per_second := 0.9
@export var heavy_smoke_threshold := 0.55
@export var cough_interval_min := 1.8
@export var cough_interval_max := 5.0

var smoke_density := 0.0
var heat_level := 0.0
var target_smoke_density := 0.0
var target_heat_level := 0.0
var cough_timer := 3.0


func _ready() -> void:
	monitoring = true
	monitorable = false
	collision_layer = 0
	collision_mask = 1
	if get_child_count() == 0:
		var shape := CollisionShape3D.new()
		var sphere := SphereShape3D.new()
		sphere.radius = probe_radius
		shape.shape = sphere
		add_child(shape)
	area_entered.connect(_on_area_entered)
	area_exited.connect(_on_area_exited)


func _process(delta: float) -> void:
	target_smoke_density = maxf(0.0, target_smoke_density - smoke_decay_per_second * delta)
	target_heat_level = maxf(0.0, target_heat_level - heat_decay_per_second * delta)
	smoke_density = lerpf(smoke_density, target_smoke_density, 1.0 - exp(-7.0 * delta))
	heat_level = lerpf(heat_level, target_heat_level, 1.0 - exp(-7.0 * delta))
	smoke_changed.emit(smoke_density)
	heat_changed.emit(heat_level)

	if smoke_density > 0.18:
		cough_timer -= delta * lerpf(0.7, 2.5, smoke_density)
		if cough_timer <= 0.0:
			cough_requested.emit(smoke_density)
			cough_timer = randf_range(cough_interval_min, cough_interval_max)
	else:
		cough_timer = minf(cough_timer + delta, cough_interval_max)


func set_environment_exposure(smoke: float, heat: float) -> void:
	target_smoke_density = maxf(target_smoke_density, clampf(smoke, 0.0, 1.0))
	target_heat_level = maxf(target_heat_level, clampf(heat, 0.0, 1.0))


func is_heavy_smoke() -> bool:
	return smoke_density >= heavy_smoke_threshold


func _on_area_entered(area: Area3D) -> void:
	if area.is_in_group("smoke_zone"):
		target_smoke_density = maxf(target_smoke_density, float(area.get_meta("smoke_density", 0.65)))
	if area.is_in_group("heat_zone") or area.is_in_group("fire_zone"):
		target_heat_level = maxf(target_heat_level, float(area.get_meta("heat_level", 0.7)))


func _on_area_exited(_area: Area3D) -> void:
	pass

