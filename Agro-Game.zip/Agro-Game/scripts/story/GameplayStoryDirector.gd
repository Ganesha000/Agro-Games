class_name GameplayStoryDirector
extends Node

signal chapter_changed(chapter_id: String)
signal story_completed(ending_id: String)

const DRONE_SCENE := preload("res://scenes/drone/RescueDrone.tscn")

enum StoryStage {
	INTRO,
	TUTORIAL,
	WARNING_SIGNS,
	FIRE_START,
	FIRST_RESPONSE,
	KABIR_RESCUE,
	RESQTECH_ONLINE,
	LIBRARY_RESCUE,
	DRONE_UNLOCK,
	CONTROL_ROOM,
	FINAL_ESCAPE,
	ENDING
}

const STAGE_TITLES := {
	StoryStage.INTRO: "Chapter 1 - A Normal Day",
	StoryStage.TUTORIAL: "Tutorial - Learn the Campus",
	StoryStage.WARNING_SIGNS: "Chapter 2 - Warning Signs",
	StoryStage.FIRE_START: "Chapter 3 - The Fire Starts",
	StoryStage.FIRST_RESPONSE: "Chapter 4 - Panic Inside the School",
	StoryStage.KABIR_RESCUE: "First Rescue - Kabir",
	StoryStage.RESQTECH_ONLINE: "Chapter 5 - ResQTech Online",
	StoryStage.LIBRARY_RESCUE: "Chapter 6 - Library Rescue",
	StoryStage.DRONE_UNLOCK: "Advanced Tool - Rescue Drone",
	StoryStage.CONTROL_ROOM: "Chapter 8 - Control Room",
	StoryStage.FINAL_ESCAPE: "Final Chapter - The Last Escape",
	StoryStage.ENDING: "Evacuation Report"
}

const STAGE_HINTS := {
	StoryStage.INTRO: "Move with WASD. Look around SPS GN Bhopal and head toward the auditorium exhibition.",
	StoryStage.TUTORIAL: "Sprint with Shift, crouch with Ctrl, crawl with C, interact with E.",
	StoryStage.WARNING_SIGNS: "Watch the flickering systems. Press F to trigger the FIRELINE incident when ready.",
	StoryStage.FIRE_START: "Explosion detected. Stay low, avoid flames, and listen to ResQTech AI.",
	StoryStage.FIRST_RESPONSE: "Pull a fire alarm, grab an extinguisher, then look for trapped students.",
	StoryStage.KABIR_RESCUE: "Kabir is trapped near Smart Classroom B. Break emergency glass or open a safe route.",
	StoryStage.RESQTECH_ONLINE: "Follow green route markers. Smoke rises, so crouch or crawl through dense smoke.",
	StoryStage.LIBRARY_RESCUE: "Thermal scan reports Riya and junior students in the library. Reach the west wing.",
	StoryStage.DRONE_UNLOCK: "Use the rescue drone station in the auditorium to scan smoke-filled routes.",
	StoryStage.CONTROL_ROOM: "Reach the security control room and activate the exit unlock protocol.",
	StoryStage.FINAL_ESCAPE: "Evacuate to the rooftop helipad. Carry injured survivors if you can.",
	StoryStage.ENDING: "Every second matters. Review the rescue outcome and replay to improve survival."
}

var campus: Node
var player: Node3D
var stage: int = StoryStage.INTRO
var elapsed := 0.0
var survivors_rescued := 0
var systems_restored := 0
var hints_seen := {}
var flags := {
	"alarm": false,
	"extinguisher": false,
	"glass": false,
	"kabir": false,
	"library": false,
	"drone": false,
	"control": false,
	"rooftop": false
}

var canvas: CanvasLayer
var chapter_label: Label
var objective_label: Label
var ai_label: Label
var hint_label: Label
var tip_label: Label
var rescue_label: Label
var ending_panel: PanelContainer
var ending_label: Label
var active_drone: DroneController


func setup(campus_node: Node, player_node: Node3D) -> void:
	campus = campus_node
	player = player_node
	_build_story_hud()
	_bind_player()
	_set_stage(StoryStage.INTRO, "ResQTech AI: Campus systems nominal. Welcome to the annual science exhibition.")


func notify_fire_phase_started() -> void:
	if stage < StoryStage.FIRE_START:
		_set_stage(StoryStage.FIRE_START, "ResQTech AI: Emergency detected. Fire hazard level critical.")


func notify_fire_phase_ended() -> void:
	_set_stage(StoryStage.INTRO, "ResQTech AI: Training reset. Campus systems restored to normal simulation mode.")


func _process(delta: float) -> void:
	if player == null or not is_instance_valid(player):
		return
	elapsed += delta
	_update_story_by_time()
	_update_story_by_location()
	_update_survival_hints()
	_refresh_hud()


func _bind_player() -> void:
	if player == null:
		return
	var interaction := player.get_node_or_null("Neck/CameraRig/Camera3D/InteractionRay")
	if interaction and interaction.has_signal("interaction_performed"):
		interaction.interaction_performed.connect(_on_interaction_performed)


func _update_story_by_time() -> void:
	if stage == StoryStage.INTRO and elapsed > 5.0:
		_set_stage(StoryStage.TUTORIAL, "ResQTech booth objective added. Learn movement before the emergency begins.")
	elif stage == StoryStage.TUTORIAL and elapsed > 18.0:
		_set_stage(StoryStage.WARNING_SIGNS, "ResQTech AI: Minor power instability detected in Chemistry Wing.")


func _update_story_by_location() -> void:
	var pos := player.global_position
	if stage >= StoryStage.FIRE_START and stage < StoryStage.LIBRARY_RESCUE and pos.distance_to(Vector3(-58, 3, -6)) < 18.0:
		flags["library"] = true
		_set_stage(StoryStage.LIBRARY_RESCUE, "Thermal scan detected Riya and two junior students in the library zone.")
	if stage >= StoryStage.LIBRARY_RESCUE and stage < StoryStage.CONTROL_ROOM and pos.distance_to(Vector3(58, 3.5, 2)) < 18.0:
		_set_stage(StoryStage.DRONE_UNLOCK, "Rescue drone station nearby. Use drone scanning before entering heavy smoke.")
	if stage >= StoryStage.DRONE_UNLOCK and stage < StoryStage.CONTROL_ROOM and pos.distance_to(Vector3(0, 3, 34)) < 15.0:
		_set_stage(StoryStage.CONTROL_ROOM, "Security control room reached. Restore emergency systems and unlock exits.")
	var helipad_flat_distance := Vector2(pos.x, pos.z).distance_to(Vector2(0, -34))
	if stage >= StoryStage.CONTROL_ROOM and stage < StoryStage.ENDING and helipad_flat_distance < 10.0:
		flags["rooftop"] = true
		_finish_game()


func _update_survival_hints() -> void:
	var smoke_density := 0.0
	var oxygen_ratio := 1.0
	if player.has_node("Systems/SmokeProbe"):
		var smoke_probe := player.get_node("Systems/SmokeProbe")
		smoke_density = float(smoke_probe.get("smoke_density"))
	if player.has_node("Systems/PlayerHealth"):
		var health := player.get_node("Systems/PlayerHealth")
		if health.has_method("oxygen_ratio"):
			oxygen_ratio = float(health.call("oxygen_ratio"))
	if smoke_density > 0.35:
		_once_hint("smoke_low", "Fire safety: smoke rises. Press Ctrl to crouch or C to crawl under dense smoke.")
	if oxygen_ratio < 0.35:
		_once_hint("oxygen", "Oxygen critical. Leave smoke immediately or crawl toward a green evacuation marker.")


func _on_interaction_performed(target: Node, interaction_type: String) -> void:
	match interaction_type:
		"fire_alarm":
			flags["alarm"] = true
			_progress_first_response("Manual alarm activated. Evacuation warnings are now broadcasting.")
		"extinguisher":
			flags["extinguisher"] = true
			_progress_first_response("Extinguisher collected. Use safe routes; do not run into active flame fronts.")
		"emergency_glass":
			flags["glass"] = true
			if stage < StoryStage.RESQTECH_ONLINE:
				_set_stage(StoryStage.KABIR_RESCUE, "Emergency glass broken. Reach Kabir and guide him out.")
		"free_trapped_npc", "calm_npc", "guide_npc":
			_handle_npc_rescue(target)
		"carry_npc", "revive_npc":
			survivors_rescued += 1
			var rescue_stage: int = maxi(stage, StoryStage.LIBRARY_RESCUE)
			_set_stage(rescue_stage, "Survivor stabilized. Move them toward the courtyard or rooftop route.")
		"rescue_drone":
			flags["drone"] = true
			_launch_drone()
			_set_stage(StoryStage.DRONE_UNLOCK, "Drone uplink active. Thermal mode can reveal survivors through smoke.")
		"emergency_switch":
			flags["control"] = true
			systems_restored += 1
			_set_stage(StoryStage.FINAL_ESCAPE, "Exit unlock protocol active. Final evacuation route available to rooftop helipad.")
		"final_evacuate":
			flags["rooftop"] = true
			_finish_game()
		"door":
			_once_hint("doors", "Opened route. If a path is hot or smoke-filled, turn back and follow the green markers.")


func _handle_npc_rescue(target: Node) -> void:
	var name_text := "survivor"
	if target:
		name_text = String(target.name)
	if name_text.contains("Kabir") and not flags["kabir"]:
		flags["kabir"] = true
		survivors_rescued += 1
		_set_stage(StoryStage.RESQTECH_ONLINE, "Kabir rescued. ResQTech has regained partial access to safe-route systems.")
	elif name_text.contains("Riya") and stage < StoryStage.DRONE_UNLOCK:
		survivors_rescued += 1
		_set_stage(StoryStage.DRONE_UNLOCK, "Riya rescued. Auditorium drone station unlocked for thermal scouting.")
	else:
		survivors_rescued += 1
		_once_hint("survivor_generic", "Survivor following. Lead them away from fire, smoke, and blocked exits.")


func _progress_first_response(message: String) -> void:
	if stage < StoryStage.FIRST_RESPONSE:
		_set_stage(StoryStage.FIRST_RESPONSE, "ResQTech AI: " + message)
	else:
		_ai(message)
	if flags["alarm"] and flags["extinguisher"] and stage < StoryStage.KABIR_RESCUE:
		_set_stage(StoryStage.KABIR_RESCUE, "First response complete. Kabir is trapped near the classroom corridor.")


func _finish_game() -> void:
	if stage == StoryStage.ENDING:
		return
	var ending := _ending_id()
	_set_stage(StoryStage.ENDING, "Final evacuation complete. Emergency response report generated.")
	ending_panel.visible = true
	ending_label.text = _ending_text(ending)
	story_completed.emit(ending)


func _launch_drone() -> void:
	if active_drone and is_instance_valid(active_drone):
		active_drone.launch(player.global_position + Vector3(0, 1.4, 0))
		return
	active_drone = DRONE_SCENE.instantiate() as DroneController
	active_drone.name = "Playable_RescueDrone"
	if campus:
		campus.add_child(active_drone)
	else:
		add_child(active_drone)
	active_drone.launch(player.global_position + Vector3(0, 1.4, 0))
	_once_hint("drone_controls", "Drone controls: I/K forward-back, J/L strafe, U/O descend-ascend, T thermal, arrow keys camera.")


func _ending_id() -> String:
	if survivors_rescued >= 4 and systems_restored >= 1 and flags["kabir"] and flags["control"]:
		return "good"
	if survivors_rescued <= 1 or not flags["control"]:
		return "bad"
	return "partial"


func _ending_text(ending: String) -> String:
	match ending:
		"good":
			return "GOOD ENDING\n\nMost survivors evacuated. ResQTech systems restored. Harshit's leadership helped SPS GN Bhopal survive the FIRELINE disaster.\n\nTechnology alone cannot save lives. Together with courage, it can change the future.\n\nPress F to replay training."
		"bad":
			return "BAD ENDING\n\nToo many objectives were missed. The incident becomes a national warning about safety maintenance and delayed evacuation.\n\nEvery second matters during emergencies.\n\nPress F to try again."
		_:
			return "PARTIAL SURVIVAL ENDING\n\nSeveral lives were saved, but some systems failed and parts of the school were lost. Replay to rescue more students and restore emergency infrastructure.\n\nPress F to improve the outcome."


func _set_stage(next_stage: int, ai_text: String) -> void:
	if stage == next_stage and chapter_label != null:
		_ai(ai_text)
		return
	stage = next_stage
	chapter_changed.emit(String(STAGE_TITLES.get(stage, "RESQTECH: FIRELINE")))
	_ai(ai_text)
	_refresh_hud()


func _ai(text: String) -> void:
	if ai_label:
		ai_label.text = text
	if campus and campus.get("ai_label"):
		var world_label := campus.get("ai_label") as Label3D
		if world_label:
			world_label.text = text


func _once_hint(id: String, text: String) -> void:
	if hints_seen.has(id):
		return
	hints_seen[id] = true
	if hint_label:
		hint_label.text = text


func _refresh_hud() -> void:
	if not chapter_label:
		return
	chapter_label.text = String(STAGE_TITLES.get(stage, "RESQTECH: FIRELINE"))
	objective_label.text = _current_objective()
	hint_label.text = String(STAGE_HINTS.get(stage, "Listen to ResQTech AI and keep moving."))
	rescue_label.text = "Survivors rescued: %d   Systems restored: %d" % [survivors_rescued, systems_restored]
	tip_label.text = _safety_tip()


func _current_objective() -> String:
	match stage:
		StoryStage.INTRO:
			return "Objective: Explore the smart-school campus."
		StoryStage.TUTORIAL:
			return "Objective: Practice movement and interaction. Find the ResQTech booth."
		StoryStage.WARNING_SIGNS:
			return "Objective: Investigate warning signs. Press F when ready for incident simulation."
		StoryStage.FIRE_START:
			return "Objective: Survive the blast. Move away from Chemistry Wing."
		StoryStage.FIRST_RESPONSE:
			return "Objective: Pull alarm and collect extinguisher."
		StoryStage.KABIR_RESCUE:
			return "Objective: Rescue Kabir from the classroom corridor."
		StoryStage.RESQTECH_ONLINE:
			return "Objective: Follow safe route markers and reach the library."
		StoryStage.LIBRARY_RESCUE:
			return "Objective: Rescue Riya and junior students from the library."
		StoryStage.DRONE_UNLOCK:
			return "Objective: Operate rescue drone station in the auditorium."
		StoryStage.CONTROL_ROOM:
			return "Objective: Activate exit unlock protocol in the control room."
		StoryStage.FINAL_ESCAPE:
			return "Objective: Reach the rooftop evacuation helipad."
		_:
			return "Objective: Replay to improve rescue outcome."


func _safety_tip() -> String:
	match stage:
		StoryStage.FIRE_START, StoryStage.FIRST_RESPONSE:
			return "Safety Tip: Do not use smoke-filled stairs if there is a safer route."
		StoryStage.KABIR_RESCUE:
			return "Safety Tip: Calm panicking people before guiding them."
		StoryStage.LIBRARY_RESCUE:
			return "Safety Tip: Crawl in heavy smoke and avoid burning shelves."
		StoryStage.CONTROL_ROOM:
			return "Safety Tip: Restoring alarms and exits can save people you never directly see."
		StoryStage.FINAL_ESCAPE:
			return "Safety Tip: Leave immediately when structural collapse risk becomes critical."
		_:
			return "Core Lesson: Preparedness, calm decisions, and clear evacuation routes save lives."


func _build_story_hud() -> void:
	canvas = CanvasLayer.new()
	canvas.name = "PlayableStoryHUD"
	add_child(canvas)
	var root := Control.new()
	root.name = "StoryHUDRoot"
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	canvas.add_child(root)

	chapter_label = _make_label(root, Vector2(24, 18), Vector2(560, 28), 18, Color(0.48, 0.95, 1.0))
	objective_label = _make_label(root, Vector2(24, 50), Vector2(720, 34), 17, Color.WHITE)
	ai_label = _make_label(root, Vector2(24, 90), Vector2(820, 48), 15, Color(0.68, 0.92, 1.0))
	hint_label = _make_label(root, Vector2(24, 142), Vector2(820, 42), 14, Color(1.0, 0.86, 0.36))
	tip_label = _make_label(root, Vector2(24, 190), Vector2(780, 36), 13, Color(0.72, 1.0, 0.72))
	rescue_label = _make_label(root, Vector2(24, 236), Vector2(520, 28), 14, Color(0.9, 0.95, 1.0))

	ending_panel = PanelContainer.new()
	ending_panel.visible = false
	ending_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ending_panel.position = Vector2(240, 120)
	ending_panel.size = Vector2(620, 360)
	root.add_child(ending_panel)
	ending_label = Label.new()
	ending_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ending_label.add_theme_font_size_override("font_size", 18)
	ending_label.add_theme_color_override("font_color", Color.WHITE)
	ending_panel.add_child(ending_label)


func _make_label(parent: Control, pos: Vector2, node_size: Vector2, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.position = pos
	label.size = node_size
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	label.add_theme_constant_override("shadow_offset_x", 2)
	label.add_theme_constant_override("shadow_offset_y", 2)
	parent.add_child(label)
	return label
