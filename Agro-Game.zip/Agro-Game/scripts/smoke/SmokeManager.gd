class_name SmokeManager
extends Node3D

signal player_smoke_exposure_changed(density: float, oxygen: float)
signal smoke_guidance_requested(message: String)

const SMOKE_ZONE_SCENE := preload("res://scenes/smoke/SmokeZone.tscn")

@export var simulation_tick := 0.16
@export var player_sample_height_stand := 1.55
@export var player_sample_height_crouch := 0.95
@export var player_sample_height_crawl := 0.35
@export var far_room_update_multiplier := 3.0

var zones: Dictionary = {}
var tick_timer := 0.0
var heat_system: HeatSystem
var player: Node3D
var visibility_controller: VisibilityController
var oxygen_system: OxygenSystem
var audio_controller: SmokeAudioController
var current_player_density := 0.0
var current_player_oxygen := 1.0


func _ready() -> void:
	add_to_group("smoke_manager")
	visibility_controller = get_node_or_null("VisibilityController") as VisibilityController
	oxygen_system = get_node_or_null("OxygenSystem") as OxygenSystem
	audio_controller = get_node_or_null("SmokeAudioController") as SmokeAudioController


func bind_heat_system(system: HeatSystem) -> void:
	heat_system = system


func register_zone(zone: SmokeZone) -> void:
	if zones.has(zone.room_id):
		return
	zones[zone.room_id] = zone
	zone.critical_smoke.connect(_on_critical_smoke)


func create_zone(room_id: String, spawn_position: Vector3, size: Vector3, zone_type: int, airflow: float, enclosed_factor: float) -> SmokeZone:
	var zone := SMOKE_ZONE_SCENE.instantiate() as SmokeZone
	zone.name = "SmokeZone_" + room_id
	zone.room_id = room_id
	zone.position = spawn_position
	zone.size = size
	zone.zone_type = zone_type as SmokeZone.ZoneType
	zone.base_airflow = airflow
	zone.airflow = airflow
	zone.enclosed_factor = enclosed_factor
	add_child(zone)
	register_zone(zone)
	return zone


func connect_zones(room_a: String, room_b: String) -> void:
	if not zones.has(room_a) or not zones.has(room_b):
		return
	var a := zones[room_a] as SmokeZone
	var b := zones[room_b] as SmokeZone
	if not a.connected_zones.has(b):
		a.connected_zones.append(b)
	if not b.connected_zones.has(a):
		b.connected_zones.append(a)


func open_ventilation(room_id: String, boost: float = 0.55) -> void:
	if zones.has(room_id):
		(zones[room_id] as SmokeZone).open_ventilation(boost)


func activate_sprinkler(room_id: String) -> void:
	if zones.has(room_id):
		(zones[room_id] as SmokeZone).activate_sprinkler()


func _process(delta: float) -> void:
	tick_timer -= delta
	if tick_timer > 0.0:
		return
	tick_timer = simulation_tick
	_simulate(simulation_tick)


func _simulate(delta: float) -> void:
	_resolve_player()
	var player_position: Vector3 = player.global_position if player else Vector3.ZERO
	_inject_from_fire_rooms(delta)

	for zone_key in zones.keys():
		var zone := zones[zone_key] as SmokeZone
		zone.simulate(delta, player_position)
		_apply_npc_reactions(zone)

	_update_player_exposure(player_position)


func _inject_from_fire_rooms(delta: float) -> void:
	if heat_system == null:
		return
	for room_id in zones.keys():
		var zone := zones[room_id] as SmokeZone
		var heat := heat_system.room_temperature(String(room_id))
		var smoke := heat_system.room_smoke(String(room_id))
		if smoke > 0.0 or heat > 36.0:
			var toxicity := _toxicity_for_room(String(room_id))
			zone.inject_smoke(smoke * 1.25 + maxf(0.0, heat - 45.0) * 0.0009, toxicity, heat, delta)


func _update_player_exposure(player_position: Vector3) -> void:
	var density := 0.0
	var oxygen := 1.0
	var sample_height := player_sample_height_stand
	if player:
		var player_stance := int(player.get("stance"))
		if player_stance == 1:
			sample_height = player_sample_height_crouch
		elif player_stance == 2:
			sample_height = player_sample_height_crawl

	for zone_key in zones.keys():
		var zone := zones[zone_key] as SmokeZone
		if not zone.is_player_inside(player_position):
			continue
		var local_height := zone.to_local(player_position).y + sample_height + zone.size.y * 0.5
		density = maxf(density, zone.exposure_at_height(local_height))
		oxygen = minf(oxygen, zone.oxygen_at_height(local_height))

	current_player_density = density
	current_player_oxygen = oxygen
	player_smoke_exposure_changed.emit(density, oxygen)
	if oxygen_system:
		oxygen_system.update_player_exposure(player, density, oxygen)
	if visibility_controller:
		visibility_controller.update_visibility(density, oxygen)
	if audio_controller:
		audio_controller.update_smoke_audio(density, oxygen)


func _apply_npc_reactions(zone: SmokeZone) -> void:
	if zone.smoke_density < 0.25:
		return
	for body in zone.get_overlapping_bodies():
		if not body.is_in_group("story_character"):
			continue
		if body.has_method("set_emergency_mode"):
			body.call("set_emergency_mode", true)
		if zone.smoke_density > 0.75 and body.has_method("mark_injured"):
			body.call("mark_injured")


func _resolve_player() -> void:
	if player and is_instance_valid(player):
		return
	var players := get_tree().get_nodes_in_group("player")
	if not players.is_empty() and players[0] is Node3D:
		player = players[0] as Node3D


func _toxicity_for_room(room_id: String) -> float:
	if room_id.contains("chemistry"):
		return 1.0
	if room_id.contains("cafeteria") or room_id.contains("control"):
		return 0.75
	if room_id.contains("library"):
		return 0.45
	return 0.32


func _on_critical_smoke(zone: SmokeZone) -> void:
	smoke_guidance_requested.emit("ResQTech AI: Critical smoke in " + zone.room_id + ". Crouch or crawl immediately.")
