class_name SmokeAudioController
extends Node

@export var update_smoothing := 0.15

var smoke_intensity := 0.0
var oxygen_stress := 0.0
@onready var cough_loop: AudioStreamPlayer = $CoughLoop
@onready var muffled_hearing: AudioStreamPlayer = $MuffledHearing
@onready var panic_breathing: AudioStreamPlayer = $PanicBreathing


func _ready() -> void:
	_play_if_stream(cough_loop)
	_play_if_stream(muffled_hearing)
	_play_if_stream(panic_breathing)


func update_smoke_audio(smoke_density: float, oxygen: float) -> void:
	smoke_intensity = lerpf(smoke_intensity, smoke_density, update_smoothing)
	oxygen_stress = lerpf(oxygen_stress, 1.0 - oxygen, update_smoothing)
	cough_loop.volume_db = lerpf(-40.0, -8.0, clampf(smoke_intensity, 0.0, 1.0))
	muffled_hearing.volume_db = lerpf(-42.0, -12.0, clampf(smoke_intensity * 0.8 + oxygen_stress * 0.35, 0.0, 1.0))
	panic_breathing.volume_db = lerpf(-38.0, -6.0, clampf(oxygen_stress, 0.0, 1.0))


func _play_if_stream(player: AudioStreamPlayer) -> void:
	if player and player.stream:
		player.play()

