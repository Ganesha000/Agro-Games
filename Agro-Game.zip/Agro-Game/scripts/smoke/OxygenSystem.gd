class_name OxygenSystem
extends Node

signal oxygen_warning(level: float)
signal suffocation_risk(level: float)

@export var stamina_penalty_density_threshold := 0.28
@export var movement_penalty_oxygen_threshold := 0.42


func update_player_exposure(player: Node, smoke_density: float, oxygen: float) -> void:
	if player == null:
		return
	if player.has_node("Systems/SmokeProbe"):
		var probe := player.get_node("Systems/SmokeProbe")
		if probe and probe.has_method("set_environment_exposure"):
			probe.call("set_environment_exposure", smoke_density, 0.0)
	if player.has_node("Systems/PlayerHealth"):
		var health := player.get_node("Systems/PlayerHealth")
		var max_oxygen := float(health.get("max_oxygen"))
		var current_oxygen := float(health.get("current_oxygen"))
		health.set("current_oxygen", minf(current_oxygen, oxygen * max_oxygen))
	if oxygen < 0.35:
		suffocation_risk.emit(oxygen)
	elif oxygen < 0.55:
		oxygen_warning.emit(oxygen)
