class_name SmokeZone
extends Area3D

signal density_changed(zone: SmokeZone, density: float, oxygen: float)
signal critical_smoke(zone: SmokeZone)

enum ZoneType { CLASSROOM, CORRIDOR, STAIRCASE, LIBRARY, VENT_SHAFT, AUDITORIUM, OPEN_COURTYARD }
enum DensityLevel { CLEAR, LIGHT, MEDIUM, HEAVY, CRITICAL }

@export var room_id := "global"
@export var zone_type: ZoneType = ZoneType.CLASSROOM
@export var size := Vector3(8, 4, 8)
@export var base_airflow := 0.25
@export var enclosed_factor := 1.0
@export var vertical_rise_factor := 0.6
@export var smoke_leak_rate := 0.08
@export var oxygen_recovery_rate := 0.035
@export var particle_lod_distance := 90.0

var smoke_density := 0.0
var ceiling_density := 0.0
var floor_density := 0.0
var toxic_density := 0.0
var oxygen := 1.0
var airflow := 0.25
var ventilation_open := false
var sprinkler_active := false
var density_level: DensityLevel = DensityLevel.CLEAR
var connected_zones: Array[SmokeZone] = []
var target_external_density := 0.0

@onready var collision_shape: CollisionShape3D = $CollisionShape3D
@onready var cloud_particles: GPUParticles3D = $SmokeCloud
@onready var ceiling_particles: GPUParticles3D = $CeilingLayer
@onready var toxic_particles: GPUParticles3D = $ToxicSmoke
@onready var haze_mesh: MeshInstance3D = $HazeVolume


func _ready() -> void:
	add_to_group("smoke_zone")
	monitoring = true
	monitorable = true
	collision_layer = 1
	collision_mask = 1
	airflow = base_airflow
	set_meta("smoke_density", smoke_density)
	set_meta("oxygen", oxygen)
	_configure_shape()
	_configure_haze()


func inject_smoke(amount: float, toxicity: float, heat: float, delta: float) -> void:
	var rise_bonus := vertical_rise_factor + clampf(heat / 700.0, 0.0, 1.0) * 0.5
	ceiling_density = clampf(ceiling_density + amount * rise_bonus * enclosed_factor * delta, 0.0, 1.0)
	smoke_density = clampf(smoke_density + amount * enclosed_factor * delta, 0.0, 1.0)
	toxic_density = clampf(toxic_density + amount * toxicity * delta, 0.0, 1.0)
	oxygen = clampf(oxygen - amount * (0.035 + toxicity * 0.035) * delta, 0.05, 1.0)


func simulate(delta: float, player_position: Vector3) -> void:
	var ventilation_factor: float = 2.2 if ventilation_open else 1.0
	var sprinkler_factor: float = 1.65 if sprinkler_active else 1.0
	var effective_airflow := maxf(0.02, airflow * ventilation_factor)

	_spread_to_connected_zones(delta, effective_airflow)
	ceiling_density = maxf(0.0, ceiling_density - effective_airflow * smoke_leak_rate * 0.42 * sprinkler_factor * delta)
	smoke_density = maxf(0.0, smoke_density - effective_airflow * smoke_leak_rate * sprinkler_factor * delta)
	toxic_density = maxf(0.0, toxic_density - effective_airflow * smoke_leak_rate * 0.65 * delta)
	floor_density = clampf(smoke_density * 0.32 + ceiling_density * 0.16, 0.0, 1.0)
	oxygen = minf(1.0, oxygen + oxygen_recovery_rate * effective_airflow * ventilation_factor * delta)

	if zone_type == ZoneType.STAIRCASE:
		ceiling_density = clampf(ceiling_density + smoke_density * 0.14 * delta, 0.0, 1.0)
		smoke_density = clampf(smoke_density + ceiling_density * 0.05 * delta, 0.0, 1.0)
	elif zone_type == ZoneType.OPEN_COURTYARD:
		smoke_density = maxf(0.0, smoke_density - 0.25 * delta)
		ceiling_density = maxf(0.0, ceiling_density - 0.28 * delta)

	_update_density_level()
	_update_visuals(delta, player_position)
	set_meta("smoke_density", smoke_density)
	set_meta("oxygen", oxygen)
	density_changed.emit(self, smoke_density, oxygen)
	if density_level == DensityLevel.CRITICAL:
		critical_smoke.emit(self)


func open_ventilation(boost: float = 0.55) -> void:
	ventilation_open = true
	airflow = clampf(airflow + boost, 0.0, 1.0)


func close_ventilation() -> void:
	ventilation_open = false
	airflow = base_airflow


func activate_sprinkler() -> void:
	sprinkler_active = true


func exposure_at_height(local_height: float) -> float:
	var height_ratio := clampf(local_height / maxf(0.1, size.y), 0.0, 1.0)
	return clampf(lerpf(floor_density, ceiling_density, height_ratio) + toxic_density * 0.35, 0.0, 1.0)


func oxygen_at_height(local_height: float) -> float:
	var smoke_at_height := exposure_at_height(local_height)
	return clampf(oxygen - smoke_at_height * 0.22 - toxic_density * 0.18, 0.0, 1.0)


func is_player_inside(player_position: Vector3) -> bool:
	var local := to_local(player_position)
	return absf(local.x) <= size.x * 0.5 and absf(local.y) <= size.y * 0.5 and absf(local.z) <= size.z * 0.5


func _spread_to_connected_zones(delta: float, effective_airflow: float) -> void:
	for zone in connected_zones:
		if not is_instance_valid(zone):
			continue
		var transfer := maxf(0.0, smoke_density - zone.smoke_density) * effective_airflow * 0.08 * delta
		if transfer <= 0.0:
			continue
		smoke_density = maxf(0.0, smoke_density - transfer * 0.55)
		zone.inject_smoke(transfer, toxic_density, 220.0, 1.0)


func _update_density_level() -> void:
	if smoke_density < 0.08:
		density_level = DensityLevel.CLEAR
	elif smoke_density < 0.25:
		density_level = DensityLevel.LIGHT
	elif smoke_density < 0.50:
		density_level = DensityLevel.MEDIUM
	elif smoke_density < 0.78:
		density_level = DensityLevel.HEAVY
	else:
		density_level = DensityLevel.CRITICAL


func _update_visuals(delta: float, player_position: Vector3) -> void:
	var distance := global_position.distance_to(player_position)
	var lod: float = 1.0 if distance < particle_lod_distance else 0.35
	cloud_particles.amount_ratio = lerpf(cloud_particles.amount_ratio, clampf(smoke_density * lod, 0.0, 1.0), 1.0 - exp(-5.0 * delta))
	ceiling_particles.amount_ratio = lerpf(ceiling_particles.amount_ratio, clampf(ceiling_density * lod, 0.0, 1.0), 1.0 - exp(-5.0 * delta))
	toxic_particles.amount_ratio = lerpf(toxic_particles.amount_ratio, clampf(toxic_density * lod, 0.0, 1.0), 1.0 - exp(-5.0 * delta))
	if haze_mesh and haze_mesh.material_override is StandardMaterial3D:
		var mat := haze_mesh.material_override as StandardMaterial3D
		var haze_color := mat.albedo_color
		haze_color.a = lerpf(haze_color.a, clampf(smoke_density * 0.42, 0.0, 0.52), 1.0 - exp(-4.0 * delta))
		mat.albedo_color = haze_color


func _configure_shape() -> void:
	if collision_shape and collision_shape.shape is BoxShape3D:
		(collision_shape.shape as BoxShape3D).size = size


func _configure_haze() -> void:
	if haze_mesh:
		haze_mesh.scale = size
		var mat := StandardMaterial3D.new()
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.albedo_color = Color(0.08, 0.08, 0.075, 0.0)
		mat.roughness = 1.0
		haze_mesh.material_override = mat
