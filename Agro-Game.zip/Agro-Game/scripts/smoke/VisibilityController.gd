class_name VisibilityController
extends Node

@export var max_fog_density := 0.13
@export var clear_fog_density := 0.012
@export var critical_vignette_message := "Visibility critical. Stay low."

var current_density := 0.0
var current_oxygen := 1.0
var world_environment: WorldEnvironment


func _ready() -> void:
	world_environment = _find_world_environment()


func update_visibility(smoke_density: float, oxygen: float) -> void:
	current_density = lerpf(current_density, smoke_density, 0.18)
	current_oxygen = lerpf(current_oxygen, oxygen, 0.18)
	if world_environment == null:
		world_environment = _find_world_environment()
	if world_environment == null or world_environment.environment == null:
		return
	var env := world_environment.environment
	env.volumetric_fog_enabled = true
	env.volumetric_fog_density = lerpf(clear_fog_density, max_fog_density, current_density)
	env.volumetric_fog_albedo = Color(0.16, 0.15, 0.13).lerp(Color(0.05, 0.05, 0.045), current_density)
	env.adjustment_enabled = true
	env.adjustment_contrast = lerpf(1.08, 1.42, current_density)
	env.adjustment_saturation = lerpf(1.0, 0.55, current_density)
	env.glow_enabled = true
	env.glow_intensity = lerpf(0.55, 1.2, current_density)


func _find_world_environment() -> WorldEnvironment:
	var root := get_tree().current_scene
	if root == null:
		return null
	return _find_world_environment_recursive(root)


func _find_world_environment_recursive(node: Node) -> WorldEnvironment:
	if node is WorldEnvironment:
		return node as WorldEnvironment
	for child in node.get_children():
		var found := _find_world_environment_recursive(child)
		if found:
			return found
	return null

