class_name DroneThermalScanner
extends Node3D

signal scan_ping(position: Vector3, kind: String, confidence: float)
signal scan_results(results: Array)

@export var scan_radius := 35.0
@export var scan_interval := 0.4
@export var survivor_group := "survivor"

var tick := 0.0
var enabled := false


func _process(delta: float) -> void:
	if not enabled:
		return
	tick -= delta
	if tick <= 0.0:
		tick = scan_interval
		scan(global_position)


func scan(origin: Vector3) -> Array:
	var results: Array = []
	for node in get_tree().get_nodes_in_group(survivor_group):
		if not node is Node3D:
			continue
		var body := node as Node3D
		var distance := body.global_position.distance_to(origin)
		if distance > scan_radius:
			continue
		var confidence := 1.0 - distance / scan_radius
		results.append({"target": body, "position": body.global_position, "kind": "survivor", "confidence": confidence})
		scan_ping.emit(body.global_position, "survivor", confidence)
	scan_results.emit(results)
	return results
