class_name DroneCamera
extends Node3D

signal camera_mode_changed(mode: int)

enum CameraMode { STANDARD, THERMAL, SMOKE_PENETRATION, HAZARD_ANALYSIS }

@export var mouse_sensitivity := 0.003
@export var zoom_speed := 6.0
@export var min_fov := 35.0
@export var max_fov := 85.0
@export var shake_decay := 4.0

var mode: int = CameraMode.STANDARD
var yaw := 0.0
var pitch := 0.0
var shake := 0.0

@onready var camera: Camera3D = get_node_or_null("Camera3D") as Camera3D


func _ready() -> void:
	if not camera:
		camera = Camera3D.new()
		camera.name = "Camera3D"
		add_child(camera)


func update_look(delta: float, look_input: Vector2, zoom_input: float) -> void:
	yaw -= look_input.x * mouse_sensitivity
	pitch = clampf(pitch - look_input.y * mouse_sensitivity, deg_to_rad(-78.0), deg_to_rad(78.0))
	rotation = Vector3(pitch, yaw, 0.0)
	camera.fov = clampf(camera.fov - zoom_input * zoom_speed * delta, min_fov, max_fov)
	if shake > 0.0:
		camera.h_offset = randf_range(-shake, shake)
		camera.v_offset = randf_range(-shake, shake)
		shake = move_toward(shake, 0.0, shake_decay * delta)
	else:
		camera.h_offset = 0.0
		camera.v_offset = 0.0


func set_mode(next_mode: int) -> void:
	mode = next_mode
	camera_mode_changed.emit(mode)


func add_shake(amount: float) -> void:
	shake = maxf(shake, amount)
