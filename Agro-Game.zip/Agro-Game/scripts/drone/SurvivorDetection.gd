class_name SurvivorDetection
extends Node

signal survivor_marked(target: Node3D, priority: float)
signal rescue_ping(position: Vector3, priority: float)

@export var confidence_threshold := 0.28

var marked: Dictionary = {}


func ingest_scan_results(results: Array) -> void:
	for result in results:
		var target := result.get("target") as Node3D
		if not target:
			continue
		var confidence := float(result.get("confidence", 0.0))
		if confidence < confidence_threshold:
			continue
		var priority := confidence
		if target.has_method("get_rescue_priority"):
			priority = maxf(priority, float(target.call("get_rescue_priority")))
		marked[target.get_instance_id()] = {"target": target, "priority": priority}
		survivor_marked.emit(target, priority)
		rescue_ping.emit(target.global_position, priority)
