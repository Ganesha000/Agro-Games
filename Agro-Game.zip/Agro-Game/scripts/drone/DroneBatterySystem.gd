class_name DroneBatterySystem
extends Node

signal battery_changed(level: float)
signal low_battery(level: float)
signal depleted

@export var capacity_seconds := 360.0
@export var thermal_drain_multiplier := 1.45
@export var boost_drain_multiplier := 1.7
@export var heat_damage_drain := 0.85
@export var low_battery_threshold := 0.18

var level := 1.0
var warned := false


func update_battery(delta: float, speed_factor: float, thermal_enabled: bool, boosting: bool, heat: float) -> void:
	var drain := delta / capacity_seconds
	drain *= lerpf(0.75, 1.35, clampf(speed_factor, 0.0, 1.0))
	if thermal_enabled:
		drain *= thermal_drain_multiplier
	if boosting:
		drain *= boost_drain_multiplier
	drain += heat * heat_damage_drain * delta / capacity_seconds
	level = clampf(level - drain, 0.0, 1.0)
	battery_changed.emit(level)
	if level <= low_battery_threshold and not warned:
		warned = true
		low_battery.emit(level)
	if level <= 0.0:
		depleted.emit()


func recharge(amount: float) -> void:
	level = clampf(level + amount, 0.0, 1.0)
	warned = level <= low_battery_threshold
	battery_changed.emit(level)
