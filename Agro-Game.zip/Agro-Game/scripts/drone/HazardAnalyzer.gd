class_name HazardAnalyzer
extends Node3D

signal hazard_detected(kind: String, position: Vector3, severity: float)

@export var probe_radius := 24.0
@export var probe_interval := 0.5

var tick := 0.0
var danger_analysis: Node


func _ready() -> void:
	var nodes := get_tree().get_nodes_in_group("danger_analysis")
	if not nodes.is_empty():
		danger_analysis = nodes[0]


func _process(delta: float) -> void:
	tick -= delta
	if tick <= 0.0:
		tick = probe_interval
		analyze(global_position)


func analyze(origin: Vector3) -> float:
	if not danger_analysis or not danger_analysis.has_method("danger_at"):
		return 0.0
	var severity := float(danger_analysis.call("danger_at", origin, probe_radius))
	if severity > 0.55:
		hazard_detected.emit("environment", origin, severity)
	return severity
