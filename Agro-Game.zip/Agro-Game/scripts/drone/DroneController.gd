class_name DroneController
extends CharacterBody3D

signal launched
signal recalled
signal drone_warning(text: String, urgency: float)

@export var max_speed := 8.5
@export var boost_speed := 14.0
@export var acceleration := 7.5
@export var vertical_speed := 5.0
@export var tilt_amount := 0.24
@export var return_height := 2.0
@export var player_anchor_path: NodePath

var active := false
var boost := false
var hover_hold := true
var home_position := Vector3.ZERO
var heat_exposure := 0.0

@onready var camera_rig: DroneCamera = get_node_or_null("DroneCamera") as DroneCamera
@onready var battery: DroneBatterySystem = get_node_or_null("DroneBatterySystem") as DroneBatterySystem
@onready var thermal_scanner: DroneThermalScanner = get_node_or_null("DroneThermalScanner") as DroneThermalScanner
@onready var survivor_detection: SurvivorDetection = get_node_or_null("SurvivorDetection") as SurvivorDetection
@onready var hazard_analyzer: HazardAnalyzer = get_node_or_null("HazardAnalyzer") as HazardAnalyzer
@onready var player_anchor: Node3D = get_node_or_null(player_anchor_path) as Node3D


func _ready() -> void:
	add_to_group("rescue_drone")
	_ensure_input_actions()
	_ensure_children()
	battery.low_battery.connect(func(level: float) -> void: drone_warning.emit("Drone battery low: " + str(roundi(level * 100.0)) + "%", 0.75))
	battery.depleted.connect(recall)
	thermal_scanner.scan_results.connect(survivor_detection.ingest_scan_results)
	hazard_analyzer.hazard_detected.connect(func(kind: String, _pos: Vector3, sev: float) -> void: drone_warning.emit("Drone hazard scan: " + kind, sev))


func launch(origin: Vector3) -> void:
	global_position = origin + Vector3.UP * return_height
	home_position = origin
	active = true
	visible = true
	launched.emit()


func recall() -> void:
	active = false
	thermal_scanner.enabled = false
	recalled.emit()


func _physics_process(delta: float) -> void:
	if not active:
		return
	var input := _movement_input()
	boost = Input.is_action_pressed("drone_boost")
	var target_speed := boost_speed if boost else max_speed
	var desired := (global_transform.basis * input).limit_length(1.0) * target_speed
	velocity = velocity.move_toward(desired, acceleration * delta)
	move_and_slide()
	rotation.z = lerpf(rotation.z, -input.x * tilt_amount, delta * 5.0)
	rotation.x = lerpf(rotation.x, input.z * tilt_amount, delta * 5.0)
	var speed_factor := velocity.length() / boost_speed
	battery.update_battery(delta, speed_factor, thermal_scanner.enabled, boost, heat_exposure)


func _process(delta: float) -> void:
	if not active:
		return
	var look := Input.get_vector("drone_look_left", "drone_look_right", "drone_look_up", "drone_look_down")
	var zoom := Input.get_axis("drone_zoom_out", "drone_zoom_in")
	camera_rig.update_look(delta, look, zoom)
	if Input.is_action_just_pressed("drone_thermal"):
		thermal_scanner.enabled = not thermal_scanner.enabled
		camera_rig.set_mode(DroneCamera.CameraMode.THERMAL if thermal_scanner.enabled else DroneCamera.CameraMode.STANDARD)


func apply_explosion_shock(strength: float) -> void:
	camera_rig.add_shake(strength * 0.15)
	velocity += Vector3(randf_range(-1, 1), randf_range(0.2, 1.0), randf_range(-1, 1)).normalized() * strength


func _movement_input() -> Vector3:
	var x := Input.get_axis("drone_left", "drone_right")
	var z := Input.get_axis("drone_forward", "drone_back")
	var y := Input.get_axis("drone_descend", "drone_ascend")
	return Vector3(x, y * vertical_speed / max_speed, z)


func _ensure_children() -> void:
	if not camera_rig:
		camera_rig = DroneCamera.new()
		camera_rig.name = "DroneCamera"
		add_child(camera_rig)
	if not battery:
		battery = DroneBatterySystem.new()
		battery.name = "DroneBatterySystem"
		add_child(battery)
	if not thermal_scanner:
		thermal_scanner = DroneThermalScanner.new()
		thermal_scanner.name = "DroneThermalScanner"
		add_child(thermal_scanner)
	if not survivor_detection:
		survivor_detection = SurvivorDetection.new()
		survivor_detection.name = "SurvivorDetection"
		add_child(survivor_detection)
	if not hazard_analyzer:
		hazard_analyzer = HazardAnalyzer.new()
		hazard_analyzer.name = "HazardAnalyzer"
		add_child(hazard_analyzer)


func _ensure_input_actions() -> void:
	_ensure_key_action("drone_forward", [KEY_I])
	_ensure_key_action("drone_back", [KEY_K])
	_ensure_key_action("drone_left", [KEY_J])
	_ensure_key_action("drone_right", [KEY_L])
	_ensure_key_action("drone_ascend", [KEY_O])
	_ensure_key_action("drone_descend", [KEY_U])
	_ensure_key_action("drone_boost", [KEY_SHIFT])
	_ensure_key_action("drone_thermal", [KEY_T])
	_ensure_key_action("drone_look_left", [KEY_LEFT])
	_ensure_key_action("drone_look_right", [KEY_RIGHT])
	_ensure_key_action("drone_look_up", [KEY_UP])
	_ensure_key_action("drone_look_down", [KEY_DOWN])
	_ensure_key_action("drone_zoom_in", [KEY_EQUAL])
	_ensure_key_action("drone_zoom_out", [KEY_MINUS])


func _ensure_key_action(action_name: String, physical_keys: Array) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	if not InputMap.action_get_events(action_name).is_empty():
		return
	for keycode: int in physical_keys:
		var event := InputEventKey.new()
		event.physical_keycode = keycode as Key
		InputMap.action_add_event(action_name, event)
